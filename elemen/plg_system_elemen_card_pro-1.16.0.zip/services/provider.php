<?php

/**
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

use Elemen\Plugin\System\CardPro\Extension\CardPro;
use Joomla\CMS\Extension\PluginInterface;
use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(
            PluginInterface::class,
            function (Container $container) {
                $plugin = new CardPro((array) PluginHelper::getPlugin('system', 'elemen_card_pro'));
                $plugin->setApplication(Factory::getApplication());

                return $plugin;
            }
        );
    }
};
