<?php

/**
 * Card Pro helpers: presets, checked settings, the grid and the accent colour classes.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

if (class_exists('ElemenCardPro', false)) {
    return;
}

final class ElemenCardPro
{
    /** Columns per screen size: setting => UIkit breakpoint. */
    public const BREAKPOINTS = ['grid_small' => 's', 'grid_medium' => 'm', 'grid_large' => 'l'];

    /**
     * Every setting a preset can decide, with the allowed values; the first is the default.
     * While a preset is picked these settings are hidden in the builder and come from it.
     */
    public const CHOICES = [
        'card_style'     => ['elevated', 'outline', 'accent', 'gradient', 'glass', 'overlay', 'spotlight', 'split'],
        'hover'          => ['lift', 'none', 'zoom', 'tilt', 'reveal', 'glow'],
        'media_position' => ['top', 'bottom', 'left', 'right', 'inset'],
        'image_display'  => ['cover', 'avatar', 'logo'],
        'image_ratio'    => ['16-9', 'auto', '3-2', '4-3', '1-1'],
        'icon_shape'     => ['circle', 'none', 'square'],
        'text_align'     => ['left', 'center'],
        'link_style'     => ['arrow', 'default', 'primary', 'secondary', 'text'],
        'meta_position'  => ['above', 'below'],
        'meta_style'     => ['meta', 'kicker'],
        'quote_mark'     => [false, true],
    ];

    /** Other settings with fixed values; the first is the default. */
    public const OPTIONS = [
        'surface'          => ['auto', 'muted', 'primary', 'secondary', 'none'],
        'accent'           => ['primary', 'secondary', 'custom'],
        'radius'           => ['medium', 'none', 'small', 'large', 'xlarge'],
        'shadow'           => ['', 'none', 'small', 'medium', 'large'],
        'padding'          => ['default', 'small', 'large'],
        'speed'            => ['normal', 'slow', 'fast'],
        'accent_position'  => ['top', 'start', 'bottom'],
        'glass_blur'       => ['medium', 'small', 'large'],
        'glass_tint'       => ['none', 'primary', 'secondary'],
        'overlay_height'   => ['medium', 'small', 'large'],
        'overlay_scrim'    => ['dark', 'primary', 'secondary'],
        'overlay_position' => ['bottom', 'center'],
        'spot_size'        => ['medium', 'small', 'large'],
        'split_side'       => ['start', 'end'],
        'split_width'      => ['1-3', '1-4', '2-5'],
        'media_width'      => ['2-5', '1-3', '1-2'],
        'horizontal_breakpoint' => ['s', 'm'],
        'entrance'         => ['', 'fade', 'slide', 'scale'],
        'gap'              => ['medium', 'small', 'large'],
        'title_element'    => ['h3', 'h2', 'h4', 'div'],
        'title_style'      => ['h4', '', 'h5', 'h3', 'h2'],
        'content_style'    => ['', 'small', 'large'],
        'badge_position'   => ['inline', 'corner', 'ribbon'],
        'badge_style'      => ['', 'success', 'warning', 'danger'],
    ];

    /** Ready-made looks: values for the settings in CHOICES. */
    public const PRESETS = [
        'corporate' => [
            'card_style' => 'accent', 'hover' => 'lift', 'media_position' => 'top', 'image_display' => 'cover', 'image_ratio' => '16-9',
            'icon_shape' => 'square', 'text_align' => 'left', 'link_style' => 'arrow', 'meta_position' => 'above', 'meta_style' => 'kicker', 'quote_mark' => false,
        ],
        'glass' => [
            'card_style' => 'glass', 'hover' => 'glow', 'media_position' => 'inset', 'image_display' => 'cover', 'image_ratio' => '16-9',
            'icon_shape' => 'circle', 'text_align' => 'left', 'link_style' => 'arrow', 'meta_position' => 'above', 'meta_style' => 'meta', 'quote_mark' => false,
        ],
        'feature' => [
            'card_style' => 'elevated', 'hover' => 'lift', 'media_position' => 'top', 'image_display' => 'logo', 'image_ratio' => 'auto',
            'icon_shape' => 'circle', 'text_align' => 'center', 'link_style' => 'arrow', 'meta_position' => 'below', 'meta_style' => 'meta', 'quote_mark' => false,
        ],
        'blog' => [
            'card_style' => 'elevated', 'hover' => 'zoom', 'media_position' => 'top', 'image_display' => 'cover', 'image_ratio' => '3-2',
            'icon_shape' => 'none', 'text_align' => 'left', 'link_style' => 'arrow', 'meta_position' => 'above', 'meta_style' => 'meta', 'quote_mark' => false,
        ],
        'team' => [
            'card_style' => 'overlay', 'hover' => 'reveal', 'media_position' => 'top', 'image_display' => 'cover', 'image_ratio' => 'auto',
            'icon_shape' => 'none', 'text_align' => 'left', 'link_style' => 'text', 'meta_position' => 'below', 'meta_style' => 'kicker', 'quote_mark' => false,
        ],
        'service' => [
            'card_style' => 'split', 'hover' => 'lift', 'media_position' => 'left', 'image_display' => 'cover', 'image_ratio' => 'auto',
            'icon_shape' => 'none', 'text_align' => 'left', 'link_style' => 'arrow', 'meta_position' => 'above', 'meta_style' => 'kicker', 'quote_mark' => false,
        ],
        'testimonial' => [
            'card_style' => 'elevated', 'hover' => 'lift', 'media_position' => 'top', 'image_display' => 'avatar', 'image_ratio' => 'auto',
            'icon_shape' => 'none', 'text_align' => 'left', 'link_style' => 'text', 'meta_position' => 'below', 'meta_style' => 'meta', 'quote_mark' => true,
        ],
        'showcase' => [
            'card_style' => 'gradient', 'hover' => 'tilt', 'media_position' => 'inset', 'image_display' => 'cover', 'image_ratio' => '16-9',
            'icon_shape' => 'circle', 'text_align' => 'left', 'link_style' => 'arrow', 'meta_position' => 'above', 'meta_style' => 'kicker', 'quote_mark' => false,
        ],
    ];

    /** Radius in px, also used for the drawn outline. */
    public const RADIUS = ['none' => 0, 'small' => 6, 'medium' => 12, 'large' => 20, 'xlarge' => 28];

    /** The shadow each style has when Shadow is "Style default". */
    public const STYLE_SHADOW = [
        'elevated' => 'small', 'outline' => 'none', 'accent' => 'small', 'gradient' => 'none',
        'glass' => 'small', 'overlay' => 'medium', 'spotlight' => 'none', 'split' => 'small',
    ];

    /**
     * The settings with the preset applied and every value checked.
     *
     * @param  array<string, mixed> $props
     * @return array<string, mixed>
     */
    public static function settings(array $props): array
    {
        $preset = (string) ($props['preset'] ?? '');
        $preset = isset(self::PRESETS[$preset]) ? $preset : '';
        $s      = ['preset' => $preset];

        foreach (self::CHOICES as $key => $allowed) {
            $value   = $preset !== '' ? self::PRESETS[$preset][$key] : ($props[$key] ?? $allowed[0]);
            $s[$key] = $key === 'quote_mark' ? (bool) $value : (in_array((string) $value, $allowed, true) ? (string) $value : $allowed[0]);
        }

        foreach (self::OPTIONS as $key => $allowed) {
            $value   = (string) ($props[$key] ?? $allowed[0]);
            $s[$key] = in_array($value, $allowed, true) ? $value : $allowed[0];
        }

        $s['shadow']       = $s['shadow'] === '' ? self::STYLE_SHADOW[$s['card_style']] : $s['shadow'];
        $s['border_width'] = max(0, min(8, (int) ($props['border_width'] ?? 0)));
        $s['tilt_angle']   = max(2, min(20, (int) ($props['tilt_angle'] ?? 0) ?: 8));
        $s['icon_size']    = max(16, min(96, (int) ($props['icon_size'] ?? 0) ?: 28));
        $s['accent_color'] = self::color($props['accent_color'] ?? '');
        $s['accent_end']   = self::color($props['gradient_color'] ?? '');

        foreach (['equal_height' => true, 'style_motion' => true, 'ambient' => false, 'spot_group' => true, 'tilt_glare' => true, 'whole_card' => false, 'link_full' => false, 'link_target' => false] as $key => $default) {
            $s[$key] = (bool) ($props[$key] ?? $default);
        }

        // A custom accent without a colour falls back to the primary colour.
        if ($s['accent'] === 'custom' && $s['accent_color'] === '') {
            $s['accent'] = 'primary';
        }

        return $s;
    }

    /** A CSS colour from a colour field, or '' when it isn't one. */
    public static function color($value): string
    {
        $value = trim((string) $value);

        return preg_match('/^(#[0-9a-f]{3,8}|(rgb|rgba|hsl|hsla|oklch|oklab)\([0-9.,%\s\/+-]+(deg)?\))$/i', $value) ? $value : '';
    }

    /**
     * Classes for the decorative layers that take the accent colour: they draw with
     * currentColor, so a theme colour class gives them the theme's colour, and the inverse
     * colour in dark sections.
     */
    public static function tone(string $accent, string $custom = ''): string
    {
        if ($custom !== '' || $accent === 'custom') {
            return 'cp-tone cp-tone-custom';
        }

        return 'cp-tone uk-text-' . ($accent === 'secondary' ? 'secondary' : 'primary');
    }

    /** Background classes for an accent panel (Split, scrims and tints). */
    public static function panel(string $accent, string $custom = ''): string
    {
        if ($custom !== '' || $accent === 'custom') {
            return 'cp-panel-custom';
        }

        return 'uk-background-' . ($accent === 'secondary' ? 'secondary' : 'primary');
    }

    /**
     * Grid width classes per screen size; each size falls back to the one below.
     *
     * @param  array<string, mixed> $props
     * @return list<string>
     */
    public static function grid(array $props): array
    {
        $first   = max(1, min(6, (int) ($props['grid_default'] ?? 1) ?: 1));
        $classes = ["uk-child-width-1-{$first}"];

        foreach (self::BREAKPOINTS as $key => $bp) {
            $value = (int) ($props[$key] ?? 0);

            if ($value > 0) {
                $classes[] = 'uk-child-width-1-' . max(1, min(6, $value)) . "@{$bp}";
            }
        }

        return $classes;
    }
}
