/* Elemen: Card Pro — Spotlight and Tilt 3D. Only for mice and trackpads, never with reduced motion. No dependencies. */
(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
    const pointer = window.matchMedia('(hover: hover) and (pointer: fine)');

    function setup(cp) {
        cp.setAttribute('data-cp-ready', '');

        const frames = [...cp.querySelectorAll(':scope > .cp-grid > .cp-item > .cp-frame')];
        const cards = frames.map((frame) => frame.querySelector(':scope > .cp-card')).filter(Boolean);
        const active = () => pointer.matches && !reduce.matches;

        // Spotlight: the light follows the pointer. With "nearby cards" every card gets the
        // position, so the border light reaches the neighbours of the hovered card.
        if (cp.classList.contains('cp-style-spotlight')) {
            const group = cp.classList.contains('cp-spot-group');
            let frame = 0;
            let last = null;

            const paint = () => {
                frame = 0;

                const targets = group ? cards : cards.filter((card) => card.matches(':hover'));
                const rects = targets.map((card) => card.getBoundingClientRect());

                targets.forEach((card, i) => {
                    card.style.setProperty('--cp-x', `${Math.round(last.clientX - rects[i].left)}px`);
                    card.style.setProperty('--cp-y', `${Math.round(last.clientY - rects[i].top)}px`);
                });
            };

            cp.addEventListener('pointermove', (event) => {
                if (!active() || event.pointerType === 'touch') {
                    return;
                }

                last = event;
                frame = frame || requestAnimationFrame(paint);
            }, { passive: true });
        }

        // Tilt 3D: the card leans towards the pointer, with an optional glare.
        if (cp.classList.contains('cp-hover-tilt')) {
            const max = Math.min(20, Math.max(2, Number(cp.getAttribute('data-cp-tilt')) || 8));

            frames.forEach((el) => {
                let frame = 0;
                let last = null;

                const paint = () => {
                    frame = 0;

                    const rect = el.getBoundingClientRect();
                    const x = Math.min(1, Math.max(0, (last.clientX - rect.left) / rect.width));
                    const y = Math.min(1, Math.max(0, (last.clientY - rect.top) / rect.height));

                    el.classList.add('is-tilting');
                    el.style.transform = `perspective(1000px) rotateX(${((0.5 - y) * max).toFixed(2)}deg) rotateY(${((x - 0.5) * max).toFixed(2)}deg) translateY(-4px)`;
                    el.style.setProperty('--cp-gx', `${Math.round(x * 100)}%`);
                    el.style.setProperty('--cp-gy', `${Math.round(y * 100)}%`);
                };

                el.addEventListener('pointermove', (event) => {
                    if (!active() || event.pointerType === 'touch') {
                        return;
                    }

                    last = event;
                    frame = frame || requestAnimationFrame(paint);
                }, { passive: true });

                el.addEventListener('pointerleave', () => {
                    cancelAnimationFrame(frame);
                    frame = 0;
                    el.classList.remove('is-tilting');
                    el.style.transform = '';
                });
            });
        }
    }

    const init = (root) => root.querySelectorAll('.elemen-card-pro:not([data-cp-ready])').forEach(setup);

    const boot = () => {
        init(document);

        // The YOOtheme builder preview replaces elements while editing.
        new MutationObserver(() => init(document)).observe(document.body, { childList: true, subtree: true });
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
