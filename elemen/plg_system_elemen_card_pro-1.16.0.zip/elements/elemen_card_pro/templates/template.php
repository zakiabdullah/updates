<?php

/**
 * Card Pro: a grid of cards with a style, a hover effect and a layout for all of them.
 *
 * Every look is CSS. The accent colour reaches decorative layers through theme colour
 * classes (currentColor), so it follows the theme and turns light in dark sections.
 * card-pro.js is only queued for the Spotlight style and the Tilt 3D hover effect.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var \YOOtheme\Builder $builder
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<int, object> $children
 */

use Joomla\CMS\Uri\Uri;
use YOOtheme\Metadata;

use function YOOtheme\app;

\defined('_JEXEC') or die;

require_once \dirname(__DIR__) . '/ElemenCardPro.php';

// Display options: fields of every card can be hidden without deleting them. Layouts saved
// before the options existed don't have them, so they count as shown.
$hidden = [];

foreach (['title' => ['title'], 'meta' => ['meta'], 'content' => ['content'], 'image' => ['image'], 'icon' => ['icon', 'icon_lucide'], 'badge' => ['badge'], 'link' => ['link', 'link_text']] as $option => $fields) {
    if (!($props["show_{$option}"] ?? true)) {
        array_push($hidden, ...$fields);
    }
}

foreach ($hidden ? $children : [] as $child) {
    foreach ($hidden as $field) {
        if (is_array($child->props ?? null)) {
            $child->props[$field] = '';
        } elseif (is_object($child->props ?? null)) {
            $child->props->{$field} = '';
        }
    }
}

$has = static fn ($value): bool => trim((string) $value) !== '';

// Cards with something to show.
$cards = array_values(array_filter($children, static function (object $child) use ($has): bool {
    $p = (array) ($child->props ?? []);

    foreach (['title', 'meta', 'content', 'image', 'icon', 'icon_lucide'] as $field) {
        if ($has($p[$field] ?? '')) {
            return true;
        }
    }

    return false;
}));

if (!$cards) {
    return;
}

$s = ElemenCardPro::settings($props);

$assets   = \dirname(__DIR__) . '/assets';
$assetUrl = static fn (string $file): string => Uri::root(true) . '/'
    . str_replace('\\', '/', substr($assets, strlen(JPATH_ROOT) + 1)) . "/{$file}?v=" . @filemtime("{$assets}/{$file}");
$metadata = app(Metadata::class);

$metadata->set('style:elemen-card-pro', ['href' => $assetUrl('card-pro.css')]);

$spotlight = $s['card_style'] === 'spotlight';
$tilt      = $s['hover'] === 'tilt';

if ($spotlight || $tilt) {
    $metadata->set('script:elemen-card-pro', ['src' => $assetUrl('card-pro.js'), 'defer' => true]);
}

$horizontal = $s['card_style'] === 'split' || (in_array($s['media_position'], ['left', 'right'], true) && $s['image_display'] === 'cover' && $s['card_style'] !== 'overlay');

$vars = ['--cp-radius: ' . ElemenCardPro::RADIUS[$s['radius']] . 'px', "--cp-icon: {$s['icon_size']}px"];

if ($s['border_width'] > 0) {
    $vars[] = "--cp-border: {$s['border_width']}px";
}

if ($s['accent'] === 'custom') {
    $vars[] = "--cp-accent: {$s['accent_color']}";
}

if ($s['accent_end'] !== '') {
    $vars[] = "--cp-accent-2: {$s['accent_end']}";
}

$el = $this->el('div', [
    'class' => [
        'elemen-card-pro cp',
        "cp-style-{$s['card_style']}",
        "cp-hover-{$s['hover']}",
        "cp-surface-{$s['surface']}",
        "cp-shadow-{$s['shadow']}",
        "cp-pad-{$s['padding']}",
        "cp-speed-{$s['speed']}",
        "cp-align-{$s['text_align']}",
        "cp-image-{$s['image_display']}",
        "cp-media-{$s['media_position']}" => $s['image_display'] === 'cover',
        "cp-ratio-{$s['image_ratio']}" => $s['image_display'] === 'cover' && $s['image_ratio'] !== 'auto',
        "cp-hz cp-hz-{$s['horizontal_breakpoint']}" => $horizontal,
        "cp-mw-{$s['media_width']}" => $horizontal && $s['card_style'] !== 'split',
        "cp-bar-{$s['accent_position']}" => $s['card_style'] === 'accent',
        "cp-blur-{$s['glass_blur']}" => $s['card_style'] === 'glass',
        "cp-oh-{$s['overlay_height']} cp-op-{$s['overlay_position']}" => $s['card_style'] === 'overlay',
        "cp-spot-{$s['spot_size']}" => $spotlight,
        'cp-spot-group' => $spotlight && $s['spot_group'],
        "cp-split-{$s['split_side']} cp-sw-{$s['split_width']}" => $s['card_style'] === 'split',
        'cp-motion' => $s['style_motion'],
        'cp-ambient' => $s['ambient'] && $s['card_style'] === 'gradient',
        'cp-glare' => $tilt && $s['tilt_glare'],
        'cp-equal' => $s['equal_height'],
        'cp-whole' => $s['whole_card'],
        "cp-meta-{$s['meta_style']}",
        "cp-content-{$s['content_style']}" => $s['content_style'] !== '',
    ],
    'style'       => implode('; ', $vars),
    'data-cp-tilt' => $tilt ? (string) $s['tilt_angle'] : false,
]);

$gap = $s['gap'];

$entrance = [
    'fade'  => 'uk-animation-fade',
    'slide' => 'uk-animation-slide-bottom-small',
    'scale' => 'uk-animation-scale-up',
][$s['entrance']] ?? '';

$grid = $this->el('div', [
    'class'        => ['cp-grid uk-grid', "uk-grid-{$gap}", 'uk-grid-match' => $s['equal_height'], 'uk-flex-center' => $s['text_align'] === 'center', ...ElemenCardPro::grid($props)],
    'uk-grid'      => true,
    'uk-scrollspy' => $entrance !== '' ? "target: > .cp-item; cls: {$entrance}; delay: 90" : false,
]);

?>
<?= $el($props, $attrs) ?>

    <?= $grid() ?>
        <?php foreach ($cards as $i => $card) : ?>
        <?= $builder->render($card, ['element' => $props, 'settings' => $s, 'index' => $i]) ?>
        <?php endforeach ?>
    <?= $grid->end() ?>

<?= $el->end() ?>
