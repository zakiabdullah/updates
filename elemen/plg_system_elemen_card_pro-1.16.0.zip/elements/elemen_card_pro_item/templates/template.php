<?php

/**
 * Card Pro card. The parent passes its props and the checked settings.
 *
 * Structure: .cp-item (grid cell) > .cp-frame (moves: lift, tilt; holds the glow) >
 * .cp-card (clips: surface, decorative layers, media, body).
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<string, mixed> $element
 * @var array<string, mixed> $settings
 */

\defined('_JEXEC') or die;

require_once \dirname(__DIR__, 2) . '/elemen_card_pro/ElemenCardPro.php';

$element ??= [];
$s         = $settings ?? ElemenCardPro::settings($element);
$has       = static fn ($value): bool => trim((string) $value) !== '';
$e         = static fn ($value): string => htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
$style     = $s['card_style'];
$featured  = !empty($props['featured']);
$custom    = ElemenCardPro::color($props['accent_color'] ?? '');
$tone      = ElemenCardPro::tone($s['accent'], $custom);
$panel     = ElemenCardPro::panel($s['accent'], $custom);
$image     = $has($props['image'] ?? '') ? (string) $props['image'] : '';
$display   = $s['image_display'];
$titleTag  = $s['title_element'];
$link      = $has($props['link'] ?? '') ? (string) $props['link'] : '';
$whole     = $s['whole_card'] && $link !== '';
$reveal    = $s['hover'] === 'reveal';
$avatar    = $display === 'avatar' && $image !== '';
$target    = $s['link_target'] ? ' target="_blank" rel="noopener"' : '';

$img = fn (string $class, array $extra = []): string => $this->el('image', [
    'class'     => ['el-image', $class],
    'src'       => $image,
    'alt'       => $props['image_alt'] ?? '',
    'loading'   => 'lazy',
    'thumbnail' => true,
] + $extra)->render([]);

// Icon: Icon Pro's icon (its "Icon (Icon Pro)" field, while Icon Pro is installed) wins over
// the UIkit icon.
$icon = '';

if ($has($props['icon_lucide'] ?? '')) {
    $file = JPATH_PLUGINS . '/system/elemen_icon_pro/elements/elemen_icon_pro/icons/Icons.php';

    if (is_file($file)) {
        require_once $file;
        $icon = \Elemen\IconPro\Icons::svg((string) $props['icon_lucide'], ['size' => $style === 'split' ? max(40, $s['icon_size']) : $s['icon_size']]);
    }
}

if ($icon === '' && $has($props['icon'] ?? '')) {
    $ratio = round(($style === 'split' ? max(40, $s['icon_size']) : $s['icon_size']) / 20, 2);
    $icon  = '<span uk-icon="icon: ' . $e($props['icon']) . '; ratio: ' . $ratio . '"></span>';
}

// Surface of the card itself.
$surface = match (true) {
    $style === 'glass'   => 'cp-glass',
    $style === 'overlay' => 'cp-overlay uk-light',
    default              => [
        'auto'      => 'uk-background-default',
        'muted'     => 'uk-background-muted',
        'primary'   => 'uk-background-primary uk-light',
        'secondary' => 'uk-background-secondary uk-light',
        'none'      => 'cp-transparent',
    ][$s['surface']],
};

$badge = '';

if ($has($props['badge'] ?? '')) {
    $label = 'uk-label' . ($s['badge_style'] !== '' ? " uk-label-{$s['badge_style']}" : '');
    $badge = [
        'inline' => '<div class="cp-badge"><span class="' . $label . '">' . $props['badge'] . '</span></div>',
        'corner' => '<span class="cp-badge-corner ' . $label . '">' . $props['badge'] . '</span>',
        'ribbon' => '<span class="cp-ribbon ' . $label . '">' . $props['badge'] . '</span>',
    ][$s['badge_position']];
}

// Title: the whole-card link sits on it (its ::after covers the card).
$title = '';

if ($has($props['title'] ?? '')) {
    $text  = $whole ? '<a class="cp-main-link" href="' . $e($link) . '"' . $target . '>' . $props['title'] . '</a>' : $props['title'];
    $title = "<{$titleTag} class=\"el-title cp-title uk-margin-remove" . ($s['title_style'] !== '' ? " uk-{$s['title_style']}" : '') . "\">{$text}</{$titleTag}>";
}

$meta = '';

if ($has($props['meta'] ?? '')) {
    $meta = $s['meta_style'] === 'kicker'
        ? '<div class="el-meta cp-meta cp-kicker ' . $tone . '">' . $props['meta'] . '</div>'
        : '<div class="el-meta cp-meta uk-text-meta">' . $props['meta'] . '</div>';
}

// Link: with the whole card clickable and a title to carry the link, the visible button is
// only decoration, so the card has one link for keyboards and screen readers.
$action = '';

if ($link !== '' && $has($props['link_text'] ?? '')) {
    $text = (string) $props['link_text'];
    $tag  = $whole && $title !== '' ? 'span' : 'a';
    $href = $tag === 'a' ? ' href="' . $e($link) . '"' . $target : ' aria-hidden="true"';
    $main = $tag === 'a' && $whole ? ' cp-main-link' : '';

    $action = $s['link_style'] === 'arrow'
        ? "<{$tag} class=\"el-link cp-arrow {$tone}{$main}\"{$href}><span>{$text}</span><span class=\"cp-arrow-icon\" uk-icon=\"icon: arrow-right; ratio: .9\"></span></{$tag}>"
        : "<{$tag} class=\"el-link uk-button uk-button-{$s['link_style']}" . ($s['link_full'] ? ' uk-width-1-1' : '') . "{$main}\"{$href}>{$text}</{$tag}>";
}

$content = $has($props['content'] ?? '') ? '<div class="el-content cp-content uk-panel' . ($s['content_style'] === 'small' ? ' uk-text-small' : ($s['content_style'] === 'large' ? ' uk-text-lead' : '')) . '">' . $props['content'] . '</div>' : '';
$quote   = $s['quote_mark'] && $content !== '' ? '<div class="cp-quote ' . $tone . '" aria-hidden="true">&ldquo;</div>' : '';

// Media for the Cover image (Overlay and Split place the image themselves).
$media = '';

if ($image !== '' && $display === 'cover' && !in_array($style, ['overlay', 'split'], true)) {
    $media = '<div class="cp-media">' . $img('cp-image') . '</div>';
}

$el = $this->el('div', [
    'class' => ['el-item cp-item', 'cp-featured' => $featured],
    'style' => $custom !== '' ? "--cp-accent: {$custom}" : false,
]);

?>
<?= $el($props, $attrs) ?>
    <div class="cp-frame">

        <?php if ($s['hover'] === 'glow' || $featured) : ?>
        <span class="cp-glow <?= $tone ?>" aria-hidden="true"></span>
        <?php endif ?>

        <div class="cp-card <?= $surface ?>">

            <?php if ($style === 'overlay') : ?>
            <div class="cp-bg"><?= $image !== '' ? $img('cp-image') : '' ?></div>
            <span class="cp-scrim<?= $s['overlay_scrim'] !== 'dark' ? ' cp-scrim-tint ' . ElemenCardPro::panel($s['overlay_scrim']) : '' ?>" aria-hidden="true"></span>
            <?php endif ?>

            <?php if ($style === 'glass') : ?>
            <?php if ($s['glass_tint'] !== 'none') : ?><span class="cp-tint <?= ElemenCardPro::panel($s['glass_tint']) ?>" aria-hidden="true"></span><?php endif ?>
            <?php if ($s['style_motion']) : ?><span class="cp-shine" aria-hidden="true"></span><?php endif ?>
            <?php endif ?>

            <?php if ($style === 'gradient') : ?>
            <span class="cp-ring <?= $tone ?>" aria-hidden="true"></span>
            <?php elseif ($featured) : ?>
            <span class="cp-feature-ring <?= $tone ?>" aria-hidden="true"></span>
            <?php endif ?>

            <?php if ($style === 'outline' && $s['style_motion']) : ?>
            <svg class="cp-draw <?= $tone ?>" aria-hidden="true" focusable="false"><rect x="0" y="0" width="100%" height="100%" rx="<?= ElemenCardPro::RADIUS[$s['radius']] ?>" ry="<?= ElemenCardPro::RADIUS[$s['radius']] ?>" pathLength="100" /></svg>
            <?php endif ?>

            <?php if ($style === 'accent') : ?>
            <span class="cp-bar <?= $tone ?>" aria-hidden="true"></span>
            <?php endif ?>

            <?php if ($style === 'spotlight') : ?>
            <span class="cp-spot <?= $tone ?>" aria-hidden="true"></span>
            <span class="cp-spot-edge <?= $tone ?>" aria-hidden="true"></span>
            <?php endif ?>

            <?php if ($s['hover'] === 'tilt' && $s['tilt_glare']) : ?>
            <span class="cp-glare-layer" aria-hidden="true"></span>
            <?php endif ?>

            <?php if ($s['badge_position'] !== 'inline') : ?><?= $badge ?><?php endif ?>

            <?php if ($style === 'split') : ?>
            <div class="cp-panel <?= $panel ?> uk-light">
                <?php if ($icon !== '') : ?>
                <span class="cp-panel-icon" aria-hidden="true"><?= $icon ?></span>
                <?php elseif ($image !== '' && $display === 'cover') : ?>
                <?= $img('cp-image') ?>
                <?php endif ?>
            </div>
            <?php endif ?>

            <?= $media ?>

            <div class="cp-body">

                <?php if ($s['badge_position'] === 'inline') : ?><?= $badge ?><?php endif ?>

                <?php if ($image !== '' && $display === 'logo') : ?>
                <div class="cp-logo"><?= $img('cp-logo-image') ?></div>
                <?php elseif ($icon !== '' && $style !== 'split') : ?>
                <div class="cp-icon cp-icon-<?= $s['icon_shape'] ?> <?= $tone ?>" aria-hidden="true"><?= $icon ?></div>
                <?php endif ?>

                <?php if (!$avatar) : ?>
                <?php if ($s['meta_position'] === 'above') : ?><?= $meta ?><?php endif ?>
                <?= $title ?>
                <?php if ($s['meta_position'] === 'below') : ?><?= $meta ?><?php endif ?>
                <?php endif ?>

                <?php if ($reveal && ($content !== '' || $action !== '')) : ?>
                <div class="cp-reveal"><div class="cp-reveal-inner">
                <?php endif ?>

                <?= $quote ?>
                <?= $content ?>

                <?php if ($avatar) : ?>
                <div class="cp-person">
                    <?= $img('cp-avatar', ['width' => 56, 'height' => 56]) ?>
                    <div class="cp-person-text">
                        <?= $title ?>
                        <?= $meta ?>
                    </div>
                </div>
                <?php endif ?>

                <?php if ($action !== '') : ?>
                <div class="cp-action"><?= $action ?></div>
                <?php endif ?>

                <?php if ($reveal && ($content !== '' || $action !== '')) : ?>
                </div></div>
                <?php endif ?>

            </div>
        </div>
    </div>
<?= $el->end() ?>
