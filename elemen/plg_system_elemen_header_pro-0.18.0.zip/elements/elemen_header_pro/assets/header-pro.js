/*
 * Elemen Header Pro: takes the tint from the theme style and keeps the menu readable.
 *
 * The tint is the background of a uk-section-{default|muted|primary|secondary} section in
 * the compiled theme, so it follows the customizer. Whether text on it is light is the
 * theme's own choice too: the text colour of that section. With light text, the sticky
 * navbar gets uk-light (UIkit's light text) while it is sticky, and loses it again
 * afterwards, unless it had it before.
 */
(() => {
    const body = document.body;
    const tint = (body.className.match(/\belemen-hp--tint-(\w+)/) || [])[1] || 'default';

    const probe = document.createElement('div');
    probe.className = `uk-section uk-section-${tint}`;
    probe.style.cssText = 'position:absolute;width:0;height:0;padding:0;overflow:hidden;visibility:hidden';
    body.appendChild(probe);
    const style = getComputedStyle(probe);
    const parse = (value) => (value.match(/[\d.]+/g) || []).map(Number);
    const bg = parse(style.backgroundColor);
    const text = parse(style.color);
    probe.remove();

    // Not found, or transparent: keep the default (white) tint from the stylesheet.
    if (bg.length < 3 || bg[3] === 0) {
        return;
    }

    body.style.setProperty('--ehp-rgb', bg.slice(0, 3).join(' '));

    const luminance = (rgb) => {
        const [r, g, b] = rgb.slice(0, 3)
            .map((v) => v / 255)
            .map((v) => (v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4));

        return 0.2126 * r + 0.7152 * g + 0.0722 * b;
    };

    // A number, or max(...) in browsers without backdrop blur, which is nearly solid.
    const alpha = parseFloat(getComputedStyle(body).getPropertyValue('--ehp-alpha'));
    const opacity = Number.isNaN(alpha) ? 1 : alpha;

    // Light text on this colour in the theme. A see-through glass shows the page more than
    // the tint, so then the text is left alone.
    if (text.length < 3 || luminance(text) < 0.5 || opacity < 0.5) {
        return;
    }

    body.classList.add('elemen-hp--dark');

    const headers = [
        body.classList.contains('elemen-hp--desktop') && '.tm-header',
        body.classList.contains('elemen-hp--mobile') && '.tm-header-mobile',
    ].filter(Boolean);

    const sync = (bar) => {
        const sticky = bar.classList.contains('uk-navbar-sticky');

        if (sticky && !bar.classList.contains('uk-light')) {
            bar.classList.add('uk-light');
            bar.dataset.ehpLight = '';
        } else if (!sticky && 'ehpLight' in bar.dataset) {
            bar.classList.remove('uk-light');
            delete bar.dataset.ehpLight;
        }
    };

    document.querySelectorAll(headers.map((h) => `${h} .uk-navbar-container`).join(',') || ':not(*)').forEach((bar) => {
        sync(bar);
        new MutationObserver(() => sync(bar)).observe(bar, { attributes: true, attributeFilter: ['class'] });
    });
})();
