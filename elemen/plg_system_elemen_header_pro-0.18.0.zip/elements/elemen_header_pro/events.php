<?php

/**
 * Header Pro: how the navbar looks while it is sticky (glass or solid, full width or a
 * floating capsule), set in the customizer under Header, right after the sticky option.
 *
 * Nothing in YOOtheme's header markup changes. The settings become classes on <body> and
 * CSS custom properties; header-pro.css styles the navbar while UIkit marks it sticky
 * (.uk-navbar-sticky). header-pro.js reads the tint colour from the theme's own
 * uk-background-* class, so the glass follows the style chosen in the customizer, and
 * switches the menu text to light on dark tints.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

use Joomla\CMS\Document\HtmlDocument;
use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;
use YOOtheme\Config;
use YOOtheme\Event;
use YOOtheme\Metadata;

use function YOOtheme\app;

\defined('_JEXEC') or die;

if (!class_exists('ElemenHeaderPro', false)) {
    final class ElemenHeaderPro
    {
        public const STYLES = ['glass', 'solid'];

        public const RADIUS = ['pill' => '999px', 'large' => '24px', 'medium' => '14px', 'small' => '8px', 'none' => '0px'];

        /**
         * The customizer fields, keyed by their config path below ~theme.
         *
         * @return array<string, array<string, mixed>>
         */
        public static function fields(): array
        {
            $on      = 'elemen_header.style';
            $glass   = "elemen_header.style == 'glass'";
            $capsule = "elemen_header.style && elemen_header.shape == 'capsule'";

            return [
                'elemen_header.style' => [
                    'label'       => 'Sticky Style',
                    'description' => 'How the navbar looks while it is sticky (Elemen Header Pro). Glass blurs the page behind it. Needs a sticky navbar, set above.',
                    'type'        => 'select',
                    'options'     => ['None' => '', 'Glass' => 'glass', 'Solid' => 'solid'],
                    'enable'      => 'navbar.sticky || mobile.navbar.sticky',
                ],
                'elemen_header.shape' => [
                    'label'   => 'Sticky Shape',
                    'type'    => 'select',
                    'options' => ['Full Width' => 'full', 'Capsule' => 'capsule'],
                    'show'    => $on,
                ],
                'elemen_header.tint' => [
                    'label'       => 'Sticky Tint',
                    'description' => 'Colour of the glass or bar, from the theme style. Menu text turns light on dark colours.',
                    'type'        => 'select',
                    'options'     => ['Background' => 'default', 'Muted' => 'muted', 'Primary' => 'primary', 'Secondary' => 'secondary'],
                    'show'        => $on,
                ],
                'elemen_header.opacity' => [
                    'label'  => 'Glass Opacity',
                    'type'   => 'range',
                    'attrs'  => ['min' => 0, 'max' => 100, 'step' => 5],
                    'show'   => $glass,
                ],
                'elemen_header.blur' => [
                    'label'       => 'Glass Blur',
                    'description' => 'Opacity in percent and blur in pixels.',
                    'type'        => 'range',
                    'attrs'       => ['min' => 0, 'max' => 40, 'step' => 1],
                    'show'        => $glass,
                ],
                'elemen_header.gap' => [
                    'label'       => 'Capsule Gap',
                    'description' => 'Space around the capsule, in pixels.',
                    'type'        => 'range',
                    'attrs'       => ['min' => 0, 'max' => 40, 'step' => 1],
                    'show'        => $capsule,
                ],
                'elemen_header.radius' => [
                    'label'   => 'Capsule Corners',
                    'type'    => 'select',
                    'options' => ['Pill' => 'pill', 'Large' => 'large', 'Medium' => 'medium', 'Small' => 'small', 'None' => 'none'],
                    'show'    => $capsule,
                ],
                'elemen_header.height' => [
                    'label'       => 'Sticky Height',
                    'description' => 'Navbar height while sticky, in pixels; the logo shrinks to fit. 0 keeps the height.',
                    'type'        => 'range',
                    'attrs'       => ['min' => 0, 'max' => 120, 'step' => 2],
                    'show'        => $on,
                ],
                'elemen_header.shadow' => [
                    'label' => 'Sticky Effects',
                    'type'  => 'checkbox',
                    'text'  => 'Add a shadow',
                    'show'  => $on,
                ],
                'elemen_header.border' => [
                    'type' => 'checkbox',
                    'text' => 'Add a border',
                    'show' => $on,
                ],
                'elemen_header.mobile' => [
                    'description' => 'The mobile header gets the same look. If its own navbar is static (under Mobile), it becomes sticky like the navbar above.',
                    'type'        => 'checkbox',
                    'text'        => 'Apply to the mobile header',
                    'show'        => "$on && mobile.breakpoint",
                ],
            ];
        }

        /**
         * Body classes and CSS custom properties for the current settings, or null when off.
         *
         * @param  array<string, mixed>  $theme  the ~theme config
         *
         * @return array{classes: list<string>, css: string, mobile_sticky: int|null}|null
         */
        public static function settings(array $theme): ?array
        {
            $s     = (array) ($theme['elemen_header'] ?? []);
            $style = (string) ($s['style'] ?? '');

            if (!in_array($style, self::STYLES, true)) {
                return null;
            }

            $desktop = !empty($theme['navbar']['sticky']);
            $mobile  = !empty($s['mobile']) && !empty($theme['mobile']['breakpoint'])
                && (!empty($theme['mobile']['navbar']['sticky']) || $desktop);

            if (!$desktop && !$mobile) {
                return null;
            }

            // A static mobile navbar follows the desktop one (Sticky or Sticky on scroll up).
            $mobileSticky = $mobile ? ((int) ($theme['mobile']['navbar']['sticky'] ?? 0) ?: (int) $theme['navbar']['sticky']) : null;

            $tint   = in_array($s['tint'] ?? '', ['default', 'muted', 'primary', 'secondary'], true) ? $s['tint'] : 'default';
            $height = max(0, min(200, (int) ($s['height'] ?? 0)));

            $classes = array_values(array_filter([
                'elemen-hp',
                "elemen-hp--$style",
                "elemen-hp--tint-$tint",
                ($s['shape'] ?? '') === 'capsule' ? 'elemen-hp--capsule' : '',
                $desktop ? 'elemen-hp--desktop' : '',
                $mobile ? 'elemen-hp--mobile' : '',
                $height ? 'elemen-hp--shrink' : '',
                !empty($s['shadow']) ? 'elemen-hp--shadow' : '',
                !empty($s['border']) ? 'elemen-hp--border' : '',
            ]));

            $vars = [
                '--ehp-opacity' => round(max(0, min(100, (int) ($s['opacity'] ?? 70))) / 100, 2),
                '--ehp-blur'    => max(0, min(60, (int) ($s['blur'] ?? 16))) . 'px',
                '--ehp-gap'     => max(0, min(60, (int) ($s['gap'] ?? 12))) . 'px',
                '--ehp-radius'  => self::RADIUS[$s['radius'] ?? 'pill'] ?? self::RADIUS['pill'],
                '--ehp-height'  => $height . 'px',
            ];

            $css = ':root{' . implode(';', array_map(static fn ($k, $v) => "$k:$v", array_keys($vars), $vars)) . '}';

            return ['classes' => $classes, 'css' => $css, 'mobile_sticky' => $mobileSticky];
        }

        public static function assetUrl(string $file): string
        {
            $assets = __DIR__ . '/assets';

            return Uri::root(true) . '/' . str_replace('\\', '/', substr($assets, strlen(JPATH_ROOT) + 1)) . "/{$file}?v=" . @filemtime("{$assets}/{$file}");
        }

        /** On the site, once Joomla has dispatched and YOOtheme has set its body classes. */
        public static function apply(): void
        {
            $app = Factory::getApplication();

            if (!$app->isClient('site') || !$app->getDocument() instanceof HtmlDocument) {
                return;
            }

            $config = app(Config::class);

            if (!$config->get('theme.active')) {
                return;
            }

            $settings = self::settings((array) $config->get('~theme'));

            if ($settings === null) {
                return;
            }

            $config->set('~theme.body_class', array_merge((array) $config->get('~theme.body_class', []), $settings['classes']));

            // Before the template renders the mobile header, which reads this.
            if ($settings['mobile_sticky'] !== null) {
                $config->set('~theme.mobile.navbar.sticky', $settings['mobile_sticky']);
            }

            $metadata = app(Metadata::class);
            $metadata->set('style:elemen-header-pro', ['href' => self::assetUrl('header-pro.css')]);
            // Inline CSS straight to Joomla: YOOtheme's Metadata passes only files and scripts
            // on to the Web Asset Manager, so an inline style there never reaches the page.
            $app->getDocument()->getWebAssetManager()->addInlineStyle($settings['css'], ['name' => 'elemen-header-pro-vars']);
            $metadata->set('script:elemen-header-pro', ['src' => self::assetUrl('header-pro.js'), 'defer' => true]);
        }
    }
}

// YOOtheme sets ~theme.body_class on onAfterDispatch (default priority, and it replaces
// the list); this runs afterwards and adds to it. Joomla runs higher priorities first.
Factory::getApplication()->getDispatcher()->addListener('onAfterDispatch', static function (): void {
    ElemenHeaderPro::apply();
}, -100);

// The customizer: the Header panel gets the fields right after its sticky option. Runs
// after YOOtheme has loaded the panels (priority 0) and before it sends them (-20).
Event::on('customizer.init', static function (): void {
    $config = app(Config::class);
    $fields = (array) $config->get('customizer.panels.header.fields');

    if (!$fields || isset($fields['elemen_header.style'])) {
        return;
    }

    $out = [];

    foreach ($fields as $name => $field) {
        $out[$name] = $field;

        if ($name === 'navbar.sticky') {
            $out += ElemenHeaderPro::fields();
        }
    }

    // Without the sticky option (another YOOtheme version), at the end of the panel.
    $config->set('customizer.panels.header.fields', $out + ElemenHeaderPro::fields());
}, -10);

return [];
