<?php

/**
 * Marquee Pro item: a logo, an icon and/or a text, linked or not.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<string, mixed> $element
 * @var int|null $index
 */

\defined('_JEXEC') or die;

$has = static fn ($value): bool => trim((string) $value) !== '';

// Display options of the marquee: hide fields without deleting them. Missing in layouts
// saved before the options existed, so they count as shown.
$show = static fn (string $field): bool => (bool) ($element["show_{$field}"] ?? true);

$text  = $show('text') && $has($props['text']);
$image = $show('image') && $props['image'];
$icons = $show('icon') && ($has($props['icon']) || $has($props['icon_lucide'] ?? ''));
$link  = $show('link') && $props['link'];

if (!$text && !$image && !$icons) {
    return;
}

// A Lucide icon from Icon Pro's "Lucide Icon" field, when Icon Pro is installed.
$lucide = static function ($name, int $size): string {
    $file = JPATH_PLUGINS . '/system/elemen_icon_pro/elements/elemen_icon_pro/icons/Icons.php';

    if (trim((string) $name) === '' || !is_file($file)) {
        return '';
    }

    require_once $file;

    return \Elemen\IconPro\Icons::svg((string) $name, ['size' => $size]);
};

$index = (int) ($index ?? 0);
$inner = '';

if ($image) {
    $inner .= $this->el('image', [
        'class'     => ['el-image mq-image'],
        'src'       => $props['image'],
        'alt'       => $props['image_alt'],
        'thumbnail' => true,
    ])->render([]);
}

if (!$icons) {
    // Icons hidden.
} elseif ($svg = $lucide($props['icon_lucide'] ?? '', 20)) {
    $inner .= '<span class="mq-icon">' . $svg . '</span>';
} elseif ($has($props['icon'])) {
    $inner .= '<span class="mq-icon" uk-icon="icon: ' . htmlspecialchars((string) $props['icon']) . '"></span>';
}

if ($text) {
    $style  = (string) $element['text_style'];
    $inner .= '<span class="el-title mq-text' . ($style ? ' uk-' . $style . ' uk-margin-remove' : '')
        . ($element['text_color'] ? ' uk-text-' . $element['text_color'] : '') . '">' . $props['text'] . '</span>';
}

// A link without its text still needs a name for screen readers: the hidden text, unless
// the image has an alt text.
$label = $link && !$text && !($image && $has($props['image_alt'])) ? trim(strip_tags((string) $props['text'])) : '';

$el = $this->el($link ? 'a' : 'div', [
    'class'      => ['el-item mq-item', 'mq-outline' => $element['outline'] && $index % 2 === 1],
    'href'       => $link ? ['{link}'] : false,
    'target'     => $link && $props['link_target'] ? '_blank' : false,
    'aria-label' => $label !== '' ? $label : false,
]);

echo $el($props, $attrs) . $inner . $el->end();
