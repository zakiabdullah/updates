/* Elemen: Marquee Pro — rows that scroll without end. No dependencies. */
(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    function setup(mq) {
        mq.setAttribute('data-mq-ready', '');

        if (reduce || !Element.prototype.animate) {
            return; // stays still and scrolls by hand
        }

        let options = {};

        try {
            options = JSON.parse(mq.getAttribute('data-mq') || '{}');
        } catch (e) {
            // keep the defaults
        }

        const speed = Math.max(5, Number(options.speed) || 50);
        const toggle = mq.querySelector(':scope > .mq-toggle');
        const state = { hover: false, focus: false, visible: true, stopped: false };
        const rows = [];

        // Pause, slow down or run every row, from the state above.
        function apply() {
            const pause = state.stopped || !state.visible || state.focus || (options.hover === 'pause' && state.hover);
            const rate = options.hover === 'slow' && state.hover ? 0.25 : 1;

            rows.forEach(({ animation }) => {
                if (!animation) {
                    return;
                }

                if (pause) {
                    animation.pause();
                } else {
                    animation.updatePlaybackRate ? animation.updatePlaybackRate(rate) : (animation.playbackRate = rate);
                    animation.play();
                }
            });
        }

        mq.querySelectorAll(':scope > .mq-row').forEach((row) => {
            const track = row.querySelector(':scope > .mq-track');
            const group = track && track.querySelector(':scope > .mq-group');

            if (!group) {
                return;
            }

            const entry = { animation: null, width: 0 };
            rows.push(entry);

            // Copies the group until the row is full twice over, then moves the track by
            // exactly one group, so the loop has no seam. Keeps the position on resize.
            const build = () => {
                const width = group.getBoundingClientRect().width;

                if (!width || Math.abs(width - entry.width) < 0.5 && track.children.length * width >= row.clientWidth + width) {
                    return;
                }

                const copies = Math.ceil(row.clientWidth / width) + 1;

                while (track.children.length < copies) {
                    const copy = group.cloneNode(true);
                    copy.classList.add('mq-clone');
                    // Hidden from screen readers and skipped by Tab, but still clickable:
                    // most of what is on screen can be copies, and their links must work.
                    copy.setAttribute('aria-hidden', 'true');
                    copy.querySelectorAll('a, button, [tabindex]').forEach((node) => node.setAttribute('tabindex', '-1'));
                    copy.querySelectorAll('[id]').forEach((node) => node.removeAttribute('id'));
                    track.appendChild(copy);
                }

                const duration = (width / speed) * 1000;
                let progress = 0;

                if (entry.animation) {
                    const timing = entry.animation.effect.getTiming();
                    progress = ((entry.animation.currentTime || 0) % timing.duration) / timing.duration;
                    entry.animation.cancel();
                }

                entry.width = width;
                entry.animation = track.animate(
                    [{ transform: 'translateX(0)' }, { transform: `translateX(${-width}px)` }],
                    { duration, iterations: Infinity, direction: row.getAttribute('data-dir') === 'right' ? 'reverse' : 'normal' }
                );
                entry.animation.currentTime = progress * duration;
                mq.classList.add('mq-moving');
                apply();
            };

            let frame = 0;
            const schedule = () => {
                cancelAnimationFrame(frame);
                frame = requestAnimationFrame(build);
            };

            if ('ResizeObserver' in window) {
                const observer = new ResizeObserver(schedule);
                observer.observe(row);
                observer.observe(group);
            } else {
                window.addEventListener('resize', schedule);
            }

            build();
        });

        mq.addEventListener('mouseenter', () => {
            state.hover = true;
            apply();
        });
        mq.addEventListener('mouseleave', () => {
            state.hover = false;
            apply();
        });

        // A keyboard user tabbing through the links needs them to hold still.
        mq.addEventListener('focusin', (event) => {
            state.focus = event.target !== toggle;
            apply();
        });
        mq.addEventListener('focusout', () => {
            state.focus = false;
            apply();
        });

        // Rows off screen do not need to move.
        if ('IntersectionObserver' in window) {
            new IntersectionObserver(([entry]) => {
                state.visible = entry.isIntersecting;
                apply();
            }).observe(mq);
        }

        if (toggle) {
            let labels = ['Pause', 'Play'];

            try {
                labels = JSON.parse(toggle.getAttribute('data-labels')) || labels;
            } catch (e) {
                // keep the defaults
            }

            toggle.hidden = false;
            toggle.addEventListener('click', () => {
                state.stopped = !state.stopped;
                toggle.setAttribute('aria-pressed', String(state.stopped));
                toggle.setAttribute('aria-label', labels[state.stopped ? 1 : 0]);
                apply();
            });
        }
    }

    const init = (root) => root.querySelectorAll('.elemen-marquee-pro:not([data-mq-ready])').forEach(setup);

    const boot = () => {
        init(document);

        // The YOOtheme builder preview replaces elements while editing.
        new MutationObserver(() => init(document)).observe(document.body, { childList: true, subtree: true });
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
