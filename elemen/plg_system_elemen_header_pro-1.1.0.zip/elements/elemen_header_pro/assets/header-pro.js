/*
 * Elemen Header Pro: takes colours from the theme style and keeps the menu readable.
 *
 * Colours come from hidden probes with the theme's own classes, so they follow the
 * customizer: the tint is the background of a uk-section-{default|muted|primary|secondary}
 * section, the active menu item uses the primary section's background and text colour,
 * and glass dropdowns the navbar dropdown's background.
 *
 * When the theme uses light text on the tint, the navbar gets uk-light (UIkit's light
 * text) while its surface shows: while sticky, or always, and not while waiting for
 * Start After. It loses it again afterwards, unless it had it before.
 *
 * Also: the scroll progress bar, Start After (body class elemen-hp--waiting until the page
 * is scrolled --ehp-offset pixels) and the moving menu highlight (.elemen-hp-indicator).
 */
(() => {
    const body = document.body;
    const has = (name) => body.classList.contains(`elemen-hp--${name}`);
    const tint = (body.className.match(/\belemen-hp--tint-(\w+)/) || [])[1] || 'default';
    const parse = (value) => (value.match(/[\d.]+/g) || []).map(Number);
    const visible = (rgb) => rgb.length >= 3 && rgb[3] !== 0;
    const headers = [has('desktop') && '.tm-header', has('mobile') && '.tm-header-mobile'].filter(Boolean);
    const within = (selector) => headers.map((h) => `${h} ${selector}`).join(',') || ':not(*)';
    const syncs = [];

    const probe = (className) => {
        const el = document.createElement('div');
        el.className = className;
        el.style.cssText = 'position:absolute;width:0;height:0;padding:0;overflow:hidden;visibility:hidden';
        body.appendChild(el);
        const style = getComputedStyle(el);
        const colors = { bg: parse(style.backgroundColor), text: parse(style.color) };
        el.remove();

        return colors;
    };

    const luminance = (rgb) => {
        const [r, g, b] = rgb.slice(0, 3)
            .map((v) => v / 255)
            .map((v) => (v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4));

        return 0.2126 * r + 0.7152 * g + 0.0722 * b;
    };

    const set = (name, rgb) => body.style.setProperty(name, rgb.slice(0, 3).join(' '));

    // Scroll progress: a bar in the primary colour, scaled to how far the page is read.
    if (has('progress')) {
        const bar = document.createElement('div');
        bar.className = 'elemen-hp-progress uk-background-primary';
        bar.setAttribute('aria-hidden', 'true');
        body.appendChild(bar);

        let queued = false;
        const update = () => {
            queued = false;
            const max = document.documentElement.scrollHeight - window.innerHeight;
            bar.style.transform = `scaleX(${max > 0 ? Math.min(1, Math.max(0, window.scrollY / max)) : 0})`;
        };
        const queue = () => {
            if (!queued) {
                queued = true;
                requestAnimationFrame(update);
            }
        };

        window.addEventListener('scroll', queue, { passive: true });
        window.addEventListener('resize', queue);
        update();
    }

    // Smaller navbar while sticky: the logo gets a height, at most its own (--ehp-logo-h), so
    // a small logo is never made larger. Its height attribute, else its height on the page.
    if (has('shrink')) {
        document.querySelectorAll(within('.uk-logo')).forEach((logo) => {
            const heights = [...logo.querySelectorAll('img, svg')]
                .map((el) => parseFloat(el.getAttribute('height')) || el.getBoundingClientRect().height)
                .filter((h) => h > 0);

            if (heights.length) {
                logo.style.setProperty('--ehp-logo-h', `${Math.max(...heights)}px`);
            }
        });
    }

    // Start After: the surface waits until the page is scrolled far enough.
    if (has('waiting')) {
        const offset = parseFloat(getComputedStyle(body).getPropertyValue('--ehp-offset')) || 0;
        let waiting = true;
        const check = () => {
            const now = window.scrollY < offset;

            if (now !== waiting) {
                waiting = now;
                body.classList.toggle('elemen-hp--waiting', waiting);
                syncs.forEach((sync) => sync());
            }
        };

        window.addEventListener('scroll', check, { passive: true });
        check();
    }

    // Moving highlight: one pill or line per menu that slides to the item under the pointer
    // or keyboard focus, and back to the active item.
    if (has('menu-slide') && (has('menu-pill') || has('menu-underline'))) {
        document.querySelectorAll(within('.uk-navbar-nav')).forEach((nav) => {
            const items = [...nav.children].filter((li) => li.tagName === 'LI');
            const active = items.find((li) => li.classList.contains('uk-active')) || null;
            const indicator = document.createElement('li');
            indicator.className = 'elemen-hp-indicator';
            indicator.setAttribute('role', 'presentation');
            indicator.setAttribute('aria-hidden', 'true');
            nav.appendChild(indicator);

            let current = null;
            let jump = true;

            const moveTo = (li) => {
                current = li;
                items.forEach((item) => {
                    item.classList.toggle('elemen-hp-on', item === li);
                    item.classList.toggle('elemen-hp-off', item !== li && item.classList.contains('uk-active'));
                });

                const link = li && li.querySelector(':scope > a');

                if (!link) {
                    indicator.style.opacity = '0';
                    return;
                }

                const box = nav.getBoundingClientRect();
                const rect = link.getBoundingClientRect();

                // The first placement (and after a resize) jumps; later moves slide.
                if (jump) {
                    indicator.style.transition = 'none';
                }

                indicator.style.fontSize = getComputedStyle(link).fontSize;
                indicator.style.width = `${rect.width}px`;
                indicator.style.setProperty('--ehp-x', `${rect.left - box.left}px`);
                indicator.style.opacity = '1';

                if (jump) {
                    indicator.getBoundingClientRect();
                    indicator.style.transition = '';
                    jump = false;
                }
            };

            // Delegated, bubbling events on the menu: enter events on its items do not
            // always arrive (another script stops them on the way down).
            const itemOf = (target) => items.find((li) => li.contains(target)) || null;
            const enter = (e) => {
                const li = itemOf(e.target);

                if (li && li !== current) {
                    moveTo(li);
                }
            };

            nav.addEventListener('mouseover', enter);
            nav.addEventListener('focusin', enter);
            nav.addEventListener('mouseleave', () => moveTo(active));
            nav.addEventListener('focusout', (e) => nav.contains(e.relatedTarget) || moveTo(active));

            if (window.ResizeObserver) {
                new ResizeObserver(() => {
                    jump = true;
                    moveTo(current);
                }).observe(nav);
            }

            moveTo(active);
        });
    }

    // Active menu item and menu dialog cards: the primary colour, with the theme's text
    // colour on it.
    if (has('menu-pill') || has('menu-underline') || has('dialog-cards')) {
        const primary = probe('uk-section uk-section-primary');

        if (visible(primary.bg) && primary.text.length >= 3) {
            set('--ehp-accent', primary.bg);
            set('--ehp-on-accent', primary.text);
            body.classList.add('elemen-hp--accent');
        }
    }

    // Dropdowns as glass, or as cards under a capsule (dropbar): the theme's dropdown colour.
    if (has('dropdown-glass') || has('capsule') || has('mcapsule')) {
        const dropdown = probe('uk-navbar-dropdown');

        if (visible(dropdown.bg)) {
            set('--ehp-drop-rgb', dropdown.bg);
        }
    }

    if (!has('glass') && !has('solid')) {
        return;
    }

    const surface = probe(`uk-section uk-section-${tint}`);

    // Not found, or transparent: keep the default (white) tint from the stylesheet.
    if (!visible(surface.bg)) {
        return;
    }

    set('--ehp-rgb', surface.bg);

    // A number, or max(...) in browsers without backdrop blur, which is nearly solid.
    const alpha = parseFloat(getComputedStyle(body).getPropertyValue('--ehp-alpha'));
    const opacity = Number.isNaN(alpha) ? 1 : alpha;

    // Light text on this colour in the theme. A see-through glass shows the page more than
    // the tint, so then the text is left alone.
    if (surface.text.length < 3 || luminance(surface.text) < 0.5 || opacity < 0.5) {
        return;
    }

    body.classList.add('elemen-hp--dark');

    const always = has('always');

    const sync = (bar) => {
        const on = (always || bar.classList.contains('uk-navbar-sticky')) && !has('waiting');

        if (on && !bar.classList.contains('uk-light')) {
            bar.classList.add('uk-light');
            bar.dataset.ehpLight = '';
        } else if (!on && 'ehpLight' in bar.dataset) {
            bar.classList.remove('uk-light');
            delete bar.dataset.ehpLight;
        }
    };

    document.querySelectorAll(within('.uk-navbar-container')).forEach((bar) => {
        syncs.push(() => sync(bar));
        sync(bar);
        new MutationObserver(() => sync(bar)).observe(bar, { attributes: true, attributeFilter: ['class'] });
    });
})();
