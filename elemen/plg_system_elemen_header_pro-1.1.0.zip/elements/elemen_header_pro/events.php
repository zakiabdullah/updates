<?php

/**
 * Header Pro: the navbar as glass or a solid bar (full width or a floating capsule) while
 * it is sticky or always, pill or underline menu items, glass dropdowns and a divider
 * before the header modules. Set in the customizer under Header, after the sticky option.
 *
 * Nothing in YOOtheme's header markup changes. The settings become classes on <body> and
 * CSS custom properties; header-pro.css styles the navbar, its surface while UIkit marks
 * it sticky (.uk-navbar-sticky) or always. header-pro.js takes the colours from the
 * theme's own classes, so they follow the style chosen in the customizer, and switches
 * the menu text to light on dark tints.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

use Joomla\CMS\Document\HtmlDocument;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use YOOtheme\Config;
use YOOtheme\Event;
use YOOtheme\Metadata;

use function YOOtheme\app;

\defined('_JEXEC') or die;

if (!class_exists('ElemenHeaderPro', false)) {
    final class ElemenHeaderPro
    {
        public const STYLES = ['glass', 'solid'];

        public const MENUS = ['pill', 'underline'];

        public const TINTS = ['default', 'muted', 'primary', 'secondary'];

        public const RADIUS = ['pill' => '999px', 'large' => '24px', 'medium' => '14px', 'small' => '8px', 'none' => '0px'];

        /** Settings saved by 0.x under older names, and their names from 1.0. */
        public const RENAMED = [
            'apply'    => 'show_when',
            'width'    => 'capsule_width',
            'gap'      => 'capsule_gap',
            'radius'   => 'capsule_radius',
            'height'   => 'sticky_height',
            'menu'     => 'menu_style',
            'dropdown' => 'dropdown_style',
            'dialog'   => 'dialog_style',
            'mobile'   => 'mobile_apply',
        ];

        /**
         * Settings under their older names take the new names. The defaults only hold the new
         * names, so an older name comes from saved settings and wins; it is then dropped, so
         * the customizer saves the new name only.
         *
         * @param  array<string, mixed>  $settings  ~theme.elemen_header
         *
         * @return array<string, mixed>
         */
        public static function migrate(array $settings): array
        {
            foreach (self::RENAMED as $old => $new) {
                if (array_key_exists($old, $settings)) {
                    $settings[$new] = $settings[$old];
                    unset($settings[$old]);
                }
            }

            return $settings;
        }

        /** Older setting names in the loaded theme settings take the new names. */
        public static function migrateConfig(): void
        {
            $config   = app(Config::class);
            $settings = (array) $config->get('~theme.elemen_header', []);

            if (array_intersect_key($settings, self::RENAMED)) {
                $config->set('~theme.elemen_header', self::migrate($settings));
            }
        }

        /**
         * The customizer fields, keyed by their config path below ~theme.
         *
         * @return array<string, array<string, mixed>>
         */
        public static function fields(): array
        {
            $on      = 'elemen_header.style';
            $glass   = "elemen_header.style == 'glass'";
            $capsule = "elemen_header.style && elemen_header.shape == 'capsule'";

            return [
                'elemen_header.style' => [
                    'label'       => 'Header Pro Style',
                    'description' => 'A glass or solid navbar (Elemen Header Pro), while it is sticky or always. Glass blurs the page behind it. Not with Blend with page content, which inverts its colours.',
                    'type'        => 'select',
                    'options'     => ['None' => '', 'Glass' => 'glass', 'Solid' => 'solid'],
                ],
                'elemen_header.show_when' => [
                    'label'       => 'Show',
                    'description' => 'While sticky needs a sticky navbar, set above.',
                    'type'        => 'select',
                    'options'     => ['While sticky' => 'sticky', 'Always' => 'always'],
                    'show'        => $on,
                ],
                'elemen_header.offset' => [
                    'label'       => 'Start After',
                    'description' => 'Show the surface only once the page is scrolled this far, in pixels, e.g. past a hero image. 0 shows it at once.',
                    'type'        => 'range',
                    'attrs'       => ['min' => 0, 'max' => 1000, 'step' => 20],
                    'show'        => $on,
                ],
                'elemen_header.shape' => [
                    'label'   => 'Shape',
                    'type'    => 'select',
                    'options' => ['Full Width' => 'full', 'Capsule' => 'capsule'],
                    'show'    => $on,
                ],
                'elemen_header.capsule_width' => [
                    'label'       => 'Capsule Width',
                    'description' => 'As wide as the header (its Max Width) or only as wide as the logo, menu and modules.',
                    'type'        => 'select',
                    'options'     => ['Header width' => 'header', 'Fit content' => 'fit'],
                    'show'        => $capsule,
                ],
                'elemen_header.tint' => [
                    'label'       => 'Tint',
                    'description' => 'Colour of the glass or bar, from the theme style. Menu text turns light on dark colours.',
                    'type'        => 'select',
                    'options'     => ['Background' => 'default', 'Muted' => 'muted', 'Primary' => 'primary', 'Secondary' => 'secondary'],
                    'show'        => $on,
                ],
                'elemen_header.opacity' => [
                    'label'       => 'Glass Opacity',
                    'description' => 'How much of the tint covers the page behind, in percent.',
                    'type'        => 'range',
                    'attrs'       => ['min' => 0, 'max' => 100, 'step' => 5],
                    'show'        => $glass,
                ],
                'elemen_header.blur' => [
                    'label'       => 'Glass Blur',
                    'description' => 'How much the page behind is blurred, in pixels.',
                    'type'        => 'range',
                    'attrs'       => ['min' => 0, 'max' => 40, 'step' => 1],
                    'show'        => $glass,
                ],
                'elemen_header.capsule_gap' => [
                    'label'       => 'Capsule Gap',
                    'description' => 'Space around the capsule, in pixels.',
                    'type'        => 'range',
                    'attrs'       => ['min' => 0, 'max' => 40, 'step' => 1],
                    'show'        => $capsule,
                ],
                'elemen_header.capsule_radius' => [
                    'label'   => 'Capsule Corners',
                    'type'    => 'select',
                    'options' => ['Pill' => 'pill', 'Large' => 'large', 'Medium' => 'medium', 'Small' => 'small', 'None' => 'none'],
                    'show'    => $capsule,
                ],
                'elemen_header.sticky_height' => [
                    'label'       => 'Sticky Height',
                    'description' => 'Navbar height while sticky, in pixels; the logo shrinks to fit. 0 keeps the height.',
                    'type'        => 'range',
                    'attrs'       => ['min' => 0, 'max' => 120, 'step' => 2],
                    'show'        => $on,
                ],
                'elemen_header.shadow' => [
                    'label' => 'Effects',
                    'type'  => 'checkbox',
                    'text'  => 'Add a shadow',
                    'show'  => $on,
                ],
                'elemen_header.border' => [
                    'type' => 'checkbox',
                    'text' => 'Add a border',
                    'show' => $on,
                ],
                'elemen_header.animate' => [
                    'type' => 'checkbox',
                    'text' => 'Slide in when it appears',
                    'show' => $on,
                ],
                'elemen_header.menu_style' => [
                    'label'       => 'Menu Style',
                    'description' => "Top-level menu items in the navbar. The active item takes the theme's primary colour.",
                    'type'        => 'select',
                    'options'     => ['Default' => '', 'Pill' => 'pill', 'Underline' => 'underline'],
                ],
                'elemen_header.menu_slide' => [
                    'type' => 'checkbox',
                    'text' => 'Slide the highlight to the item under the pointer',
                    'show' => 'elemen_header.menu_style',
                ],
                'elemen_header.dropdown_style' => [
                    'label'   => 'Dropdowns',
                    'type'    => 'select',
                    'options' => ['Default' => '', 'Glass' => 'glass'],
                ],
                'elemen_header.divider' => [
                    'label' => 'Divider',
                    'type'  => 'checkbox',
                    'text'  => 'Add a divider between the menu and the modules after it',
                ],
                'elemen_header.dialog_style' => [
                    'label'       => 'Menu Dialog',
                    'description' => 'The mobile menu (and the menu dialog, if used): items as rounded cards, the active one in the primary colour, a round close button.',
                    'type'        => 'select',
                    'options'     => ['Default' => '', 'Cards' => 'cards'],
                ],
                'elemen_header.progress' => [
                    'label'       => 'Scroll Progress',
                    'description' => 'A thin bar in the primary colour at the top of the window that fills as visitors scroll.',
                    'type'        => 'select',
                    'options'     => ['None' => '', 'All pages' => 'all', 'Articles only' => 'articles'],
                ],
                'elemen_header.cta_text' => [
                    'label'       => 'Button',
                    'description' => 'A button at the end of the header; empty for none. A language string (e.g. a language override key) is translated.',
                    'attrs'       => ['placeholder' => 'Contact me'],
                    // Multilingual plugins that read this flag add a field per language.
                    'translate'   => true,
                ],
                'elemen_header.cta_link' => [
                    'label'     => 'Button Link',
                    'attrs'     => ['placeholder' => '/contact or https://…'],
                    'show'      => 'elemen_header.cta_text',
                    'translate' => true,
                ],
                'elemen_header.cta_style' => [
                    'label'   => 'Button Style',
                    'type'    => 'select',
                    'options' => ['Primary' => 'primary', 'Secondary' => 'secondary', 'Default' => 'default'],
                    'show'    => 'elemen_header.cta_text',
                ],
                'elemen_header.cta_position' => [
                    'label'   => 'Button Position',
                    'type'    => 'select',
                    'options' => ['Header End' => 'header', 'Navbar End' => 'navbar'],
                    'show'    => 'elemen_header.cta_text',
                ],
                'elemen_header.cta_target' => [
                    'type' => 'checkbox',
                    'text' => 'Open in a new window',
                    'show' => 'elemen_header.cta_text',
                ],
                'elemen_header.cta_mobile' => [
                    'type' => 'checkbox',
                    'text' => 'Show the button in the mobile header',
                    'show' => 'elemen_header.cta_text && mobile.breakpoint',
                ],
                'elemen_header.mobile_apply' => [
                    'label'       => 'Mobile Header',
                    'description' => 'The mobile header gets the same look. If its own navbar is static (under Mobile), it becomes sticky like the navbar above.',
                    'type'        => 'checkbox',
                    'text'        => 'Apply to the mobile header',
                    'show'        => 'mobile.breakpoint',
                ],
                'elemen_header.mobile_shape' => [
                    'label'   => 'Mobile Shape',
                    'type'    => 'select',
                    'options' => ['Same as above' => '', 'Full Width' => 'full', 'Capsule' => 'capsule'],
                    'show'    => "$on && elemen_header.mobile_apply && mobile.breakpoint",
                ],
            ];
        }

        /**
         * Body classes and CSS custom properties for the current settings, or null when off.
         * mobile_sticky: the sticky value for a static mobile navbar, or null to leave it.
         *
         * @param  array<string, mixed>  $theme  the ~theme config
         *
         * @return array{classes: list<string>, css: string, mobile_sticky: int|null}|null
         */
        public static function settings(array $theme): ?array
        {
            $s        = (array) ($theme['elemen_header'] ?? []);
            $style    = in_array($s['style'] ?? '', self::STYLES, true) ? $s['style'] : '';

            // A blended header (difference blend mode) inverts every colour behind and in it,
            // so a glass or solid surface would show inverted: it is left out.
            if (!empty($theme['header']['transparent']) && !empty($theme['header']['blend'])) {
                $style = '';
            }

            $menu     = in_array($s['menu_style'] ?? '', self::MENUS, true) ? $s['menu_style'] : '';
            $dropdown = ($s['dropdown_style'] ?? '') === 'glass';
            $divider  = !empty($s['divider']);
            $cards    = ($s['dialog_style'] ?? '') === 'cards';
            $progress = in_array($s['progress'] ?? '', ['all', 'articles'], true) ? $s['progress'] : '';
            $cta      = trim((string) ($s['cta_text'] ?? '')) !== '';
            $always   = $style !== '' && ($s['show_when'] ?? '') === 'always';
            $extras   = $menu !== '' || $dropdown || $divider || $cards || $cta;

            // Articles only: a single article page (Joomla's article view).
            if ($progress === 'articles' && !self::isArticle()) {
                $progress = '';
            }

            $deskSticky   = (int) ($theme['navbar']['sticky'] ?? 0);
            $mobileSticky = (int) ($theme['mobile']['navbar']['sticky'] ?? 0);
            $hasMobile    = !empty($s['mobile_apply']) && !empty($theme['mobile']['breakpoint']);

            // The surface shows always, or while the navbar is sticky.
            $desktop = $extras || ($style !== '' && ($always || $deskSticky));
            $mobile  = $hasMobile && ($extras || ($style !== '' && ($always || $mobileSticky || $deskSticky)));

            if (!$desktop && !$mobile && $progress === '') {
                return null;
            }

            $tint    = in_array($s['tint'] ?? '', self::TINTS, true) ? $s['tint'] : 'default';
            $height  = max(0, min(200, (int) ($s['sticky_height'] ?? 0)));
            $offset  = $style !== '' ? max(0, min(5000, (int) ($s['offset'] ?? 0))) : 0;
            $capsule = $style !== '' && ($s['shape'] ?? '') === 'capsule';
            $mShape  = in_array($s['mobile_shape'] ?? '', ['full', 'capsule'], true) ? $s['mobile_shape'] : ($capsule ? 'capsule' : 'full');
            $mCapsule = $style !== '' && $mobile && $mShape === 'capsule';

            $classes = array_values(array_filter([
                'elemen-hp',
                $desktop ? 'elemen-hp--desktop' : '',
                $mobile ? 'elemen-hp--mobile' : '',
                $style !== '' ? "elemen-hp--$style" : '',
                $style !== '' ? "elemen-hp--tint-$tint" : '',
                $style !== '' ? 'elemen-hp--surface' : '',
                $always ? 'elemen-hp--always' : '',
                $offset ? 'elemen-hp--waiting' : '',
                $capsule ? 'elemen-hp--capsule' : '',
                $mCapsule ? 'elemen-hp--mcapsule' : '',
                ($capsule || $mCapsule) && ($s['capsule_width'] ?? '') === 'fit' ? 'elemen-hp--fit' : '',
                $style !== '' && !empty($s['animate']) ? 'elemen-hp--animate' : '',
                $style !== '' && $height ? 'elemen-hp--shrink' : '',
                $style !== '' && !empty($s['shadow']) ? 'elemen-hp--shadow' : '',
                $style !== '' && !empty($s['border']) ? 'elemen-hp--border' : '',
                $menu !== '' ? "elemen-hp--menu-$menu" : '',
                $menu !== '' && !empty($s['menu_slide']) ? 'elemen-hp--menu-slide' : '',
                $dropdown ? 'elemen-hp--dropdown-glass' : '',
                $divider ? 'elemen-hp--divider' : '',
                $cards ? 'elemen-hp--dialog-cards' : '',
                $progress !== '' ? 'elemen-hp--progress' : '',
            ]));

            $vars = [
                '--ehp-opacity' => round(max(0, min(100, (int) ($s['opacity'] ?? 70))) / 100, 2),
                '--ehp-blur'    => max(0, min(60, (int) ($s['blur'] ?? 16))) . 'px',
                '--ehp-gap'     => max(0, min(60, (int) ($s['capsule_gap'] ?? 12))) . 'px',
                '--ehp-radius'  => self::RADIUS[$s['capsule_radius'] ?? 'pill'] ?? self::RADIUS['pill'],
                '--ehp-height'  => $height . 'px',
                '--ehp-offset'  => $offset . 'px',
            ];

            $css = ':root{' . implode(';', array_map(static fn ($k, $v) => "$k:$v", array_keys($vars), $vars)) . '}';

            // A static mobile navbar follows the sticky desktop one, so the surface shows there
            // too while sticky.
            $follow = $mobile && $style !== '' && !$always && !$mobileSticky && $deskSticky ? $deskSticky : null;

            return ['classes' => $classes, 'css' => $css, 'mobile_sticky' => $follow];
        }

        /** A single article page: Joomla's article view. */
        public static function isArticle(): bool
        {
            $input = Factory::getApplication()->getInput();

            return $input->getCmd('option') === 'com_content' && $input->getCmd('view') === 'article';
        }

        /**
         * The header button as modules, built like YOOtheme's own header modules (search,
         * social icons), so the theme renders them in its header positions.
         *
         * @param  array<string, mixed>  $theme  the ~theme config
         *
         * @return list<object>
         */
        public static function ctaModules(array $theme): array
        {
            $s    = (array) ($theme['elemen_header'] ?? []);
            $text = trim((string) ($s['cta_text'] ?? ''));

            if ($text === '') {
                return [];
            }

            $style = in_array($s['cta_style'] ?? '', ['primary', 'secondary', 'default'], true) ? $s['cta_style'] : 'primary';
            $link  = trim((string) ($s['cta_link'] ?? '')) ?: '#';
            $link  = str_starts_with($link, 'index.php') ? Route::_($link) : $link;
            $html  = '<a class="uk-button uk-button-' . $style . ' elemen-hp-cta" href="' . htmlspecialchars($link, ENT_QUOTES, 'UTF-8') . '"'
                . (!empty($s['cta_target']) ? ' target="_blank" rel="noopener"' : '') . '>'
                . htmlspecialchars(Text::_($text), ENT_QUOTES, 'UTF-8') . '</a>';

            $navbar    = ($s['cta_position'] ?? '') === 'navbar';
            $positions = [$navbar ? 'navbar' : 'header'];

            if (!empty($s['cta_mobile']) && !empty($theme['mobile']['breakpoint'])) {
                $positions[] = $navbar ? 'navbar-mobile' : 'header-mobile';
            }

            return array_map(static fn (string $position): object => (object) [
                'id'        => "elemen-cta-$position",
                'name'      => "elemen-cta-$position",
                'title'     => '',
                'module'    => 'mod_custom',
                'position'  => $position,
                'content'   => $html,
                'showtitle' => 0,
                'menuid'    => 0,
                'style'     => null,
                'params'    => json_encode(['layout' => 'blank']),
            ], $positions);
        }

        public static function assetUrl(string $file): string
        {
            $assets = __DIR__ . '/assets';

            return Uri::root(true) . '/' . str_replace('\\', '/', substr($assets, strlen(JPATH_ROOT) + 1)) . "/{$file}?v=" . @filemtime("{$assets}/{$file}");
        }

        /** On the site, once Joomla has dispatched and YOOtheme has set its body classes. */
        public static function apply(): void
        {
            $app = Factory::getApplication();

            if (!$app->isClient('site') || !$app->getDocument() instanceof HtmlDocument) {
                return;
            }

            $config = app(Config::class);

            if (!$config->get('theme.active')) {
                return;
            }

            $settings = self::settings((array) $config->get('~theme'));

            if ($settings === null) {
                return;
            }

            $config->set('~theme.body_class', array_merge((array) $config->get('~theme.body_class', []), $settings['classes']));

            // Before the template renders the mobile header, which reads this.
            if ($settings['mobile_sticky'] !== null) {
                $config->set('~theme.mobile.navbar.sticky', $settings['mobile_sticky']);
            }

            $metadata = app(Metadata::class);
            $metadata->set('style:elemen-header-pro', ['href' => self::assetUrl('header-pro.css')]);
            // Inline CSS straight to Joomla: YOOtheme's Metadata passes only files and scripts
            // on to the Web Asset Manager, so an inline style there never reaches the page.
            $app->getDocument()->getWebAssetManager()->addInlineStyle($settings['css'], ['name' => 'elemen-header-pro-vars']);
            $metadata->set('script:elemen-header-pro', ['src' => self::assetUrl('header-pro.js'), 'defer' => true]);
        }
    }
}

// Older setting names, right after YOOtheme has loaded the theme settings: for the page and
// for the customizer, which then saves the new names.
Event::on('theme.init', [ElemenHeaderPro::class, 'migrateConfig'], 50);

// YOOtheme sets ~theme.body_class on onAfterDispatch (default priority, and it replaces
// the list); this runs afterwards and adds to it. Joomla runs higher priorities first.
Factory::getApplication()->getDispatcher()->addListener('onAfterDispatch', static function (): void {
    ElemenHeaderPro::apply();
}, -100);

// The header button: added to the module list before YOOtheme's own listener (priority
// -10), which then prepares it like its search and social modules.
Factory::getApplication()->getDispatcher()->addListener('onAfterCleanModuleList', static function ($event): void {
    $app = Factory::getApplication();

    if (!$app->isClient('site') || !$app->getDocument() instanceof HtmlDocument || !app(Config::class)->get('theme.active')) {
        return;
    }

    $buttons = ElemenHeaderPro::ctaModules((array) app(Config::class)->get('~theme'));

    if ($buttons) {
        $event->setArgument('modules', array_merge($event->getArgument('modules', []), $buttons));
    }
}, 0);

// The customizer: the Header panel gets the fields right after its sticky option. Runs
// after YOOtheme has loaded the panels (priority 0) and before it sends them (-20).
Event::on('customizer.init', static function (): void {
    $config = app(Config::class);
    $fields = (array) $config->get('customizer.panels.header.fields');

    if (!$fields || isset($fields['elemen_header.style'])) {
        return;
    }

    $out = [];

    foreach ($fields as $name => $field) {
        $out[$name] = $field;

        if ($name === 'navbar.sticky') {
            $out += ElemenHeaderPro::fields();
        }
    }

    // Without the sticky option (another YOOtheme version), at the end of the panel.
    $config->set('customizer.panels.header.fields', $out + ElemenHeaderPro::fields());
}, -10);

return [];
