<?php

/**
 * Timeline Pro item: marker, card and, in the alternating layout, the date opposite.
 * Settings come from the parent element ($element).
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<string, mixed> $element
 * @var int|null $index
 */

\defined('_JEXEC') or die;

$has = static fn ($value): bool => trim((string) $value) !== '';

// A Lucide icon from Icon Pro's "Lucide Icon" field, when Icon Pro is installed.
$lucide = static function ($name, int $size): string {
    $file = JPATH_PLUGINS . '/system/elemen_icon_pro/elements/elemen_icon_pro/icons/Icons.php';

    if (trim((string) $name) === '' || !is_file($file)) {
        return '';
    }

    require_once $file;

    return \Elemen\IconPro\Icons::svg((string) $name, ['size' => $size]);
};

if (!$has($props['title']) && !$has($props['content']) && !$has($props['meta']) && !$props['image']) {
    return;
}

$index = (int) ($index ?? 0);
$color = static fn ($value): string => preg_match('/^[#(),.%\w\s-]+$/', trim((string) $value)) ? trim((string) $value) : '';

// Even items sit left of the line in the alternating layout, odd items right.
$side = $index % 2 === 0 ? 'left' : 'right';

// Marker
$markerColor = $color($props['marker_color']) ?: ($element['marker_color'] === 'custom' ? $color($element['marker_color_custom']) : '');
$markerClass = !$markerColor ? 'uk-text-' . ($element['marker_color'] && $element['marker_color'] !== 'custom' ? $element['marker_color'] : 'primary') : '';
$markerInner = '';

if ($element['marker'] === 'number') {
    $markerInner = '<span>' . ($index + 1) . '</span>';
} elseif ($element['marker'] === 'icon') {
    // The item's own icon (Lucide, then UIkit) before the element's default (Lucide, then UIkit).
    $iconSize = $element['marker_size'] === 'large' ? 24 : ($element['marker_size'] === 'small' ? 16 : 20);
    $svg      = $lucide($props['icon_lucide'] ?? '', $iconSize) ?: ($props['icon'] ? '' : $lucide($element['marker_icon_lucide'] ?? '', $iconSize));

    if ($svg) {
        $markerInner = '<span>' . $svg . '</span>';
    } elseif ($icon = $props['icon'] ?: $element['marker_icon']) {
        $markerInner = '<span uk-icon="icon: ' . htmlspecialchars((string) $icon) . '; width: ' . $iconSize . '"></span>';
    }
}

$markerEl = $this->el('div', [
    'class'       => ['el-marker tl-marker', $markerClass],
    'style'       => $markerColor ? "color: {$markerColor}" : false,
    'aria-hidden' => 'true',
]);

// Date
$dateClass = $element['date_style'] === 'label'
    ? 'uk-label'
    : 'uk-' . ($element['date_style'] ?: 'text-meta') . ($element['date_color'] ? ' uk-text-' . $element['date_color'] : '');
$date = $has($props['meta']) ? '<div class="el-meta tl-date"><span class="' . $dateClass . ' uk-margin-remove">' . $props['meta'] . '</span></div>' : '';

// Image
$image = '';

if ($props['image']) {
    $image = $this->el('image', [
        'class'     => ['el-image tl-image', 'uk-border-' . $element['image_border'] => (bool) $element['image_border']],
        'src'       => $props['image'],
        'alt'       => $props['image_alt'],
        'width'     => $element['image_width'],
        'height'    => $element['image_height'],
        'loading'   => 'lazy',
        'thumbnail' => true,
    ])->render([]);
    $image = '<div class="' . ($element['image_position'] === 'bottom' ? 'uk-margin-top' : 'uk-margin-bottom') . '">' . $image . '</div>';
}

// Title, content, link
$titleTag = $element['title_element'] ?: 'h3';
$title    = $has($props['title'])
    ? '<' . $titleTag . ' class="el-title tl-title uk-margin-remove-top uk-margin-small-bottom'
        . ($element['title_style'] ? ' uk-' . $element['title_style'] : '')
        . ($element['title_color'] ? ' uk-text-' . $element['title_color'] : '') . '">' . $props['title'] . '</' . $titleTag . '>'
    : '';
$content = $has($props['content'])
    ? '<div class="el-content tl-content uk-panel' . ($element['content_style'] ? ' uk-' . $element['content_style'] : '') . '">' . $props['content'] . '</div>'
    : '';
$link = '';

if ($props['link'] && $has($props['link_text'])) {
    $style = $element['link_style'] ?: 'text';
    $link  = $this->el('a', [
        'class'  => [$style === 'link' ? 'el-link uk-link' : "el-link uk-button uk-button-{$style}"],
        'href'   => ['{link}'],
        'target' => $element['link_target'] ? '_blank' : false,
    ])->render($props, $props['link_text']);
    $link = '<div class="uk-margin-small-top">' . $link . '</div>';
}

// Card
$cardStyle = $element['card_style'];
$cardEl    = $this->el('div', [
    'class' => [
        'el-card tl-card',
        'uk-card uk-card-body uk-card-' . $cardStyle => in_array($cardStyle, ['default', 'primary', 'secondary', 'hover'], true),
        'uk-card-' . $element['card_padding'] => $cardStyle && $cardStyle !== 'muted' && $element['card_padding'],
        'uk-background-muted tl-card-muted' => $cardStyle === 'muted',
        'uk-padding-' . $element['card_padding'] => $cardStyle === 'muted' && $element['card_padding'],
        'uk-padding' => $cardStyle === 'muted' && !$element['card_padding'],
    ],
]);

$body = $cardEl($props,
    '<div class="tl-date-in-card">' . $date . '</div>'
    . ($element['image_position'] !== 'bottom' ? $image : '')
    . $title . $content
    . ($element['image_position'] === 'bottom' ? $image : '')
    . $link
);

$el = $this->el('div', [
    'class' => ['el-item tl-item', "tl-side-{$side}"],
]);

?>
<?= $el($props, $attrs) ?>
    <div class="tl-opposite"><?= $date ?></div>
    <?= $markerEl($props, $markerInner) ?>
    <div class="tl-body"><?= $body ?></div>
<?= $el->end() ?>
