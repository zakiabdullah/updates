<?php

// Based on the YOOtheme Pro 5.0.56 Headline element; margins follow the layout.

\defined('_JEXEC') or die;

if ($props['image']) {
    $src   = $props['image'];
    $focal = $props['image_focal_point'];
    $media = include "{$__dir}/template-image.php";
} elseif ($props['icon']) {
    $media = include "{$__dir}/template-icon.php";
} else {
    return;
}

$media->attr([

    'class' => [
        'el-image',
        'uk-margin-{image_margin}-bottom {@layout: stacked}',
        'uk-margin-{image_margin}-right {@layout: left}',
        'uk-margin-{image_margin}-left {@layout: right}',
    ],

]);

if ($props['image']) {
    $media->attr('class', ['uk-border-{image_border}']);
}

echo $media($props, '');
