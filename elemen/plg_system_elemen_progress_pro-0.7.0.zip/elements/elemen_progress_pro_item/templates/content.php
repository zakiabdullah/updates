<?php

/**
 * Plain HTML stored in the article text, used by search and when the builder is off.
 *
 * @var array<string, mixed> $props
 */

\defined('_JEXEC') or die;

?>
<?= $props['title'] ?><?php if ($props['value_text'] || $props['value'] !== '') : ?>: <?= $props['value_text'] ?: $props['value'] ?><?php endif ?>
<?php if ($props['content']) : ?>
<?= $props['content'] ?>
<?php endif ?>
