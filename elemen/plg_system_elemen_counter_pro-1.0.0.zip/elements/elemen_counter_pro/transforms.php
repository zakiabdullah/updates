<?php

/**
 * Builder transforms for Counter Pro.
 *
 * Counter Pro 0.3 held one counter in the element itself. From 0.4 counters are items;
 * when an older layout loads, its counter becomes the first item, in a single column,
 * so the page looks the same and the editor shows the item.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

return [
    'preload' => static function (object $node): void {
        if (($node->type ?? '') !== 'elemen_counter_pro' || !empty($node->children)) {
            return;
        }

        $props = (array) ($node->props ?? []);
        $keys  = ['number', 'number_start', 'prefix', 'suffix', 'title', 'meta', 'content', 'image', 'image_alt', 'icon', 'link', 'link_text'];
        $item  = array_filter(
            array_intersect_key($props, array_flip($keys)),
            static fn ($value): bool => $value !== '' && $value !== null && !is_array($value) && !is_object($value)
        );

        if (!isset($item['number']) && !isset($item['title'])) {
            return;
        }

        $node->props = array_diff_key($props, array_flip($keys));
        $node->props['grid_default'] = '1';
        $node->props['grid_small']   = '';
        $node->props['grid_medium']  = '';
        $node->props['grid_large']   = '';

        // Dynamic content mapped to the old fields moves along with them.
        $source = null;

        if (isset($node->source->props)) {
            $mapped = array_intersect_key((array) $node->source->props, array_flip($keys));

            if ($mapped) {
                // The item gets the same query, so the mapped fields keep resolving.
                $source = (object) (['props' => (object) $mapped] + array_diff_key((array) $node->source, ['props' => 1]));
                $node->source->props = (object) array_diff_key((array) $node->source->props, $mapped);
            }
        }

        $child = (object) ['type' => 'elemen_counter_pro_item', 'props' => $item];

        if ($source) {
            $child->source = $source;
        }

        $node->children = [$child];
    },
];
