<?php

/**
 * Renamed settings of Counter Pro. Layouts saved with the old values load with the new
 * ones (see the plugin's bootstrap).
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

return [
    'values' => [
        // Number Format "Malay" is now "Words", in the page's language.
        'number_format' => ['malay' => 'words'],
    ],
];
