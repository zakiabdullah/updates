<?php

/**
 * Counter Pro item: one number that counts up when it scrolls into view. Content comes
 * from the item, settings from the parent element ($element).
 *
 * The final number is in the HTML, so visitors without JavaScript, screen readers and
 * search engines get it; the script counts up to it on screen.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<string, mixed> $element
 * @var int|null $index
 * @var string $__dir
 */

use Joomla\CMS\Factory;

\defined('_JEXEC') or die;

// Settings from the element, content from this item.
$content = ['number', 'number_start', 'prefix', 'suffix', 'title', 'meta', 'content', 'image', 'image_alt', 'icon', 'icon_lucide', 'link', 'link_text'];
$color   = static fn ($value): string => preg_match('/^[#(),.%\w\s-]+$/', trim((string) $value)) ? trim((string) $value) : '';
$own     = $color($props['number_color'] ?? '');
$props   = array_merge((array) ($element ?? []), array_intersect_key($props, array_flip($content)));
$delay   = (int) ($index ?? 0) * (int) ($props['stagger'] ?? 0);

if ($own) {
    $props['number_color']        = 'custom';
    $props['number_color_custom'] = $own;
}

$decimalMark = $props['decimal_mark'] === ',' ? ',' : '.';
$separator   = in_array($props['separator'], [',', '.', ' ', ''], true) ? $props['separator'] : ',';

// Accepts "1,250", "1 250", "99.5" or, with a comma decimal mark, "99,5".
$parse = static function ($value) use ($decimalMark): ?array {
    $value = str_replace([' ', "\u{00A0}"], '', trim(strip_tags((string) $value)));

    if ($decimalMark === ',') {
        $value = str_replace(['.', ','], ['', '.'], $value);
    } else {
        $value = str_replace(',', '', $value);
    }

    if ($value === '' || !is_numeric($value)) {
        return null;
    }

    $dot = strpos($value, '.');

    return [(float) $value, $dot === false ? 0 : strlen($value) - $dot - 1];
};

$number = $parse($props['number']);
$raw    = trim((string) $props['number']);

if ($raw === '' && trim((string) $props['title']) === '') {
    return;
}

$valueHtml = $raw;
$counting  = false;

// Short forms: 1.3K / 1.3 million. Words come from the plugin's language files, in the
// page's language. The script uses the same rules (and words) while counting.
$compact         = in_array($props['number_format'] ?? '', ['short', 'words'], true) ? $props['number_format'] : '';
$compactDecimals = ($props['decimals'] ?? '') !== '' && $props['decimals'] !== null ? (int) $props['decimals'] : 1;
$units           = ['short' => [[1e12, 'T'], [1e9, 'B'], [1e6, 'M'], [1e3, 'K']], 'words' => []];

if ($compact === 'words') {
    $language = Factory::getApplication()->getLanguage();
    $language->load('plg_system_elemen_counter_pro', JPATH_ADMINISTRATOR);

    // A no-break space keeps "1.3 million" on one line.
    foreach (['TRILLION' => 1e12, 'BILLION' => 1e9, 'MILLION' => 1e6, 'THOUSAND' => 1e3] as $key => $size) {
        $units['words'][] = [$size, "\u{00A0}" . $language->_('PLG_SYSTEM_ELEMEN_COUNTER_PRO_' . $key)];
    }
}
$format = static function (float $n, int $decimals) use ($compact, $compactDecimals, $units, $decimalMark, $separator): string {
    foreach ($compact ? $units[$compact] : [] as [$size, $suffix]) {
        if (abs($n) >= $size) {
            $short = number_format(round($n / $size, $compactDecimals), $compactDecimals, $decimalMark, '');

            return ($compactDecimals ? rtrim(rtrim($short, '0'), $decimalMark) : $short) . $suffix;
        }
    }

    return number_format($n, $decimals, $decimalMark, $separator);
};

if ($number) {
    [$end, $endDecimals] = $number;
    $start    = $parse($props['number_start'])[0] ?? 0.0;
    $decimals = $props['decimals'] !== '' && $props['decimals'] !== null ? (int) $props['decimals'] : $endDecimals;
    $final    = $format($end, $decimals);
    $counting = $start != $end;

    $valueHtml = $counting
        ? '<span class="uk-hidden-visually">' . $final . '</span>'
            . '<span class="cp-value" aria-hidden="true"'
            . ' data-cp-start="' . $start . '" data-cp-end="' . $end . '" data-cp-decimals="' . $decimals . '"'
            . ' data-cp-sep="' . htmlspecialchars($separator) . '" data-cp-dec="' . $decimalMark . '"'
            . ($compact ? ' data-cp-compact="' . $compact . '" data-cp-cdec="' . $compactDecimals . '"' : '')
            . ($compact === 'words' ? ' data-cp-words="' . htmlspecialchars((string) json_encode(array_column($units['words'], 1), JSON_UNESCAPED_UNICODE), ENT_QUOTES) . '"' : '')
            . ' data-cp-duration="' . (int) ($props['duration'] ?: 2000) . '" data-cp-easing="' . htmlspecialchars((string) ($props['easing'] ?: 'out')) . '"'
            . ($props['repeat'] ? ' data-cp-repeat="true"' : '')
            . ($delay ? ' data-cp-delay="' . $delay . '"' : '')
            . (($props['count_style'] ?? '') === 'odometer' ? ' data-cp-style="odometer"' : '')
            . '>' . $final . '</span>'
        : $final;
}

// Number colors.
$vars = [];

if ($props['number_color'] === 'custom' && $color($props['number_color_custom'])) {
    $vars[] = '--cp-color: ' . $color($props['number_color_custom']);
}

if ($props['number_color'] === 'gradient') {
    $color($props['number_gradient_start']) && $vars[] = '--cp-from: ' . $color($props['number_gradient_start']);
    $color($props['number_gradient_end']) && $vars[] = '--cp-to: ' . $color($props['number_gradient_end']);
}

$affix = static fn (string $class, $text): string => trim((string) $text) === ''
    ? ''
    : '<span class="' . $class . '">' . $text . '</span>';

$numberEl = $this->el('div', [

    'class' => [
        'el-number cp-number',
        'uk-{number_style}',
        'uk-font-{number_font_family}',
        'uk-text-{0}' => !in_array($props['number_color'], ['', 'custom', 'gradient'], true) ? $props['number_color'] : '',
        'cp-color-custom' => $props['number_color'] === 'custom',
        'cp-gradient' => $props['number_color'] === 'gradient',
        'cp-affix-{affix_style}',
        'uk-margin-remove',
    ],

    'style' => $vars ? implode('; ', $vars) : false,

]);

$titleEl = $this->el(in_array($props['title_element'], ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'div'], true) ? $props['title_element'] : 'div', [

    'class' => [
        'el-title cp-title',
        'uk-{title_style}',
        'uk-text-{title_color}',
        'uk-margin-small-top uk-margin-remove-bottom',
    ],

]);

$metaEl = $this->el('div', [

    'class' => [
        'el-meta cp-meta',
        'uk-{meta_style}',
        'uk-text-{meta_color}',
        $props['meta_position'] === 'below' ? 'uk-margin-xsmall-top' : 'uk-margin-xsmall-bottom',
    ],

]);

$contentEl = $this->el('div', [

    'class' => [
        'el-content cp-content uk-panel',
        'uk-{content_style}',
        'uk-margin-small-top',
    ],

]);

// Box
$box = $props['box_style'] ? $this->el('div', [

    'class' => [
        'uk-card uk-card-{0}' => str_starts_with($props['box_style'], 'card-') ? substr($props['box_style'], 5) : '',
        'uk-card-body {@box_style: card-.*}',
        'uk-card-{box_padding} {@box_style: card-.*}',
        'uk-tile uk-tile-muted {@box_style: tile-muted}',
        'uk-padding-{box_padding} {@box_style: tile-muted}',
        'uk-height-1-1',
    ],

]) : null;

// A link without text links the whole counter.
$wrapLink = $props['link'] && trim((string) $props['link_text']) === '';

$el = $this->el($wrapLink ? 'a' : 'div', [

    'class' => [
        'el-item elemen-counter-pro',
        'uk-height-1-1 {@grid_match}',
        'uk-link-toggle' => $wrapLink,
        'uk-display-block' => $wrapLink,
    ],

    'href'   => $wrapLink ? ['{link}'] : false,
    'target' => $wrapLink ? ['_blank {@link_target}'] : false,

]);

$button = $props['link'] && !$wrapLink ? $this->el('a', [

    'class' => [
        'el-link',
        'uk-button uk-button-{link_style} {@link_style: default|primary|secondary|text}',
        'uk-link {@link_style: link}',
    ],

    'href'   => ['{link}'],
    'target' => ['_blank {@link_target}'],

]) : null;

$media = $this->render("{$__dir}/template-media", compact('props'));
$side  = $media && $props['layout'] !== 'stacked';

$meta    = trim((string) $props['meta']) !== '' ? $metaEl($props, $props['meta']) : '';
$title   = trim((string) $props['title']) !== '' ? $titleEl($props, $props['title']) : '';
$content = trim((string) $props['content']) !== '' ? $contentEl($props, $props['content']) : '';
$numberHtml = $raw !== '' ? $numberEl($props, $affix('cp-prefix', $props['prefix']) . $valueHtml . $affix('cp-suffix', $props['suffix'])) : '';

$body = ($props['meta_position'] !== 'below' ? $meta : '')
    . $numberHtml
    . $title
    . ($props['meta_position'] === 'below' ? $meta : '')
    . $content
    . ($button ? '<div class="uk-margin-small-top">' . $button($props, $props['link_text']) . '</div>' : '');

?>
<?= $el($props, $attrs) ?>

    <?php if ($box) : ?>
    <?= $box($props) ?>
    <?php endif ?>

        <?php if ($side) : ?>
        <div class="uk-flex uk-flex-<?= $props['image_vertical_align'] === 'middle' ? 'middle' : 'top' ?>">
            <?php if ($props['layout'] === 'left') : ?><div class="uk-flex-none"><?= $media ?></div><?php endif ?>
            <div class="uk-flex-1 uk-width-expand"><?= $body ?></div>
            <?php if ($props['layout'] === 'right') : ?><div class="uk-flex-none uk-flex-last"><?= $media ?></div><?php endif ?>
        </div>
        <?php else : ?>
            <?php if ($media) : ?><div><?= $media ?></div><?php endif ?>
            <?= $body ?>
        <?php endif ?>

    <?php if ($box) : ?>
    <?= $box->end() ?>
    <?php endif ?>

<?= $el->end() ?>
