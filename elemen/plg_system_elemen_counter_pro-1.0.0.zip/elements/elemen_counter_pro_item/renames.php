<?php

/**
 * Renamed settings of the Counter Pro item. Layouts saved with the old names load with the
 * new ones, dynamic content mappings included (see the plugin's bootstrap).
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

return [
    'props' => [
        'color' => 'number_color',
    ],
];
