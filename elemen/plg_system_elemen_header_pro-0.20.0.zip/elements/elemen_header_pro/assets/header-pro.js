/*
 * Elemen Header Pro: takes colours from the theme style and keeps the menu readable.
 *
 * Colours come from hidden probes with the theme's own classes, so they follow the
 * customizer: the tint is the background of a uk-section-{default|muted|primary|secondary}
 * section, the active menu item uses the primary section's background and text colour,
 * and glass dropdowns the navbar dropdown's background.
 *
 * When the theme uses light text on the tint, the navbar gets uk-light (UIkit's light
 * text) while its surface shows: while sticky, or always. It loses it again afterwards,
 * unless it had it before.
 */
(() => {
    const body = document.body;
    const has = (name) => body.classList.contains(`elemen-hp--${name}`);
    const tint = (body.className.match(/\belemen-hp--tint-(\w+)/) || [])[1] || 'default';
    const parse = (value) => (value.match(/[\d.]+/g) || []).map(Number);
    const visible = (rgb) => rgb.length >= 3 && rgb[3] !== 0;

    const probe = (className) => {
        const el = document.createElement('div');
        el.className = className;
        el.style.cssText = 'position:absolute;width:0;height:0;padding:0;overflow:hidden;visibility:hidden';
        body.appendChild(el);
        const style = getComputedStyle(el);
        const colors = { bg: parse(style.backgroundColor), text: parse(style.color) };
        el.remove();

        return colors;
    };

    const luminance = (rgb) => {
        const [r, g, b] = rgb.slice(0, 3)
            .map((v) => v / 255)
            .map((v) => (v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4));

        return 0.2126 * r + 0.7152 * g + 0.0722 * b;
    };

    const set = (name, rgb) => body.style.setProperty(name, rgb.slice(0, 3).join(' '));

    // Scroll progress: a bar in the primary colour, scaled to how far the page is read.
    if (has('progress')) {
        const bar = document.createElement('div');
        bar.className = 'elemen-hp-progress uk-background-primary';
        bar.setAttribute('aria-hidden', 'true');
        body.appendChild(bar);

        let queued = false;
        const update = () => {
            queued = false;
            const max = document.documentElement.scrollHeight - window.innerHeight;
            bar.style.transform = `scaleX(${max > 0 ? Math.min(1, Math.max(0, window.scrollY / max)) : 0})`;
        };
        const queue = () => {
            if (!queued) {
                queued = true;
                requestAnimationFrame(update);
            }
        };

        window.addEventListener('scroll', queue, { passive: true });
        window.addEventListener('resize', queue);
        update();
    }

    // Active menu item and menu dialog cards: the primary colour, with the theme's text
    // colour on it.
    if (has('menu-pill') || has('menu-underline') || has('dialog-cards')) {
        const primary = probe('uk-section uk-section-primary');

        if (visible(primary.bg) && primary.text.length >= 3) {
            set('--ehp-accent', primary.bg);
            set('--ehp-on-accent', primary.text);
            body.classList.add('elemen-hp--accent');
        }
    }

    if (has('dropdown-glass')) {
        const dropdown = probe('uk-navbar-dropdown');

        if (visible(dropdown.bg)) {
            set('--ehp-drop-rgb', dropdown.bg);
        }
    }

    if (!has('glass') && !has('solid')) {
        return;
    }

    const surface = probe(`uk-section uk-section-${tint}`);

    // Not found, or transparent: keep the default (white) tint from the stylesheet.
    if (!visible(surface.bg)) {
        return;
    }

    set('--ehp-rgb', surface.bg);

    // A number, or max(...) in browsers without backdrop blur, which is nearly solid.
    const alpha = parseFloat(getComputedStyle(body).getPropertyValue('--ehp-alpha'));
    const opacity = Number.isNaN(alpha) ? 1 : alpha;

    // Light text on this colour in the theme. A see-through glass shows the page more than
    // the tint, so then the text is left alone.
    if (surface.text.length < 3 || luminance(surface.text) < 0.5 || opacity < 0.5) {
        return;
    }

    body.classList.add('elemen-hp--dark');

    const always = has('always');
    const headers = [
        has('desktop') && '.tm-header',
        has('mobile') && '.tm-header-mobile',
    ].filter(Boolean);

    const sync = (bar) => {
        const on = always || bar.classList.contains('uk-navbar-sticky');

        if (on && !bar.classList.contains('uk-light')) {
            bar.classList.add('uk-light');
            bar.dataset.ehpLight = '';
        } else if (!on && 'ehpLight' in bar.dataset) {
            bar.classList.remove('uk-light');
            delete bar.dataset.ehpLight;
        }
    };

    document.querySelectorAll(headers.map((h) => `${h} .uk-navbar-container`).join(',') || ':not(*)').forEach((bar) => {
        sync(bar);
        new MutationObserver(() => sync(bar)).observe(bar, { attributes: true, attributeFilter: ['class'] });
    });
})();
