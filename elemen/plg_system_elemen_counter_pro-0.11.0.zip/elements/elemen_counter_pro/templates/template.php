<?php

/**
 * Counter Pro: a grid of numbers that count up when they scroll into view.
 * Each item is rendered by elemen_counter_pro_item with this element's settings.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var \YOOtheme\Builder $builder
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<int, object> $children
 */

use Joomla\CMS\Uri\Uri;
use YOOtheme\Metadata;

use function YOOtheme\app;

\defined('_JEXEC') or die;

$items = [];

foreach ($children as $i => $child) {
    $html = (string) $builder->render($child, ['element' => $props, 'index' => $i]);

    if (trim($html) !== '') {
        $items[] = $html;
    }
}

if (!$items) {
    return;
}

// Assets. The URL is worked out from this file's location, so it follows the plugin folder.
$assets   = \dirname(__DIR__) . '/assets';
$assetUrl = static fn (string $file): string => Uri::root(true) . '/'
    . str_replace('\\', '/', substr($assets, strlen(JPATH_ROOT) + 1)) . "/{$file}?v=" . @filemtime("{$assets}/{$file}");
$metadata = app(Metadata::class);

$metadata->set('style:elemen-counter-pro', ['href' => $assetUrl('counter-pro.css')]);
$metadata->set('script:elemen-counter-pro', ['src' => $assetUrl('counter-pro.js'), 'defer' => true]);

// Columns: "expand" shares the row equally, whatever the number of items.
$width = static fn ($value, string $breakpoint = ''): string => $value === '' || $value === null
    ? ''
    : ($value === 'expand' ? 'uk-child-width-expand' : "uk-child-width-1-{$value}") . $breakpoint;

$el = $this->el('div', [
    'class' => ['elemen-counter-pro-grid'],
]);

$grid = $this->el('div', [

    'class' => [
        $width($props['grid_default'] ?: '1'),
        $width($props['grid_small'], '@s'),
        $width($props['grid_medium'], '@m'),
        $width($props['grid_large'], '@l'),
        'uk-grid-column-{grid_column_gap}',
        'uk-grid-row-{grid_row_gap}',
        'uk-grid-match {@grid_match}',
    ],

    'uk-grid' => true,

]);

?>
<?= $el($props, $attrs) ?>
    <?= $grid($props) ?>
        <?php foreach ($items as $html) : ?>
        <div><?= $html ?></div>
        <?php endforeach ?>
    <?= $grid->end() ?>
<?= $el->end() ?>
