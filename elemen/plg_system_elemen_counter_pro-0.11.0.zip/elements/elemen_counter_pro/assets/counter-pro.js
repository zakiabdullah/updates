/* Elemen: Counter Pro — counts numbers up when they scroll into view. No dependencies. */
(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const easings = {
        linear: (t) => t,
        out: (t) => 1 - Math.pow(1 - t, 3),
        'in-out': (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2),
    };

    // Short forms, as in the template: 1.3K / 1.3 ribu.
    const units = {
        short: [[1e12, 'T'], [1e9, 'B'], [1e6, 'M'], [1e3, 'K']],
        malay: [[1e12, '\u00a0trilion'], [1e9, '\u00a0bilion'], [1e6, '\u00a0juta'], [1e3, '\u00a0ribu']],
    };

    function full(value, decimals, sep, dec) {
        const [whole, fraction] = Math.abs(value).toFixed(decimals).split('.');
        const grouped = sep ? whole.replace(/\B(?=(\d{3})+(?!\d))/g, sep) : whole;

        return (value < 0 ? '-' : '') + grouped + (fraction ? dec + fraction : '');
    }

    function format(value, decimals, sep, dec, compact, compactDecimals) {
        for (const [size, suffix] of units[compact] || []) {
            if (Math.abs(value) >= size) {
                let short = full(Math.round(value / size * 10 ** compactDecimals) / 10 ** compactDecimals, compactDecimals, '', dec);

                // "1.30" → "1.3", "2.0" → "2": the short form always has decimals here.
                if (compactDecimals) {
                    short = short.replace(/0+$/, '');
                    short = short.endsWith(dec) ? short.slice(0, -dec.length) : short;
                }

                return short + suffix;
            }
        }

        return full(value, decimals, sep, dec);
    }

    const text = (el, value) => format(value, Number(el.dataset.cpDecimals) || 0, el.dataset.cpSep, el.dataset.cpDec, el.dataset.cpCompact, Number(el.dataset.cpCdec) || 0);

    /* Odometer: every digit of the final number is a strip of 0–9 (twice, for a longer
       spin) that slides up to its digit. Separators, decimal marks and short-form letters
       stay as they are. */
    function prepare(el, value) {
        el.textContent = '';

        for (const character of value) {
            if (!/\d/.test(character)) {
                el.append(character);
                continue;
            }

            const cell = document.createElement('span');
            const strip = document.createElement('span');
            cell.className = 'cp-odo';
            strip.className = 'cp-odo-strip';
            strip.dataset.digit = character;

            for (let n = 0; n < 20; n++) {
                const digit = document.createElement('span');
                digit.textContent = String(n % 10);
                strip.append(digit);
            }

            cell.append(strip);
            el.append(cell);
        }
    }

    function roll(el, value, duration, delay) {
        prepare(el, value);
        const strips = [...el.querySelectorAll('.cp-odo-strip')];

        el.cpTimer = setTimeout(() => {
            // Columns start one after the other, left to right.
            strips.forEach((strip, i) => {
                strip.style.transition = `transform ${duration}ms cubic-bezier(.2, .7, .2, 1) ${i * 70}ms`;
                strip.style.transform = `translateY(calc(${-(10 + Number(strip.dataset.digit))} * var(--cp-odo-h, 1.1em)))`;
            });
        }, delay + 30);
    }

    function count(el) {
        const start = Number(el.dataset.cpStart) || 0;
        const end = Number(el.dataset.cpEnd) || 0;
        const decimals = Number(el.dataset.cpDecimals) || 0;
        const duration = Number(el.dataset.cpDuration) || 2000;
        const ease = easings[el.dataset.cpEasing] || easings.out;
        const show = (value) => {
            el.textContent = format(value, decimals, el.dataset.cpSep, el.dataset.cpDec, el.dataset.cpCompact, Number(el.dataset.cpCdec) || 0);
        };

        cancelAnimationFrame(el.cpFrame);
        clearTimeout(el.cpTimer);

        if (reduce) {
            show(end);
            return;
        }

        if (el.dataset.cpStyle === 'odometer') {
            roll(el, text(el, end), duration, Number(el.dataset.cpDelay) || 0);
            return;
        }

        let begin = null;
        const step = (now) => {
            begin ??= now;
            const t = Math.min(1, (now - begin) / duration);
            show(start + (end - start) * ease(t));

            if (t < 1) {
                el.cpFrame = requestAnimationFrame(step);
            }
        };

        // Items in a grid start one after the other.
        el.cpTimer = setTimeout(() => {
            el.cpFrame = requestAnimationFrame(step);
        }, Number(el.dataset.cpDelay) || 0);
    }

    const observer = 'IntersectionObserver' in window
        ? new IntersectionObserver((entries) => {
            entries.forEach(({ target, isIntersecting }) => {
                if (isIntersecting) {
                    count(target);

                    if (target.dataset.cpRepeat !== 'true') {
                        observer.unobserve(target);
                    }
                } else if (target.dataset.cpRepeat === 'true' && !reduce) {
                    reset(target);
                }
            });
        }, { threshold: 0.5 })
        : null;

    // Start state: the start number, or an odometer showing zeros.
    function reset(el) {
        clearTimeout(el.cpTimer);
        cancelAnimationFrame(el.cpFrame);

        if (el.dataset.cpStyle === 'odometer') {
            prepare(el, text(el, Number(el.dataset.cpEnd) || 0));
        } else {
            el.textContent = text(el, Number(el.dataset.cpStart) || 0);
        }
    }

    function init(root) {
        root.querySelectorAll('.cp-value:not([data-cp-ready])').forEach((el) => {
            el.setAttribute('data-cp-ready', '');

            if (!observer) {
                return; // Old browsers keep the final number.
            }

            if (!reduce) {
                reset(el);
            }

            observer.observe(el);
        });
    }

    const boot = () => {
        init(document);

        // The YOOtheme builder preview replaces elements while editing.
        new MutationObserver(() => init(document)).observe(document.body, { childList: true, subtree: true });
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
