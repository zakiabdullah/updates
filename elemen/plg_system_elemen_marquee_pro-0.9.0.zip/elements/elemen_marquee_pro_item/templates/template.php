<?php

/**
 * Marquee Pro item: a logo, an icon and/or a text, linked or not.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<string, mixed> $element
 * @var int|null $index
 */

\defined('_JEXEC') or die;

$has = static fn ($value): bool => trim((string) $value) !== '';

if (!$has($props['text']) && !$props['image'] && !$has($props['icon'])) {
    return;
}

$index = (int) ($index ?? 0);
$inner = '';

if ($props['image']) {
    $inner .= $this->el('image', [
        'class'     => ['el-image mq-image'],
        'src'       => $props['image'],
        'alt'       => $props['image_alt'],
        'thumbnail' => true,
    ])->render([]);
}

if ($has($props['icon'])) {
    $inner .= '<span class="mq-icon" uk-icon="icon: ' . htmlspecialchars((string) $props['icon']) . '"></span>';
}

if ($has($props['text'])) {
    $style  = (string) $element['text_style'];
    $inner .= '<span class="el-title mq-text' . ($style ? ' uk-' . $style . ' uk-margin-remove' : '')
        . ($element['text_color'] ? ' uk-text-' . $element['text_color'] : '') . '">' . $props['text'] . '</span>';
}

$el = $this->el($props['link'] ? 'a' : 'div', [
    'class'  => ['el-item mq-item', 'mq-outline' => $element['outline'] && $index % 2 === 1],
    'href'   => $props['link'] ? ['{link}'] : false,
    'target' => $props['link'] && $props['link_target'] ? '_blank' : false,
]);

echo $el($props, $attrs) . $inner . $el->end();
