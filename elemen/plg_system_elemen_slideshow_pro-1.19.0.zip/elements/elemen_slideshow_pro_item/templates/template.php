<?php

/**
 * Slideshow Pro slide. The parent passes its props, the checked settings and the index.
 *
 * Structure: .ssp-slide > .ssp-media > .ssp-kb (Ken Burns) > images, .ssp-overlay, and
 * .ssp-layer (light/dark text) > container > .ssp-content > .ssp-a blocks, which come in one
 * after another (--ssp-i).
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<string, mixed> $element
 * @var array<string, mixed> $settings
 * @var int $index
 * @var bool $first
 * @var bool $scheduled
 */

\defined('_JEXEC') or die;

require_once \dirname(__DIR__, 2) . '/elemen_slideshow_pro/ElemenSlideshowPro.php';

$element ??= [];
$s        = $settings ?? ElemenSlideshowPro::settings($element);
$index    = (int) ($index ?? 0);
$first    = (bool) ($first ?? $index === 0);
$has      = static fn ($value): bool => trim(strip_tags((string) $value, '<img><svg>')) !== '';
$e        = static fn ($value): string => htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
$item     = static fn (string $key): string => ElemenSlideshowPro::item($props, $key);

// Per-slide overrides.
$split     = $s['layout'] === 'split';
$side      = $item('split_side') ?: $s['split_side'];
$colors    = ElemenSlideshowPro::colors($s, $item('text_color'));
$textColor = $colors['header'];
$position  = $item('content_position') ?: $s['content_position'];
$overlay   = $item('overlay') ?: $s['overlay'];
$kenburns  = $item('kenburns') ?: $s['kenburns'];
$kenburns  = $kenburns === 'auto' ? ElemenSlideshowPro::KENBURNS_AUTO[$index % 4] : ($kenburns === 'none' ? '' : $kenburns);
$duration  = trim((string) ($props['duration'] ?? '')) !== '' ? max(2, min(60, (int) $props['duration'])) : 0;

// Images: the phone image replaces the image below 640px. The first slide's image loads
// first (no lazy loading) unless there are two images, where lazy loading keeps phones from
// downloading the large one.
$image  = $has($props['image'] ?? '') ? (string) $props['image'] : '';
$mobile = $has($props['image_mobile'] ?? '') ? (string) $props['image_mobile'] : '';
$eager  = $first && $s['image_eager'];

$img = function (string $src, string $class, string $focal) use ($props, $eager, $mobile, $image): string {
    $position = ElemenSlideshowPro::focal($focal);

    return $this->el('image', [
        'class'         => ['el-image', 'ssp-img', $class],
        'src'           => $src,
        'alt'           => $props['image_alt'] ?? '',
        'loading'       => $eager && ($mobile === '' || $image === '') ? false : 'lazy',
        'fetchpriority' => $eager ? 'high' : false,
        'sizes'         => '100vw',
        'thumbnail'     => true,
        'style'         => $position !== '' ? "object-position: {$position}" : false,
    ])->render([]);
};

$media = '';

if ($image !== '') {
    $media .= $img($image, $mobile !== '' ? 'ssp-img-desktop' : '', $item('image_focal'));
}

if ($mobile !== '') {
    $media .= $img($mobile, $image !== '' ? 'ssp-img-mobile' : '', $item('image_mobile_focal') ?: $item('image_focal'));
}

// Content blocks, numbered for the staggered entrance.
$blocks = [];

if ($has($props['eyebrow'] ?? '')) {
    $blocks[] = [
        'kicker' => '<div class="el-meta ssp-eyebrow ssp-kicker">' . $props['eyebrow'] . '</div>',
        'label'  => '<div class="el-meta ssp-eyebrow"><span class="uk-label">' . $props['eyebrow'] . '</span></div>',
        'meta'   => '<div class="el-meta ssp-eyebrow uk-text-meta">' . $props['eyebrow'] . '</div>',
    ][$s['eyebrow_style']];
}

if ($has($props['title'] ?? '')) {
    $tag      = ['h1-first' => $first ? 'h1' : 'h2'][$s['title_element']] ?? $s['title_element'];
    $words    = $s['content_animation'] === 'words' ? ' data-ssp-words' : '';
    $blocks[] = "<{$tag} class=\"el-title ssp-title uk-{$s['title_style']} uk-margin-remove\"{$words}>{$props['title']}</{$tag}>";
}

if ($has($props['content'] ?? '')) {
    $blocks[] = '<div class="el-content ssp-text uk-panel' . ($s['content_style'] !== '' ? " uk-text-{$s['content_style']}" : '') . '">' . $props['content'] . '</div>';
}

$buttons = '';
$target  = $s['button_target'] ? ' target="_blank" rel="noopener"' : '';

foreach ([1, 2] as $n) {
    $label = (string) ($props["button{$n}_text"] ?? '');
    $link  = (string) ($props["button{$n}_link"] ?? '');

    if (!$has($label)) {
        continue;
    }

    $class = "el-link ssp-button uk-button uk-button-{$s["button{$n}_style"]}" . ($s['button_size'] !== '' ? " uk-button-{$s['button_size']}" : '');
    $icon  = ElemenSlideshowPro::icon($props, "button{$n}_icon", 18);

    if ($icon !== '') {
        $class .= ' ssp-button-icon ssp-icon-' . $s['button_icon_position'];
        $icon   = '<span class="ssp-button-glyph" aria-hidden="true">' . $icon . '</span>';
        $label  = $s['button_icon_position'] === 'start' ? $icon . '<span>' . $label . '</span>' : '<span>' . $label . '</span>' . $icon;
    }

    $buttons .= $link !== ''
        ? '<a class="' . $class . '" href="' . $e($link) . '"' . $target . '>' . $label . '</a>'
        : '<span class="' . $class . '">' . $label . '</span>';
}

if ($buttons !== '') {
    $blocks[] = '<div class="ssp-buttons">' . $buttons . '</div>';
}

$overlayClass = match ($overlay) {
    'none'      => '',
    'primary'   => 'uk-background-primary',
    'secondary' => 'uk-background-secondary',
    default     => "ssp-tone-{$overlay}",
};

$align = str_ends_with($position, 'left') ? 'start' : (str_ends_with($position, 'right') ? 'end' : 'center');

// Split: the content sits on a theme surface beside the image.
$panel = [
    'default'   => 'uk-background-default',
    'muted'     => 'uk-background-muted',
    'primary'   => 'uk-background-primary',
    'secondary' => 'uk-background-secondary',
][$s['split_panel']];

// Content card over the image.
$card = [
    'none'      => '',
    'box'       => ' ssp-card ssp-card-box uk-background-default',
    'glass'     => ' ssp-card ssp-card-glass',
    'primary'   => ' ssp-card ssp-card-tone uk-background-primary',
    'secondary' => ' ssp-card ssp-card-tone uk-background-secondary',
][$s['content_card']];

$el = $this->el('div', [
    'class' => [
        'el-item ssp-slide',
        "ssp-side-{$align}",
        "ssp-split ssp-img-{$side}" => $split,
        "uk-inverse-{$textColor}",
        // Without an image the slide takes a theme surface that suits its text colour.
        $media === '' ? ($textColor === 'light' ? 'uk-background-secondary' : 'uk-background-muted') : '',
        'ssp-scheduled' => !empty($scheduled),
    ],
    'role'                 => 'group',
    'aria-roledescription' => 'slide',
    'aria-label'           => ($index + 1) . ' / ' . (int) ($count ?? 1),
    'data-ssp-duration'    => $duration ?: false,
    'data-ssp-label'       => !empty($scheduled) ? 'Scheduled: not shown now' : false,
]);

?>
<?= $el($props, $attrs) ?>

    <?php if ($media !== '') : ?>
    <div class="ssp-media">
        <div class="ssp-kb<?= $kenburns !== '' ? " ssp-kb-{$kenburns}" : '' ?>"><?= $media ?></div>
        <?php if ($overlayClass !== '') : ?>
        <div class="ssp-overlay <?= $overlayClass ?>" aria-hidden="true"></div>
        <?php endif ?>
    </div>
    <?php endif ?>

    <?php if ($blocks || $split) : ?>
    <div class="ssp-layer ssp-pos-<?= $position ?> uk-<?= $colors['content'] ?><?= $split ? ' ssp-panel ' . $panel : '' ?>">
        <div class="ssp-container<?= $s['content_container'] && !$split ? ' uk-container' : '' ?>">
            <div class="ssp-content ssp-w-<?= $s['content_width'] ?> ssp-align-<?= $align ?><?= $card ?>">
                <?php foreach ($blocks as $i => $block) : ?>
                <div class="ssp-a" style="--ssp-i: <?= $i ?>"><?= $block ?></div>
                <?php endforeach ?>
            </div>
        </div>
    </div>
    <?php endif ?>

<?= $el->end() ?>
