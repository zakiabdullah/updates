<?php

/**
 * Builder transforms for Animated Background Pro.
 *
 * prerender (section): a section with an effect or grain gets a layer node as its first child, so
 * it renders inside the section like any other child. The node exists only while
 * rendering; the saved layout is never changed. Auto colors are resolved here, where the
 * section's style is known.
 *
 * render: runs after YOOtheme's element transform, so the section keeps its own classes
 * and gains the class the layer styles hang on. It also moves the layer before any nodes
 * other plugins added at the start (Shape Dividers), so those stay above the animation.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

$effects = ['aurora', 'gradient', 'waves', 'pattern', 'shapes'];

$presets = [
    'calm-aurora' => [
        'elemen_bg_effect'    => 'aurora',
        'elemen_bg_colors'    => '',
        'elemen_bg_intensity' => '',
        'elemen_bg_speed'     => '',
        'elemen_bg_grain'     => true,
    ],
    'soft-gradient' => [
        'elemen_bg_effect'    => 'gradient',
        'elemen_bg_colors'    => '',
        'elemen_bg_intensity' => '',
        'elemen_bg_speed'     => '',
        'elemen_bg_grain'     => true,
    ],
    'tech-grid' => [
        'elemen_bg_effect'         => 'pattern',
        'elemen_bg_pattern'        => 'grid',
        'elemen_bg_pattern_size'   => 48,
        'elemen_bg_pattern_edges'  => false,
        'elemen_bg_colors'         => 'corporate',
        'elemen_bg_intensity'      => '',
        'elemen_bg_speed'          => 'still',
        'elemen_bg_grain'          => false,
    ],
    'quiet-dots' => [
        'elemen_bg_effect'        => 'pattern',
        'elemen_bg_pattern'       => 'dots',
        'elemen_bg_pattern_size'  => 28,
        'elemen_bg_pattern_edges' => false,
        'elemen_bg_colors'        => '',
        'elemen_bg_intensity'     => '',
        'elemen_bg_speed'         => 'still',
        'elemen_bg_grain'         => false,
    ],
    'ocean-waves' => [
        'elemen_bg_effect'    => 'waves',
        'elemen_bg_colors'    => 'corporate',
        'elemen_bg_intensity' => 'medium',
        'elemen_bg_speed'     => '',
        'elemen_bg_grain'     => false,
    ],
    'playful-shapes' => [
        'elemen_bg_effect'         => 'shapes',
        'elemen_bg_shapes'         => '',
        'elemen_bg_shapes_count'   => 'many',
        'elemen_bg_colors'         => 'vibrant',
        'elemen_bg_intensity'      => 'medium',
        'elemen_bg_speed'          => 'medium',
        'elemen_bg_grain'          => false,
    ],
];

$settingsOf = static function (object $node) use ($presets): array {
    $settings = (array) ($node->props ?? []);
    $preset   = (string) ($settings['elemen_bg_preset'] ?? '');

    return isset($presets[$preset]) ? array_replace($settings, $presets[$preset]) : $settings;
};

$effectOf = static function (object $node) use ($effects, $settingsOf): string {
    $settings = $settingsOf($node);
    $effect   = (string) ($settings['elemen_bg_effect'] ?? '');

    return ($node->type ?? '') === 'section' && in_array($effect, $effects, true) ? $effect : '';
};

// A layer is shown for an effect, or for grain alone.
$shows = static function (object $node) use ($effectOf, $settingsOf): bool {
    $settings = $settingsOf($node);

    return ($node->type ?? '') === 'section'
        && ($effectOf($node) !== '' || !empty($settings['elemen_bg_grain']));
};

return [
    'prerender' => static function (object $node) use ($effectOf, $shows, $settingsOf): void {
        if (!$shows($node)) {
            return;
        }

        $effect = $effectOf($node);

        $originalProps = (array) $node->props;
        $props         = $settingsOf($node);
        $style         = (string) ($props['style'] ?? '');

        $values = [
            'effect'    => $effect,
            'colors'    => (string) ($props['elemen_bg_colors'] ?? ''),
            'intensity' => (string) ($props['elemen_bg_intensity'] ?? ''),
            'speed'     => (string) ($props['elemen_bg_speed'] ?? ''),
            // Auto colors depend on the section's own style.
            'style'     => $style,
            'pattern'   => (string) ($props['elemen_bg_pattern'] ?? ''),
            'size'      => $props['elemen_bg_pattern_size'] ?? '',
            'edges'     => !empty($props['elemen_bg_pattern_edges']),
            'shapes'    => (string) ($props['elemen_bg_shapes'] ?? ''),
            'count'     => (string) ($props['elemen_bg_shapes_count'] ?? ''),
            'grain'     => !empty($props['elemen_bg_grain']),
            // Floating shapes are placed from this: the same section always looks the
            // same, and sections with other settings or content look different.
            'seed'      => crc32(json_encode([$originalProps, $node->children ?? []]) ?: ''),
        ];

        foreach ([1, 2, 3] as $n) {
            $values["color_$n"] = (string) ($props["elemen_bg_color_$n"] ?? '');
        }

        $layer = (object) ['type' => 'elemen_background_pro_layer', 'props' => $values];

        $node->children = array_merge([$layer], (array) ($node->children ?? []));
    },

    'render' => static function (object $node) use ($shows): void {
        if (!$shows($node)) {
            return;
        }

        $node->attrs['class'][] = 'elemen-bg-section';

        // The layer goes first, before nodes other plugins put at the start in their own
        // prerender (e.g. Shape Dividers), so those paint above the animation.
        $children = (array) ($node->children ?? []);
        $isLayer  = static fn ($child): bool => is_object($child) && ($child->type ?? '') === 'elemen_background_pro_layer';

        $node->children = array_merge(array_values(array_filter($children, $isLayer)), array_values(array_filter($children, static fn ($child): bool => !$isLayer($child))));
    },
];
