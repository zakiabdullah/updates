<?php

/**
 * YOOtheme application config for Elemen Icon Pro.
 *
 * Every folder in elements/ with an element.json is a builder element. Names
 * start with "elemen_icon_pro" so they never clash with YOOtheme or other plugins.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

use YOOtheme\Builder;
use YOOtheme\Event;

// Optional YOOtheme event listeners per element, e.g. to add fields to a core element:
// elements/<type>/events.php returns ['builder.type' => callable, ...].
foreach (glob(__DIR__ . '/elements/*/events.php') ?: [] as $file) {
    foreach ((array) require $file as $event => $listener) {
        Event::on($event, $listener);
    }
}

return [
    'extend' => [
        Builder::class => function (Builder $builder) {
            $builder->addTypePath(__DIR__ . '/elements/*/element.json');

            // Optional builder transforms per element, e.g. to migrate older layouts:
            // elements/<type>/transforms.php returns ['preload' => callable, ...].
            foreach (glob(__DIR__ . '/elements/*/transforms.php') ?: [] as $file) {
                foreach ((array) require $file as $context => $transform) {
                    $builder->addTransform($context, $transform);
                }
            }
        },
    ],
];
