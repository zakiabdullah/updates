<?php

/**
 * Icon Pro item: the icon (or an image), its label, tooltip and link.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<string, mixed> $element
 * @var int|null $index
 */

use Elemen\IconPro\Icons;

\defined('_JEXEC') or die;

$has = static fn ($value): bool => trim((string) $value) !== '';

if (!$has($props['icon']) && !$props['image']) {
    return;
}

require_once \dirname(__DIR__, 2) . '/elemen_icon_pro/icons/Icons.php';

$color  = static fn ($value): string => preg_match('/^[#(),.%\w\s-]+$/', trim((string) $value)) ? trim((string) $value) : '';
$size   = max(16, min(240, (int) ($element['size'] ?: 40)));
$own    = $color($props['color']);
$custom = $element['color'] === 'custom' ? $color($element['color_custom']) : '';
$solid  = $element['shape'] && in_array($element['shape_style'], ['filled', 'gradient'], true);

// Gradient lines, unless the icon sits white on a filled shape.
$gradient = $element['color'] === 'gradient' && !$own && !$solid && $color($element['gradient_from']) && $color($element['gradient_to'])
    ? [$color($element['gradient_from']), $color($element['gradient_to'])]
    : null;

if ($props['image']) {
    $icon = $this->el('image', [
        'class'  => ['ic-svg ic-image'],
        'src'    => $props['image'],
        'alt'    => $props['image_alt'],
        'width'  => $size,
        'height' => $size,
    ])->render([]);
} else {
    $icon = Icons::svg((string) $props['icon'], [
        'size'     => $size,
        'stroke'   => $element['stroke'] ?: 2,
        'gradient' => $gradient,
        'fill'     => (bool) $element['duotone'],
        'draw'     => $element['animate_in'] === 'draw',
    ]);
}

$themed = !$own && !$custom && in_array($element['color'], ['primary', 'secondary', 'emphasis', 'muted', 'success', 'warning', 'danger'], true);

$iconEl = $this->el('span', [
    'class' => ['el-icon ic-icon', 'uk-text-' . $element['color'] => $themed],
    'style' => ($own ?: $custom) ? 'color: ' . ($own ?: $custom) : false,
]);

$label = $has($props['label'])
    ? '<span class="el-title ic-label' . ($element['label_style'] ? ' uk-' . $element['label_style'] : '') . '">' . $props['label'] . '</span>'
    : '';

// A link without a label is named by its tooltip, or by the icon name.
$name = $has($props['tooltip']) ? strip_tags((string) $props['tooltip'])
    : (stripos(trim((string) $props['icon']), 'class:') === 0 ? 'Icon' : ucfirst(str_replace(['uikit:', 'lucide:', '-'], ['', '', ' '], (string) $props['icon'])));

$el = $this->el($props['link'] ? 'a' : 'div', [
    'class'      => ['el-item ic-item'],
    'style'      => '--ic-i: ' . (int) ($index ?? 0),
    'href'       => $props['link'] ? ['{link}'] : false,
    'target'     => $props['link'] && $element['link_target'] ? '_blank' : false,
    'aria-label' => $props['link'] && !$label ? $name : false,
    'uk-tooltip' => $has($props['tooltip']) ? 'title: ' . htmlspecialchars(strip_tags((string) $props['tooltip'])) . '; pos: top' : false,
]);

echo $el($props, $attrs) . $iconEl($props) . $icon . $iconEl->end() . $label . $el->end();
