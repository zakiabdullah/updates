<?php

/**
 * Lets other Elemen elements use Lucide icons while Icon Pro is installed: a "Lucide Icon"
 * field goes right after each of their UIkit icon fields. Their templates draw the Lucide
 * icon when it is set and Icon Pro's icons are there, and the UIkit icon otherwise, so
 * nothing changes for layouts without it.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

use Elemen\IconPro\Icons;
use Joomla\CMS\Uri\Uri;
use YOOtheme\Config;
use YOOtheme\Event;
use YOOtheme\Metadata;
use YOOtheme\View;

use function YOOtheme\app;

\defined('_JEXEC') or die;

$gallery = static fn (): string => Uri::root(true) . '/' . str_replace('\\', '/', substr(__DIR__, strlen(JPATH_ROOT) + 1)) . '/gallery/index.html';

// YOOtheme menus: a Lucide Icon field for menu items, after their Icon field. It runs
// after YOOtheme has loaded the customizer panels (priority 0) and before it writes them
// into the page (-20).
Event::on('customizer.init', static function () use ($gallery): void {
    $config = app(Config::class);
    $fields = (array) $config->get('customizer.panels.menu-item.fields');

    if (!isset($fields['icon']) || isset($fields['icon_lucide'])) {
        return;
    }

    $out = [];

    foreach ($fields as $name => $field) {
        $out[$name] = $field;

        if ($name === 'icon') {
            $out['icon_lucide'] = [
                'label'       => 'Lucide Icon',
                'description' => 'Used instead of the icon above, e.g. <code>house</code>, or an icon font with <code>class:fi fi-rr-home</code> (Icon Pro). <a href="' . htmlspecialchars($gallery()) . '" target="_blank" rel="noopener">Open the icon gallery</a>.',
                'attrs'       => ['placeholder' => 'house'],
                'enable'      => '!image',
            ];
        }
    }

    $config->set('customizer.panels.menu-item.fields', $out);
}, -10);

// ...and its rendering: YOOtheme draws every menu item's icon or image through
// templates/menu/image.php, in every menu type. A Lucide icon takes its place, with the
// same size and spacing; otherwise YOOtheme renders as usual.
app()->extend(View::class, static function (View $view): void {
    $view->addLoader(static function (string $name, array $parameters, callable $next) {
        $item   = $parameters['item'] ?? null;
        $config = app(Config::class);
        $base   = is_object($item) && isset($item->id) ? "~theme.menu.items.{$item->id}" : '';
        $lucide = $base ? trim((string) $config->get("$base.icon_lucide")) : '';

        if ($lucide === '' || $config->get("$base.image")) {
            return $next($name, $parameters);
        }

        require_once __DIR__ . '/icons/Icons.php';

        $classes = array_filter([
            $config->get('~menu.image_margin') && !$config->get("$base.image_only") && !$config->get("$base.subtitle") ? 'uk-margin-xsmall-right' : '',
            (string) $config->get("$base.image_classes", ''),
        ]);

        // In a span.uk-icon like YOOtheme's own icons, so it lines up the same way.
        return '<span class="' . htmlspecialchars(implode(' ', ['uk-icon', ...$classes])) . '">'
            . Icons::svg($lucide, ['size' => (int) ($config->get('~menu.image_width') ?: 20)]) . '</span>';
    }, '~theme/templates/menu/image*');
});

return [
    // The builder editor: the gallery link under an icon field opens a picker in a dialog.
    'customizer.init' => static function (): void {
        $file = __DIR__ . '/assets/icon-picker.js';

        app(Metadata::class)->set('script:elemen-icon-picker', [
            'src'   => Uri::root(true) . '/' . str_replace('\\', '/', substr($file, strlen(JPATH_ROOT) + 1)) . '?v=' . @filemtime($file),
            'defer' => true,
        ]);
    },

    'builder.type' => static function (array $type): array {
        // Element type => its UIkit icon fields. The Lucide field is "<field>_lucide".
        $targets = [
            'elemen_counter_pro_item'  => ['icon'],
            'elemen_flipbox_pro'       => ['list_icon'],
            'elemen_flipbox_pro_item'  => ['icon'],
            'elemen_timeline_pro'      => ['marker_icon'],
            'elemen_timeline_pro_item' => ['icon'],
            'elemen_tabs_pro_item'     => ['icon'],
            'elemen_heading_pro'       => ['icon'],
            'elemen_marquee_pro'       => ['separator_icon'],
            'elemen_marquee_pro_item'  => ['icon'],
        ];

        $fields = $targets[$type['name'] ?? ''] ?? [];

        if (!$fields) {
            return $type;
        }

        $gallery = Uri::root(true) . '/' . str_replace('\\', '/', substr(__DIR__, strlen(JPATH_ROOT) + 1)) . '/gallery/index.html';

        foreach ($fields as $field) {
            $name = "{$field}_lucide";

            if (!isset($type['fields'][$field]) || isset($type['fields'][$name])) {
                continue;
            }

            $type['fields'][$name] = array_intersect_key((array) $type['fields'][$field], array_flip(['enable', 'show'])) + [
                'label'       => 'Lucide Icon',
                'description' => 'Used instead of the icon above, e.g. <code>house</code>, or an icon font with <code>class:fi fi-rr-home</code> (Icon Pro). <a href="' . htmlspecialchars($gallery) . '" target="_blank" rel="noopener">Open the icon gallery</a>.',
                'attrs'       => ['placeholder' => 'house'],
                'source'      => true,
            ];

            // Right after the UIkit icon field, wherever it sits in the panel.
            $insert = static function (array $list) use (&$insert, $field, $name): array {
                $out    = [];
                $isList = array_is_list($list);

                foreach ($list as $key => $entry) {
                    if (is_array($entry) && isset($entry['fields']) && is_array($entry['fields'])) {
                        $entry['fields'] = $insert($entry['fields']);
                    }

                    if ($isList) {
                        $out[] = $entry;
                    } else {
                        $out[$key] = $entry;
                    }

                    if ($entry === $field) {
                        $out[] = $name;
                    }
                }

                return $out;
            };

            foreach ($type['fieldset'] ?? [] as $key => $set) {
                if (is_array($set)) {
                    $type['fieldset'][$key] = $insert([$set])[0];
                }
            }
        }

        return $type;
    },
];
