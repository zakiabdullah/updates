<?php

/**
 * Icon Pro: icons in a row or grid. Each icon is inline SVG (see icons/Icons.php), so only
 * the icons used are in the page and they take the text color.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var \YOOtheme\Builder $builder
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<int, object> $children
 */

use Joomla\CMS\Uri\Uri;
use YOOtheme\Metadata;

use function YOOtheme\app;

\defined('_JEXEC') or die;

require_once \dirname(__DIR__) . '/icons/Icons.php';

$items = [];

foreach ($children as $i => $child) {
    $html = (string) $builder->render($child, ['element' => $props, 'index' => count($items)]);

    if (trim($html) !== '') {
        $items[] = $html;
    }
}

if (!$items) {
    return;
}

$assets   = \dirname(__DIR__) . '/assets';
$assetUrl = static fn (string $file): string => Uri::root(true) . '/'
    . str_replace('\\', '/', substr($assets, strlen(JPATH_ROOT) + 1)) . "/{$file}?v=" . @filemtime("{$assets}/{$file}");
$metadata = app(Metadata::class);

$metadata->set('style:elemen-icon-pro', ['href' => $assetUrl('icon-pro.css')]);

if ($props['animate_in']) {
    $metadata->set('script:elemen-icon-pro', ['src' => $assetUrl('icon-pro.js'), 'defer' => true]);
}

$color = static fn ($value): string => preg_match('/^[#(),.%\w\s-]+$/', trim((string) $value)) ? trim((string) $value) : '';
$size  = max(16, min(240, (int) ($props['size'] ?: 40)));
$shape = in_array($props['shape'], ['circle', 'square', 'rounded', 'blob'], true) ? $props['shape'] : '';
$box   = $shape ? (int) round($size * (['small' => 1.6, 'large' => 2.4][$props['shape_padding']] ?? 2)) : $size;

$vars = ["--ic-size: {$size}px", "--ic-box: {$box}px"];

if ($props['layout'] === 'grid') {
    $vars[] = '--ic-cols: ' . max(1, min(8, (int) ($props['columns'] ?: 4)));
    $vars[] = '--ic-cols-s: ' . max(1, min(4, (int) ($props['columns_small'] ?: 2)));
}

if ($props['color'] === 'gradient' && $color($props['gradient_from']) && $color($props['gradient_to'])) {
    $vars[] = '--ic-g1: ' . $color($props['gradient_from']);
    $vars[] = '--ic-g2: ' . $color($props['gradient_to']);
}

$el = $this->el('div', [

    'class' => [
        'elemen-icon-pro ic',
        'ic-layout-{layout}',
        'ic-gap-{gap}',
        'ic-align-{align}',
        'ic-label-{label_position}',
        "ic-shape ic-shape-{$shape} ic-style-{shape_style}" => (bool) $shape,
        'ic-in-{animate_in} {@animate_in}',
        'ic-stagger' => $props['animate_in'] && $props['stagger'],
        'ic-color-gradient' => $props['color'] === 'gradient',
        'ic-hover-{hover} {@hover}',
        'ic-loop-{loop} {@loop}',
    ],

    'style' => implode('; ', $vars),

]);

?>
<?= $el($props, $attrs) ?>
    <?= implode("\n", $items) ?>
<?= $el->end() ?>
