<?php

/**
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\Database\DatabaseInterface;
use Joomla\Filesystem\Folder;

/**
 * Installer script for plg_system_elemen_icon_pro.
 */
return new class () implements InstallerScriptInterface {
    public function install(InstallerAdapter $adapter): bool
    {
        return true;
    }

    public function update(InstallerAdapter $adapter): bool
    {
        return true;
    }

    public function uninstall(InstallerAdapter $adapter): bool
    {
        return true;
    }

    /**
     * Joomla copies new files over old ones on update but never removes old element
     * folders, so an element dropped from the package would stay registered. Clear the
     * folder before the new files are copied.
     */
    public function preflight(string $type, InstallerAdapter $adapter): bool
    {
        $elements = JPATH_PLUGINS . '/system/elemen_icon_pro/elements';

        if ($type === 'update' && is_dir($elements)) {
            Folder::delete($elements);
        }

        return true;
    }

    /**
     * Plugins are installed disabled; enable it on a fresh install so the elements
     * appear in YOOtheme right away.
     *
     * A plugin that replaces an older one under another name ("replaces" in plugin.json)
     * disables that one, so the two never run side by side.
     */
    public function postflight(string $type, InstallerAdapter $adapter): bool
    {
        if ($type !== 'install' && $type !== 'update') {
            return true;
        }

        $db     = Factory::getContainer()->get(DatabaseInterface::class);
        $plugin = static fn (string $element) => $db->getQuery(true)
            ->update($db->quoteName('#__extensions'))
            ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
            ->where($db->quoteName('folder') . ' = ' . $db->quote('system'))
            ->where($db->quoteName('element') . ' = ' . $db->quote($element));

        if ($type === 'install') {
            $db->setQuery($plugin('elemen_icon_pro')->set($db->quoteName('enabled') . ' = 1'))->execute();
        }

        foreach (array (
) as $old) {
            $db->setQuery($plugin($old)->set($db->quoteName('enabled') . ' = 0')->where($db->quoteName('enabled') . ' = 1'))->execute();

            if ($db->getAffectedRows()) {
                Factory::getApplication()->enqueueMessage(
                    "plg_system_$old has been disabled: it is replaced by plg_system_elemen_icon_pro. You can uninstall it.",
                    'notice'
                );
            }
        }

        return true;
    }
};
