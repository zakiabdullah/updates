<?php

/**
 * YOOtheme application config for Elemen Timeline Pro.
 *
 * Every folder in elements/ with an element.json is a builder element. Names
 * start with "elemen_timeline_pro" so they never clash with YOOtheme or other plugins.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

use YOOtheme\Builder;
use YOOtheme\Event;

// Optional YOOtheme event listeners per element, e.g. to add fields to a core element:
// elements/<type>/events.php returns ['builder.type' => callable, ...].
foreach (glob(__DIR__ . '/elements/*/events.php') ?: [] as $file) {
    foreach ((array) require $file as $event => $listener) {
        Event::on($event, $listener);
    }
}

$config = [
    'extend' => [
        Builder::class => function (Builder $builder) {
            $builder->addTypePath(__DIR__ . '/elements/*/element.json');

            // Optional builder transforms per element, e.g. to migrate older layouts:
            // elements/<type>/transforms.php returns ['preload' => callable, ...].
            foreach (glob(__DIR__ . '/elements/*/transforms.php') ?: [] as $file) {
                foreach ((array) require $file as $context => $transform) {
                    $builder->addTransform($context, $transform);
                }
            }
        },
    ],
];

// Optional YOOtheme application config per folder, e.g. defaults for customizer settings:
// elements/<name>/app.php returns ['theme' => [...]]. A folder may hold only app.php and
// events.php, for a plugin that extends the theme rather than the builder.
foreach (glob(__DIR__ . '/elements/*/app.php') ?: [] as $file) {
    $config = array_merge_recursive($config, (array) require $file);
}

return $config;
