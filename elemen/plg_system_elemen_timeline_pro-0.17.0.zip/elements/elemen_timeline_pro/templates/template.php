<?php

/**
 * Timeline Pro: a vertical timeline with markers, cards, a line that fills while
 * scrolling and items that animate in.
 *
 * Layout is CSS grid plus a container query, so the alternating layout falls back to one
 * side whenever the timeline itself is narrow, whatever the screen size.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var \YOOtheme\Builder $builder
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<int, object> $children
 */

use Joomla\CMS\Uri\Uri;
use YOOtheme\Metadata;

use function YOOtheme\app;

\defined('_JEXEC') or die;

// Display options: fields of every item can be hidden without deleting them. Layouts saved
// before the options existed don't have them, so they count as shown.
$hidden = [];

foreach (['title' => ['title'], 'meta' => ['meta'], 'content' => ['content'], 'image' => ['image'], 'link' => ['link', 'link_text']] as $option => $fields) {
    if (!($props["show_{$option}"] ?? true)) {
        array_push($hidden, ...$fields);
    }
}

foreach ($hidden ? $children : [] as $child) {
    foreach ($hidden as $field) {
        if (is_array($child->props ?? null)) {
            $child->props[$field] = '';
        } elseif (is_object($child->props ?? null)) {
            $child->props->{$field} = '';
        }
    }
}

// Render the items first: if all are empty, render nothing and load no assets. Where the
// Group of an item differs from the item before, a group label goes in between (not in the
// horizontal layout).
$items  = [];
$group  = '';
$groups = 0;

foreach ($children as $i => $child) {
    $html = (string) $builder->render($child, ['element' => $props, 'index' => $i]);

    if (trim($html) === '') {
        continue;
    }

    $label = trim((string) (((array) ($child->props ?? []))['group'] ?? ''));

    if ($label !== '' && $label !== $group && $props['layout'] !== 'horizontal') {
        $items[] = '<div class="tl-group' . ($items ? '' : ' tl-group-first') . '"><span class="tl-group-label uk-label'
            . ($props['group_color'] ? ' uk-label-' . $props['group_color'] : '') . '">' . $label . '</span></div>';
        $groups++;
    }

    $group   = $label !== '' ? $label : $group;
    $items[] = $html;
}

if (!$items) {
    return;
}

// Assets. The URL is worked out from this file's location, so it follows the plugin folder.
$assets   = \dirname(__DIR__) . '/assets';
$assetUrl = static fn (string $file): string => Uri::root(true) . '/'
    . str_replace('\\', '/', substr($assets, strlen(JPATH_ROOT) + 1)) . "/{$file}?v=" . @filemtime("{$assets}/{$file}");
$metadata = app(Metadata::class);

$metadata->set('style:elemen-timeline-pro', ['href' => $assetUrl('timeline-pro.css')]);

// Horizontal timelines scroll sideways; the scroll-linked line fill is for vertical ones.
$horizontal = $props['layout'] === 'horizontal';
$progress   = $props['progress'] && !$horizontal;

if ($progress || $props['reveal'] || ($horizontal && $props['navigation'])) {
    $metadata->set('script:elemen-timeline-pro', ['src' => $assetUrl('timeline-pro.js'), 'defer' => true]);
}

$color = static fn ($value): string => preg_match('/^[#(),.%\w\s-]+$/', trim((string) $value)) ? trim((string) $value) : '';

// Marker size and the vertical position of its centre within an item, so the marker
// lines up with the first line of the card.
$sizes  = $props['marker'] === 'dot' ? ['small' => 10, 'medium' => 16, 'large' => 22] : ['small' => 32, 'medium' => 40, 'large' => 52];
$marker = $sizes[$props['marker_size']] ?? reset($sizes);
$offset = $props['card_style'] ? (['small' => 32, 'large' => 52][$props['card_padding']] ?? 42) : 12;
$gap    = ['small' => 20, 'medium' => 60, 'large' => 90][$props['item_gap']] ?? 40;

$vars = [
    "--tl-m: {$marker}px",
    "--tl-offset: {$offset}px",
    "--tl-gap: {$gap}px",
    '--tl-w: ' . max(1, (int) ($props['line_width'] ?: 2)) . 'px',
    '--tl-item-w: ' . max(120, (int) ($props['item_width'] ?: 300)) . 'px',
    '--tl-sticky-top: ' . (int) ($props['group_sticky_offset'] ?? 80) . 'px',
    '--tl-line-style: ' . (in_array($props['line_style'], ['dashed', 'dotted'], true) ? $props['line_style'] : 'solid'),
];

if ($color($props['line_color'])) {
    $vars[] = '--tl-line-color: ' . $color($props['line_color']);
}

$markerColor = $props['marker_color'] === 'custom' ? '' : ($props['marker_color'] ?: 'primary');

$el = $this->el('div', [

    'class' => [
        'elemen-timeline-pro tl',
        'tl-layout-{layout}',
        'tl-date-opposite' => $horizontal || ($props['layout'] === 'alternate' && $props['date_position'] === 'opposite'),
        'tl-markers-{marker}',
        'tl-marker-outline {@marker_outline}',
        'tl-has-progress' => $progress,
        'tl-reveal tl-reveal-{reveal} {@reveal}',
        'tl-card-arrow {@card_style} {@card_arrow}',
        'tl-group-sticky' => $groups && $props['group_sticky'],
    ],

    'style' => implode('; ', $vars),

]);

$progressStyle = [];

if ($color($props['progress_color'])) {
    $progressStyle[] = 'color: ' . $color($props['progress_color']);
} elseif ($props['marker_color'] === 'custom' && $color($props['marker_color_custom'])) {
    $progressStyle[] = 'color: ' . $color($props['marker_color_custom']);
}

?>
<?= $el($props, $attrs) ?>

    <?php if ($progress) : ?>
    <div class="tl-progress<?= !$progressStyle && $markerColor ? " uk-text-{$markerColor}" : '' ?>"<?= $progressStyle ? ' style="' . implode('; ', $progressStyle) . '"' : '' ?> aria-hidden="true"></div>
    <?php endif ?>

    <?php if ($horizontal) : ?>
    <div class="tl-scroller" tabindex="0">
        <?php foreach ($items as $html) : ?>
        <?= $html ?>
        <?php endforeach ?>
    </div>

    <?php if ($props['navigation']) : ?>
    <div class="tl-nav uk-flex uk-flex-right uk-margin-small-top" hidden>
        <a class="tl-nav-prev uk-slidenav-small" href="#" uk-slidenav-previous aria-label="Previous"></a>
        <a class="tl-nav-next uk-slidenav-small uk-margin-small-left" href="#" uk-slidenav-next aria-label="Next"></a>
    </div>
    <?php endif ?>
    <?php else : ?>
    <?php foreach ($items as $html) : ?>
    <?= $html ?>
    <?php endforeach ?>
    <?php endif ?>

<?= $el->end() ?>
