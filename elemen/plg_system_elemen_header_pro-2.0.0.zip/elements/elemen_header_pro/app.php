<?php

/**
 * Header Pro: defaults of its customizer settings, stored with the theme's own settings
 * under "elemen_header". Off by default, so installing changes nothing until chosen.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

return [
    'theme' => [
        'defaults' => [
            'elemen_header' => [
                'style'          => '',
                'show_when'      => 'sticky',
                'offset'         => 0,
                'capsule_width'  => 'header',
                'animate'        => false,
                'menu_slide'     => false,
                'mobile_shape'   => '',
                'menu_style'     => '',
                'menu_line_from' => 'center',
                'menu_line_gradient' => false,
                'dropdown_style' => '',
                'divider'        => false,
                'dialog_style'   => '',
                'progress'       => '',
                'progress_color' => 'primary',
                'progress_start' => '',
                'progress_end'   => '',
                'progress_height'=> 3,
                'progress_position' => 'top',
                'progress_glow'  => false,
                'cta_text'       => '',
                'cta_link'       => '',
                'cta_style'      => 'primary',
                'cta_position'   => 'header',
                'cta_target'     => false,
                'cta_mobile'     => false,
                'shape'          => 'full',
                'tint'           => 'default',
                'opacity'        => 70,
                'blur'           => 16,
                'capsule_gap'    => 12,
                'capsule_radius' => 'pill',
                'sticky_height'  => 0,
                'shadow'         => true,
                'shadow_scroll'  => false,
                'border'         => true,
                'border_gradient'=> false,
                'mobile_apply'   => true,
                'announce_text'  => '',
                'announce_link'  => '',
                'announce_link_text' => '',
                'announce_style' => 'primary',
                'announce_pages' => 'all',
                'announce_dismiss' => true,
            ],
        ],
    ],
];
