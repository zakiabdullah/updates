<?php

/**
 * YOOtheme application config for Elemen Header Pro.
 *
 * Every folder in elements/ with an element.json is a builder element. Names
 * start with "elemen_header_pro" so they never clash with YOOtheme or other plugins.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

use YOOtheme\Builder;
use YOOtheme\Event;

// Optional YOOtheme event listeners per element, e.g. to add fields to a core element:
// elements/<type>/events.php returns ['builder.type' => callable, ...].
foreach (glob(__DIR__ . '/elements/*/events.php') ?: [] as $file) {
    foreach ((array) require $file as $event => $listener) {
        Event::on($event, $listener);
    }
}

$config = [
    'extend' => [
        Builder::class => function (Builder $builder) {
            $builder->addTypePath(__DIR__ . '/elements/*/element.json');

            // Optional builder transforms per element, e.g. to migrate older layouts:
            // elements/<type>/transforms.php returns ['preload' => callable, ...].
            foreach (glob(__DIR__ . '/elements/*/transforms.php') ?: [] as $file) {
                foreach ((array) require $file as $context => $transform) {
                    $builder->addTransform($context, $transform);
                }
            }

            // Renamed settings: elements/<type>/renames.php returns
            // ['props' => [old => new], 'values' => [key => [old => new]]]. Layouts saved with
            // the old names load with the new ones, dynamic content mappings included.
            foreach (glob(__DIR__ . '/elements/*/renames.php') ?: [] as $file) {
                $type    = basename(dirname($file));
                $renames = (array) require $file;
                $props   = (array) ($renames['props'] ?? []);
                $values  = (array) ($renames['values'] ?? []);

                $builder->addTransform('preload', static function (object $node) use ($type, $props, $values): void {
                    if (($node->type ?? '') !== $type) {
                        return;
                    }

                    $rename = static function ($bag) use ($props) {
                        $bag = (array) $bag;

                        foreach ($props as $old => $new) {
                            // The old name wins: YOOtheme has already filled in the
                            // defaults, new names included, before this transform runs.
                            if (array_key_exists($old, $bag)) {
                                $bag[$new] = $bag[$old];
                                unset($bag[$old]);
                            }
                        }

                        return $bag;
                    };

                    $node->props = $rename($node->props ?? []);

                    foreach ($values as $key => $map) {
                        $value = $node->props[$key] ?? null;

                        if (is_scalar($value) && array_key_exists((string) $value, (array) $map)) {
                            $node->props[$key] = $map[(string) $value];
                        }
                    }

                    if (isset($node->source->props)) {
                        $node->source->props = (object) $rename($node->source->props);
                    }
                });
            }
        },
    ],
];

// Optional YOOtheme application config per folder, e.g. defaults for customizer settings:
// elements/<name>/app.php returns ['theme' => [...]]. A folder may hold only app.php and
// events.php, for a plugin that extends the theme rather than the builder.
foreach (glob(__DIR__ . '/elements/*/app.php') ?: [] as $file) {
    $config = array_merge_recursive($config, (array) require $file);
}

return $config;
