<?php

/**
 * Icon Pro icons as inline SVG: Lucide by name (old names too), UIkit icons as
 * "uikit:name". Other Elemen elements can use it when Icon Pro is installed:
 *
 *   require_once JPATH_PLUGINS . '/system/elemen_icon_pro/elements/elemen_icon_pro/icons/Icons.php';
 *   echo \Elemen\IconPro\Icons::svg('house', ['size' => 24]);
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

namespace Elemen\IconPro;

\defined('_JEXEC') or die;

if (!class_exists(Icons::class, false)) {
    final class Icons
    {
        /** @var array{version: string, icons: array<string, string>, aliases: array<string, string>}|null */
        private static ?array $lucide = null;

        private static int $gradients = 0;

        /** @return array{version: string, icons: array<string, string>, aliases: array<string, string>} */
        private static function lucide(): array
        {
            if (self::$lucide === null) {
                $data         = json_decode((string) @file_get_contents(__DIR__ . '/lucide.json'), true);
                self::$lucide = is_array($data) ? $data + ['version' => '', 'icons' => [], 'aliases' => []] : ['version' => '', 'icons' => [], 'aliases' => []];
            }

            return self::$lucide;
        }

        /**
         * Whether a name is a known icon (Lucide, an old Lucide name, or any uikit: name).
         */
        public static function exists(string $name): bool
        {
            $name = self::normalize($name);

            if (str_starts_with($name, 'uikit:')) {
                return strlen($name) > 6;
            }

            $lucide = self::lucide();

            return isset($lucide['icons'][$name]) || isset($lucide['aliases'][$name]);
        }

        private static function normalize(string $name): string
        {
            $name = strtolower(trim($name));

            return str_starts_with($name, 'lucide:') ? substr($name, 7) : $name;
        }

        /**
         * The icon as markup. Options:
         *   size      px (default 24)
         *   stroke    line weight in Lucide units (default 2)
         *   gradient  [from, to] colors for the line (and soft fill)
         *   fill      fill the shapes softly with the line color
         *   draw      give every shape pathLength="1", for a drawing animation in CSS
         *   class     extra class on the <svg>
         *
         * An unknown name draws a question mark in a circle, with class "is-missing".
         *
         * @param  array<string, mixed>  $options
         */
        public static function svg(string $name, array $options = []): string
        {
            $name  = self::normalize($name);
            $size  = max(8, (int) ($options['size'] ?? 24));
            $class = trim('ic-svg ' . ($options['class'] ?? ''));

            if (str_starts_with($name, 'uikit:')) {
                $icon = preg_replace('/[^a-z0-9-]/', '', substr($name, 6));

                return '<span class="' . $class . ' ic-uikit" uk-icon="icon: ' . $icon . '; width: ' . $size . '; height: ' . $size . '"></span>';
            }

            $lucide = self::lucide();
            $markup = $lucide['icons'][$lucide['aliases'][$name] ?? $name] ?? null;

            if ($markup === null) {
                $markup = '<circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/>';
                $class .= ' is-missing';
            }

            if (!empty($options['draw'])) {
                $markup = (string) preg_replace('/<(path|circle|ellipse|line|polyline|polygon|rect)\b/', '<$1 pathLength="1"', $markup);
            }

            $stroke = max(0.25, min(4, (float) ($options['stroke'] ?? 2)));
            $paint  = 'currentColor';
            $defs   = '';

            if (!empty($options['gradient'][0]) && !empty($options['gradient'][1])) {
                $id    = 'elemen-ic-g' . ++self::$gradients;
                $paint = "url(#{$id})";
                $defs  = '<defs><linearGradient id="' . $id . '" x1="0" y1="0" x2="24" y2="24" gradientUnits="userSpaceOnUse">'
                    . '<stop offset="0" stop-color="' . htmlspecialchars((string) $options['gradient'][0]) . '"/>'
                    . '<stop offset="1" stop-color="' . htmlspecialchars((string) $options['gradient'][1]) . '"/></linearGradient></defs>';
            }

            $fill = !empty($options['fill']) ? $paint . '" fill-opacity=".2' : 'none';

            return '<svg class="' . $class . '" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="' . $fill . '" stroke="' . $paint
                . '" stroke-width="' . $stroke . '" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $defs . $markup . '</svg>';
        }
    }
}
