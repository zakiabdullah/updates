<?php

/**
 * Adds Animated Background settings to YOOtheme's Section element in the builder: a button
 * in the Settings tab opens an Animated Background panel.
 *
 * The type is extended when the editor loads its configuration, so saved layouts and the
 * core element files stay untouched. Field names start with "elemen_bg_" so they never
 * clash with YOOtheme's own options.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

return [
    'builder.type' => static function (array $type): array {
        $element = (string) ($type['name'] ?? '');
        $panel   = "elemen-bg-$element";

        if ($element !== 'section' || isset($type['panels'][$panel])) {
            return $type;
        }

        $scene  = 'elemen_bg_scene_v2';
        $custom = "!$scene && !elemen_bg_preset";
        $on     = "$custom && elemen_bg_effect";

        $fields = [
            'elemen_bg_scene_v2' => [
                'label'       => 'Scene Editor 2.0',
                'description' => 'Enable editable presets, up to three layers and mobile behaviour. Existing backgrounds stay unchanged until you turn this on.',
                'type'        => 'checkbox',
                'text'        => 'Use Scene Editor 2.0',
            ],
            'elemen_bg_preset' => [
                'label'       => 'Preset',
                'description' => 'Choose a ready-made look, or use Custom to control each setting.',
                'type'        => 'select',
                'options'     => [
                    'Custom'          => '',
                    'Calm Aurora'     => 'calm-aurora',
                    'Soft Gradient'   => 'soft-gradient',
                    'Tech Grid'       => 'tech-grid',
                    'Quiet Dots'      => 'quiet-dots',
                    'Ocean Waves'     => 'ocean-waves',
                    'Playful Shapes'  => 'playful-shapes',
                ],
            ],
            'elemen_bg_effect' => [
                'label'       => 'Effect',
                'description' => 'An animated layer behind the content of the section, over its background color or image.',
                'type'        => 'select',
                'options'     => [
                    'None'          => '',
                    'Aurora'         => 'aurora',
                    'Gradient Flow'  => 'gradient',
                    'Waves'          => 'waves',
                    'Moving Pattern' => 'pattern',
                    'Floating Shapes' => 'shapes',
                ],
                'show' => $custom,
            ],
            'elemen_bg_shapes' => [
                'label'       => 'Shapes',
                'description' => 'Shapes rising slowly from the bottom to the top, with their own sizes, speeds and turns.',
                'type'        => 'select',
                'options'     => [
                    'Mixed'           => '',
                    'Circles'         => 'circle',
                    'Rounded Squares' => 'square',
                    'Rings'           => 'ring',
                    'Triangles'       => 'triangle',
                ],
                'show' => "$custom && elemen_bg_effect == 'shapes'",
            ],
            'elemen_bg_shapes_count' => [
                'label'   => 'Number of Shapes',
                'type'    => 'select',
                'options' => ['Few (8)' => 'few', 'Some (14)' => '', 'Many (22)' => 'many'],
                'show'    => "$custom && elemen_bg_effect == 'shapes'",
            ],
            'elemen_bg_pattern' => [
                'label'       => 'Pattern',
                'description' => 'Fine lines or dots drifting slowly, drawn in the first color (Auto: the primary color, or the text color on dark sections).',
                'type'        => 'select',
                'options'     => [
                    'Grid'           => '',
                    'Dots'           => 'dots',
                    'Diagonal Lines' => 'lines',
                ],
                'show' => "$custom && elemen_bg_effect == 'pattern'",
            ],
            'elemen_bg_pattern_size' => [
                'label'       => 'Pattern Size',
                'description' => 'The distance between lines or dots, in pixels. Empty: 40 for the grid, 24 for dots, 20 for lines.',
                'type'        => 'range',
                'attrs'       => ['type' => 'number', 'min' => 8, 'max' => 120, 'step' => 2],
                'show'        => "$custom && elemen_bg_effect == 'pattern'",
            ],
            'elemen_bg_pattern_edges' => [
                'type' => 'checkbox',
                'text' => 'Show the pattern up to the edges (instead of fading it out)',
                'show' => "$custom && elemen_bg_effect == 'pattern'",
            ],
            'elemen_bg_colors' => [
                'label'       => 'Colors',
                'description' => 'Auto uses the theme\'s primary color, and light glows on Primary and Secondary sections, so it fits any brand.',
                'type'        => 'select',
                'options'     => [
                    'Auto (theme colors)' => '',
                    'Corporate'           => 'corporate',
                    'Vibrant'             => 'vibrant',
                    'Custom'              => 'custom',
                ],
                'show' => $on,
            ],
            'elemen_bg_color_1' => [
                'label' => 'Color 1',
                'type'  => 'color',
                'show'  => "$on && elemen_bg_colors == 'custom'",
            ],
            'elemen_bg_color_2' => [
                'label' => 'Color 2',
                'type'  => 'color',
                'show'  => "$on && elemen_bg_colors == 'custom'",
            ],
            'elemen_bg_color_3' => [
                'label'       => 'Color 3',
                'description' => 'Optional. Empty colors are left out.',
                'type'        => 'color',
                'show'        => "$on && elemen_bg_colors == 'custom'",
            ],
            'elemen_bg_intensity' => [
                'label'       => 'Intensity',
                'description' => 'How strongly the colors show. Subtle keeps text easy to read.',
                'type'        => 'select',
                'options'     => ['Subtle' => '', 'Medium' => 'medium', 'Strong' => 'strong'],
                'show'        => $on,
            ],
            'elemen_bg_speed' => [
                'label'       => 'Speed',
                'description' => 'Still shows the effect without movement. Visitors who prefer reduced motion always see it still, and the animation pauses while the section is off screen.',
                'type'        => 'select',
                'options'     => ['Slow' => '', 'Medium' => 'medium', 'Fast' => 'fast', 'Still' => 'still'],
                'show'        => $on,
            ],
            'elemen_bg_grain' => [
                'label'       => 'Grain',
                'description' => 'A still, fine film grain over the section background, with or without an effect. It gives flat colors and gradients a little depth.',
                'type'        => 'checkbox',
                'text'        => 'Add a grain texture',
                'show'        => $custom,
            ],
        ];

        $layerEdit = "$scene && (!elemen_bg_preset || elemen_bg_tune_preset)";

        $fields['elemen_bg_tune_preset'] = [
            'label' => 'Preset adjustments',
            'type'  => 'checkbox',
            'text'  => 'Customize the preset layers',
            'show'  => "$scene && elemen_bg_preset",
        ];
        $fields['elemen_bg_mobile'] = [
            'label'       => 'Mobile Behaviour',
            'description' => 'Choose how the scene behaves on phones. Reduced-motion preferences still take priority.',
            'type'        => 'select',
            'options'     => ['Same as desktop' => '', 'Still' => 'still', 'Subtle' => 'subtle', 'Off' => 'off'],
            'show'        => $scene,
        ];
        $fields['elemen_bg_appearance'] = [
            'label'       => 'Appearance',
            'description' => 'Auto follows the section style. Light and Dark choose matching automatic palettes; custom colors stay unchanged.',
            'type'        => 'select',
            'options'     => ['Auto (section style)' => '', 'Light' => 'light', 'Dark' => 'dark'],
            'show'        => $scene,
        ];
        $fields['elemen_bg_scene_grain'] = [
            'label'   => 'Grain',
            'type'    => 'select',
            'options' => ['Use preset' => '', 'Off' => 'off', 'On' => 'on'],
            'show'    => $layerEdit,
        ];

        $layerFieldsets = [];
        $presetEffects = [
            'calm-aurora'  => [1 => 'aurora'],
            'soft-gradient' => [1 => 'gradient'],
            'tech-grid'    => [1 => 'gradient', 2 => 'pattern'],
            'quiet-dots'   => [1 => 'pattern'],
            'ocean-waves'  => [1 => 'gradient', 2 => 'waves'],
            'playful-shapes' => [1 => 'gradient', 2 => 'shapes'],
        ];

        foreach ([1, 2, 3] as $number) {
            $prefix = "elemen_bg_layer_{$number}_";
            $visible = $number === 1 ? $layerEdit : "$layerEdit && (elemen_bg_preset || elemen_bg_layer_{$number}_effect)";
            $label = "Layer {$number}";
            $patternMatches = ["elemen_bg_layer_{$number}_effect == 'pattern'"];
            $shapeMatches = ["elemen_bg_layer_{$number}_effect == 'shapes'"];

            foreach ($presetEffects as $presetName => $layerEffects) {
                if (($layerEffects[$number] ?? '') === 'pattern') {
                    $patternMatches[] = "elemen_bg_preset == '{$presetName}'";
                } elseif (($layerEffects[$number] ?? '') === 'shapes') {
                    $shapeMatches[] = "elemen_bg_preset == '{$presetName}'";
                }
            }

            $layerFieldsets[] = $prefix . 'effect';
            $fields[$prefix . 'effect'] = [
                'label'       => "$label: Effect",
                'description' => $number === 1 ? 'For Custom, an empty override keeps the current 1.x settings.' : 'Leave empty to use the preset layer, or choose an effect to add or replace this layer.',
                'type'        => 'select',
                'options'     => ['Use preset / legacy' => '', 'None' => 'none', 'Aurora' => 'aurora', 'Gradient Flow' => 'gradient', 'Waves' => 'waves', 'Pattern' => 'pattern', 'Shapes' => 'shapes'],
                'show'        => $layerEdit,
            ];
            $layerFieldsets[] = $prefix . 'colors';
            $fields[$prefix . 'colors'] = [
                'label'   => "$label: Colors",
                'type'    => 'select',
                'options' => ['Use preset / legacy' => '', 'Auto (theme)' => 'auto', 'Corporate' => 'corporate', 'Vibrant' => 'vibrant', 'Custom' => 'custom'],
                'show'    => $visible,
            ];

            foreach ([1, 2, 3] as $colorNumber) {
                $layerFieldsets[] = $prefix . "color_{$colorNumber}";
                $fields[$prefix . "color_{$colorNumber}"] = [
                    'label' => "$label: Color {$colorNumber}",
                    'type'  => 'color',
                    'show'  => "$visible && elemen_bg_layer_{$number}_colors == 'custom'",
                ];
            }

            $layerFieldsets[] = $prefix . 'intensity';
            $fields[$prefix . 'intensity'] = [
                'label'   => "$label: Intensity",
                'type'    => 'select',
                'options' => ['Use preset / legacy' => '', 'Subtle' => 'subtle', 'Medium' => 'medium', 'Strong' => 'strong'],
                'show'    => $visible,
            ];
            $layerFieldsets[] = $prefix . 'speed';
            $fields[$prefix . 'speed'] = [
                'label'   => "$label: Speed",
                'type'    => 'select',
                'options' => ['Use preset / legacy' => '', 'Slow' => 'slow', 'Medium' => 'medium', 'Fast' => 'fast', 'Still' => 'still'],
                'show'    => $visible,
            ];
            $layerFieldsets[] = $prefix . 'position';
            $fields[$prefix . 'position'] = [
                'label'   => "$label: Position",
                'type'    => 'select',
                'options' => ['Use preset / center' => '', 'Center' => 'center', 'Top Left' => 'top-left', 'Top' => 'top', 'Top Right' => 'top-right', 'Left' => 'left', 'Right' => 'right', 'Bottom Left' => 'bottom-left', 'Bottom' => 'bottom', 'Bottom Right' => 'bottom-right'],
                'show'    => $visible,
            ];
            $layerFieldsets[] = $prefix . 'direction';
            $fields[$prefix . 'direction'] = [
                'label'   => "$label: Direction",
                'type'    => 'select',
                'options' => ['Use preset / forward' => '', 'Forward' => 'forward', 'Reverse' => 'reverse'],
                'show'    => $visible,
            ];

            foreach (['pattern', 'shapes'] as $kind) {
                $kindEffect = $kind === 'pattern' ? 'pattern' : 'shapes';
                $kindMatches = $kind === 'pattern' ? $patternMatches : $shapeMatches;

                $layerFieldsets[] = $prefix . $kind;
                $fields[$prefix . $kind] = [
                    'label'   => "$label: " . ucfirst($kind),
                    'type'    => 'select',
                    'options' => $kind === 'pattern'
                        ? ['Use preset / Grid' => '', 'Grid' => 'grid', 'Dots' => 'dots', 'Lines' => 'lines']
                        : ['Use preset / Mixed' => '', 'Mixed' => 'mixed', 'Circles' => 'circle', 'Squares' => 'square', 'Rings' => 'ring', 'Triangles' => 'triangle'],
                    'show'    => "$visible && (" . implode(' || ', $kindMatches) . ')',
                ];
            }

            $layerFieldsets[] = $prefix . 'pattern_size';
            $fields[$prefix . 'pattern_size'] = [
                'label'  => "$label: Pattern Size",
                'type'   => 'range',
                'attrs'  => ['type' => 'number', 'min' => 8, 'max' => 120, 'step' => 2],
                'show'   => "$visible && (" . implode(' || ', $patternMatches) . ')',
            ];
            $layerFieldsets[] = $prefix . 'pattern_edges';
            $fields[$prefix . 'pattern_edges'] = [
                'label'   => "$label: Pattern Edges",
                'type'    => 'select',
                'options' => ['Use preset / fade' => '', 'Fade at edges' => 'fade', 'Show to edges' => 'full'],
                'show'    => "$visible && (" . implode(' || ', $patternMatches) . ')',
            ];

            $layerFieldsets[] = $prefix . 'shape_count';
            $fields[$prefix . 'shape_count'] = [
                'label'   => "$label: Shape Count",
                'type'    => 'select',
                'options' => ['Use preset / 14' => '', 'Few (8)' => 'few', 'Some (14)' => 'some', 'Many (22)' => 'many'],
                'show'    => "$visible && (" . implode(' || ', $shapeMatches) . ')',
            ];
        }

        // Add the new scene controls after the preset; legacy controls remain below for
        // existing sections and are hidden only when Scene Editor 2.0 is enabled.
        $fields = array_slice($fields, 0, 2, true)
            + ['elemen_bg_appearance' => $fields['elemen_bg_appearance'], 'elemen_bg_tune_preset' => $fields['elemen_bg_tune_preset'], 'elemen_bg_mobile' => $fields['elemen_bg_mobile'], 'elemen_bg_scene_grain' => $fields['elemen_bg_scene_grain']]
            + array_intersect_key($fields, array_fill_keys($layerFieldsets, true))
            + array_slice($fields, 2, null, true);

        // Own panel, opened from the Settings tab like YOOtheme's Image/Video and Parallax
        // panels, so the section keeps its tabs and nothing crowds the tab bar.
        $type['panels'][$panel] = [
            'title'    => 'Animated Background',
            'width'    => 500,
            'fields'   => $fields,
            'fieldset' => ['default' => ['fields' => array_keys($fields)]],
        ];

        $type['fields']['_elemen_bg_button'] = [
            'label'       => 'Animated Background',
            'description' => 'Add a slow, animated layer behind the content, e.g. soft aurora lights or a flowing gradient.',
            'type'        => 'button-panel',
            'text'        => 'Edit Settings',
            'panel'       => $panel,
        ];

        // In the Settings tab after the background options (and Shape Divider, when that
        // plugin added its button first), else at its end.
        foreach ($type['fieldset']['default']['fields'] ?? [] as $i => $tab) {
            if (!is_array($tab) || ($tab['title'] ?? '') !== 'Settings' || !is_array($tab['fields'] ?? null)) {
                continue;
            }

            $list = $tab['fields'];
            $at   = array_search('_elemen_shape_button', $list, true);
            $at   = $at === false ? array_search('_background_parallax_button', $list, true) : $at;
            $at   = $at === false ? array_search('background_color', $list, true) : $at;
            $at   = $at === false ? count($list) : $at + 1;

            while (isset($list[$at]) && is_string($list[$at]) && empty($type['fields'][$list[$at]]['label'])) {
                $at++;
            }

            array_splice($list, $at, 0, ['_elemen_bg_button']);
            $type['fieldset']['default']['fields'][$i]['fields'] = $list;
            break;
        }

        return $type;
    },
];
