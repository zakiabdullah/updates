<?php

/**
 * Builder transforms for Animated Background Pro.
 *
 * prerender (section): a section with an effect or grain gets a layer node as its first child, so
 * it renders inside the section like any other child. The node exists only while
 * rendering; the saved layout is never changed. Auto colors are resolved here, where the
 * section's style is known.
 *
 * render: runs after YOOtheme's element transform, so the section keeps its own classes
 * and gains the class the layer styles hang on. It also moves the layer before any nodes
 * other plugins added at the start (Shape Dividers), so those stay above the animation.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

$effects = ['aurora', 'gradient', 'waves', 'pattern', 'shapes'];

$legacyPresets = [
    'calm-aurora' => [
        'elemen_bg_effect'    => 'aurora',
        'elemen_bg_colors'    => '',
        'elemen_bg_intensity' => '',
        'elemen_bg_speed'     => '',
        'elemen_bg_grain'     => true,
    ],
    'soft-gradient' => [
        'elemen_bg_effect'    => 'gradient',
        'elemen_bg_colors'    => '',
        'elemen_bg_intensity' => '',
        'elemen_bg_speed'     => '',
        'elemen_bg_grain'     => true,
    ],
    'tech-grid' => [
        'elemen_bg_effect'         => 'pattern',
        'elemen_bg_pattern'        => 'grid',
        'elemen_bg_pattern_size'   => 48,
        'elemen_bg_pattern_edges'  => false,
        'elemen_bg_colors'         => '',
        'elemen_bg_intensity'      => '',
        'elemen_bg_speed'          => 'still',
        'elemen_bg_grain'          => false,
    ],
    'quiet-dots' => [
        'elemen_bg_effect'        => 'pattern',
        'elemen_bg_pattern'       => 'dots',
        'elemen_bg_pattern_size'  => 28,
        'elemen_bg_pattern_edges' => false,
        'elemen_bg_colors'        => '',
        'elemen_bg_intensity'     => '',
        'elemen_bg_speed'         => 'still',
        'elemen_bg_grain'         => false,
    ],
    'ocean-waves' => [
        'elemen_bg_effect'    => 'waves',
        'elemen_bg_colors'    => 'corporate',
        'elemen_bg_intensity' => 'medium',
        'elemen_bg_speed'     => '',
        'elemen_bg_grain'     => false,
    ],
    'playful-shapes' => [
        'elemen_bg_effect'         => 'shapes',
        'elemen_bg_shapes'         => '',
        'elemen_bg_shapes_count'   => 'many',
        'elemen_bg_colors'         => 'vibrant',
        'elemen_bg_intensity'      => 'medium',
        'elemen_bg_speed'          => 'medium',
        'elemen_bg_grain'          => false,
    ],
];

$scenePresets = [
    'calm-aurora' => [
        'layers' => [['effect' => 'aurora', 'position' => 'center']],
        'grain'  => true,
    ],
    'soft-gradient' => [
        'layers' => [['effect' => 'gradient', 'position' => 'center']],
        'grain'  => true,
    ],
    'tech-grid' => [
        'layers' => [
            ['effect' => 'gradient', 'colors' => '', 'position' => 'center'],
            ['effect' => 'pattern', 'pattern' => 'grid', 'size' => 48, 'colors' => '', 'speed' => 'still', 'position' => 'top-right'],
        ],
        'grain' => false,
    ],
    'quiet-dots' => [
        'layers' => [['effect' => 'pattern', 'pattern' => 'dots', 'size' => 28, 'position' => 'center', 'speed' => 'still']],
        'grain'  => false,
    ],
    'ocean-waves' => [
        'layers' => [
            ['effect' => 'gradient', 'colors' => 'corporate', 'position' => 'center'],
            ['effect' => 'waves', 'colors' => 'corporate', 'intensity' => 'medium', 'position' => 'bottom'],
        ],
        'grain' => false,
    ],
    'playful-shapes' => [
        'layers' => [
            ['effect' => 'gradient', 'colors' => 'vibrant', 'position' => 'center'],
            ['effect' => 'shapes', 'colors' => 'vibrant', 'intensity' => 'medium', 'speed' => 'medium', 'count' => 'many', 'position' => 'center'],
        ],
        'grain' => false,
    ],
];

$legacySettingsOf = static function (array $props) use ($legacyPresets): array {
    $preset = (string) ($props['elemen_bg_preset'] ?? '');

    $settings = isset($legacyPresets[$preset]) ? array_replace($props, $legacyPresets[$preset]) : $props;

    if ($preset === 'tech-grid') {
        // Theme Auto uses a brand-coloured grid on light sections and brighter theme
        // tones on Primary/Secondary sections, instead of a fixed blue over blue.
        $settings['elemen_bg_colors'] = '';
    }

    return $settings;
};

$sceneOf = static function (object $node) use ($effects, $scenePresets, $legacySettingsOf): array {
    $props   = (array) ($node->props ?? []);
    $isV2    = !empty($props['elemen_bg_scene_v2']);
    $preset  = (string) ($props['elemen_bg_preset'] ?? '');

    if (!$isV2) {
        $settings = $legacySettingsOf($props);
        $effect   = (string) ($settings['elemen_bg_effect'] ?? '');
        $layers   = in_array($effect, $effects, true) ? [[
            'effect'    => $effect,
            'colors'    => (string) ($settings['elemen_bg_colors'] ?? ''),
            'color_1'   => (string) ($settings['elemen_bg_color_1'] ?? ''),
            'color_2'   => (string) ($settings['elemen_bg_color_2'] ?? ''),
            'color_3'   => (string) ($settings['elemen_bg_color_3'] ?? ''),
            'intensity' => (string) ($settings['elemen_bg_intensity'] ?? ''),
            'speed'     => (string) ($settings['elemen_bg_speed'] ?? ''),
            'pattern'   => (string) ($settings['elemen_bg_pattern'] ?? ''),
            'size'      => $settings['elemen_bg_pattern_size'] ?? '',
            'edges'     => !empty($settings['elemen_bg_pattern_edges']),
            'shapes'    => (string) ($settings['elemen_bg_shapes'] ?? ''),
            'count'     => (string) ($settings['elemen_bg_shapes_count'] ?? ''),
            'position'  => 'center',
            'direction' => 'forward',
        ]] : [];

        return ['layers' => $layers, 'grain' => !empty($settings['elemen_bg_grain']), 'mobile' => '', 'appearance' => 'auto', 'v2' => false];
    }

    $presetConfig = $scenePresets[$preset] ?? null;
    $tunePreset   = empty($presetConfig) || !empty($props['elemen_bg_tune_preset']);
    $baseLayers   = $presetConfig['layers'] ?? [];
    $legacy       = $legacySettingsOf($props);
    $layers       = [];

    foreach ([1, 2, 3] as $number) {
        $prefix = "elemen_bg_layer_{$number}_";
        $base   = $baseLayers[$number - 1] ?? [];

        if (!$presetConfig && $number === 1) {
            $legacyEffect = (string) ($legacy['elemen_bg_effect'] ?? '');
            if (in_array($legacyEffect, $effects, true)) {
                $base = [
                    'effect'    => $legacyEffect,
                    'colors'    => (string) ($legacy['elemen_bg_colors'] ?? ''),
                    'color_1'   => (string) ($legacy['elemen_bg_color_1'] ?? ''),
                    'color_2'   => (string) ($legacy['elemen_bg_color_2'] ?? ''),
                    'color_3'   => (string) ($legacy['elemen_bg_color_3'] ?? ''),
                    'intensity' => (string) ($legacy['elemen_bg_intensity'] ?? ''),
                    'speed'     => (string) ($legacy['elemen_bg_speed'] ?? ''),
                    'pattern'   => (string) ($legacy['elemen_bg_pattern'] ?? ''),
                    'size'      => $legacy['elemen_bg_pattern_size'] ?? '',
                    'edges'     => !empty($legacy['elemen_bg_pattern_edges']),
                    'shapes'    => (string) ($legacy['elemen_bg_shapes'] ?? ''),
                    'count'     => (string) ($legacy['elemen_bg_shapes_count'] ?? ''),
                ];
            }
        }

        $layer = array_replace([
            'effect' => '', 'colors' => '', 'intensity' => '', 'speed' => '', 'pattern' => '',
            'size' => '', 'edges' => false, 'shapes' => '', 'count' => '', 'position' => 'center',
            'direction' => 'forward', 'color_1' => '', 'color_2' => '', 'color_3' => '',
        ], $base);

        if ($tunePreset) {
            $effectOverride = (string) ($props[$prefix . 'effect'] ?? '');
            if ($effectOverride === 'none') {
                $layer['effect'] = '';
            } elseif (in_array($effectOverride, $effects, true)) {
                $layer['effect'] = $effectOverride;
            }

            $colorsOverride = (string) ($props[$prefix . 'colors'] ?? '');
            if ($colorsOverride === 'auto') {
                $layer['colors'] = '';
            } elseif (in_array($colorsOverride, ['corporate', 'vibrant', 'custom'], true)) {
                $layer['colors'] = $colorsOverride;
            }

            foreach (['intensity' => ['subtle', 'medium', 'strong'], 'speed' => ['slow', 'medium', 'fast', 'still'], 'pattern' => ['grid', 'dots', 'lines'], 'shapes' => ['mixed', 'circle', 'square', 'ring', 'triangle'], 'count' => ['few', 'some', 'many'], 'position' => ['center', 'top-left', 'top', 'top-right', 'left', 'right', 'bottom-left', 'bottom', 'bottom-right'], 'direction' => ['forward', 'reverse']] as $key => $allowed) {
                $override = (string) ($props[$prefix . ($key === 'count' ? 'shape_count' : $key)] ?? '');
                if (in_array($override, $allowed, true)) {
                    $layer[$key] = $override === 'subtle' || $override === 'slow' || $override === 'some' ? '' : $override;
                }
            }

            $sizeOverride = $props[$prefix . 'pattern_size'] ?? '';
            if (is_numeric($sizeOverride)) {
                $layer['size'] = max(8, min(120, (int) round((float) $sizeOverride)));
            }

            $edgeOverride = (string) ($props[$prefix . 'pattern_edges'] ?? '');
            if ($edgeOverride === 'full') {
                $layer['edges'] = true;
            } elseif ($edgeOverride === 'fade') {
                $layer['edges'] = false;
            }

            if (($props[$prefix . 'colors'] ?? '') === 'custom') {
                foreach ([1, 2, 3] as $colorNumber) {
                    $layer["color_{$colorNumber}"] = (string) ($props[$prefix . "color_{$colorNumber}"] ?? '');
                }
            }
        }

        if (in_array($layer['effect'], $effects, true)) {
            $layers[] = $layer;
        }
    }

    $grainMode = (string) ($props['elemen_bg_scene_grain'] ?? '');
    $grain     = $grainMode === 'on' ? true : ($grainMode === 'off' ? false : ($presetConfig['grain'] ?? false));

    return [
        'layers' => $layers,
        'grain'  => $grain,
        'mobile' => in_array($props['elemen_bg_mobile'] ?? '', ['still', 'subtle', 'off'], true) ? (string) $props['elemen_bg_mobile'] : '',
        'appearance' => in_array($props['elemen_bg_appearance'] ?? '', ['light', 'dark'], true) ? (string) $props['elemen_bg_appearance'] : 'auto',
        'v2'     => true,
    ];
};

// A section is decorated when it has at least one valid effect or grain.
$shows = static function (object $node) use ($sceneOf): bool {
    if (($node->type ?? '') !== 'section') {
        return false;
    }

    $scene = $sceneOf($node);

    return $scene['layers'] !== [] || $scene['grain'];
};

return [
    'prerender' => static function (object $node) use ($shows, $sceneOf): void {
        if (!$shows($node)) {
            return;
        }

        $scene = $sceneOf($node);
        $props = (array) ($node->props ?? []);
        $style = (string) ($props['style'] ?? '');
        $layers = $scene['layers'];

        if (!$layers && $scene['grain']) {
            $layers[] = ['effect' => ''];
        }

        $layerNodes = [];
        foreach ($layers as $index => $settings) {
            $values = [
                'effect'    => (string) ($settings['effect'] ?? ''),
                'colors'    => (string) ($settings['colors'] ?? ''),
                'intensity' => (string) ($settings['intensity'] ?? ''),
                'speed'     => (string) ($settings['speed'] ?? ''),
                'style'     => $style,
                'pattern'   => (string) ($settings['pattern'] ?? ''),
                'size'      => $settings['size'] ?? '',
                'edges'     => !empty($settings['edges']),
                'shapes'    => (string) ($settings['shapes'] ?? ''),
                'count'     => (string) ($settings['count'] ?? ''),
                'position'  => (string) ($settings['position'] ?? 'center'),
                'direction' => (string) ($settings['direction'] ?? 'forward'),
                'grain'     => $index === array_key_last($layers) && $scene['grain'],
                'mobile'    => $scene['mobile'],
                'appearance' => $scene['appearance'],
                'v2'        => $scene['v2'],
                // Keep shape placement stable while allowing each layer its own scene.
                'seed'      => crc32(json_encode([$props, $node->children ?? [], $index]) ?: ''),
            ];

            foreach ([1, 2, 3] as $number) {
                $values["color_$number"] = (string) ($settings["color_$number"] ?? '');
            }

            $layerNodes[] = (object) ['type' => 'elemen_background_pro_layer', 'props' => $values];
        }

        $node->children = array_merge($layerNodes, (array) ($node->children ?? []));
    },

    'render' => static function (object $node) use ($shows, $sceneOf): void {
        if (!$shows($node)) {
            return;
        }

        $node->attrs['class'][] = 'elemen-bg-section';
        $scene = $sceneOf($node);
        if ($scene['mobile']) {
            $node->attrs['class'][] = "elemen-bg-mobile-{$scene['mobile']}";
        }

        // The layer goes first, before nodes other plugins put at the start in their own
        // prerender (e.g. Shape Dividers), so those paint above the animation.
        $children = (array) ($node->children ?? []);
        $isLayer  = static fn ($child): bool => is_object($child) && ($child->type ?? '') === 'elemen_background_pro_layer';

        $node->children = array_merge(array_values(array_filter($children, $isLayer)), array_values(array_filter($children, static fn ($child): bool => !$isLayer($child))));
    },
];
