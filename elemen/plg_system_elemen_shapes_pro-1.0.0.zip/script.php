<?php

/**
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\Database\DatabaseInterface;
use Joomla\Filesystem\Folder;

/**
 * Installer script for plg_system_elemen_shapes_pro.
 */
return new class () implements InstallerScriptInterface {
    public function install(InstallerAdapter $adapter): bool
    {
        return true;
    }

    public function update(InstallerAdapter $adapter): bool
    {
        return true;
    }

    public function uninstall(InstallerAdapter $adapter): bool
    {
        return true;
    }

    /**
     * Stops on a PHP or Joomla version that is too old, with a message that says why.
     *
     * Joomla copies new files over old ones on update but never removes old element
     * folders, so an element dropped from the package would stay registered. Clear the
     * folder before the new files are copied.
     */
    public function preflight(string $type, InstallerAdapter $adapter): bool
    {
        if ($type !== 'uninstall' && (version_compare(PHP_VERSION, '8.1', '<') || version_compare(JVERSION, '5.0', '<'))) {
            Factory::getApplication()->enqueueMessage(Text::sprintf('PLG_SYSTEM_ELEMEN_SHAPES_PRO_REQUIREMENTS', '8.1', '5.0', PHP_VERSION, JVERSION), 'error');

            return false;
        }

        $elements = JPATH_PLUGINS . '/system/elemen_shapes_pro/elements';

        if ($type === 'update' && is_dir($elements)) {
            Folder::delete($elements);
        }

        return true;
    }

    /**
     * Plugins are installed disabled; enable it on a fresh install so the elements
     * appear in YOOtheme right away.
     *
     * A plugin that replaces an older one under another name ("replaces" in plugin.json)
     * disables that one, so the two never run side by side.
     */
    public function postflight(string $type, InstallerAdapter $adapter): bool
    {
        if ($type !== 'install' && $type !== 'update') {
            return true;
        }

        $db     = Factory::getContainer()->get(DatabaseInterface::class);
        $plugin = static fn (string $element) => $db->createQuery()
            ->update($db->quoteName('#__extensions'))
            ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
            ->where($db->quoteName('folder') . ' = ' . $db->quote('system'))
            ->where($db->quoteName('element') . ' = ' . $db->quote($element));

        if ($type === 'install') {
            $db->setQuery($plugin('elemen_shapes_pro')->set($db->quoteName('enabled') . ' = 1'))->execute();
        }

        // The elements need YOOtheme Pro; without it the plugin quietly does nothing.
        if (!is_file(JPATH_SITE . '/templates/yootheme/templateDetails.xml')) {
            Factory::getApplication()->enqueueMessage(Text::_('PLG_SYSTEM_ELEMEN_SHAPES_PRO_NO_YOOTHEME'), 'warning');
        }

        foreach (array (
  0 => 'elemen_shapes',
) as $old) {
            $db->setQuery($plugin($old)->set($db->quoteName('enabled') . ' = 0')->where($db->quoteName('enabled') . ' = 1'))->execute();

            if ($db->getAffectedRows()) {
                Factory::getApplication()->enqueueMessage(
                    Text::sprintf('PLG_SYSTEM_ELEMEN_SHAPES_PRO_REPLACED', "plg_system_$old", 'plg_system_elemen_shapes_pro'),
                    'notice'
                );
            }
        }

        return true;
    }
};
