<?php

/**
 * Custom SVG shapes: loads a site SVG file and keeps only plain drawing.
 *
 * Returns a function (path relative to the site root) => clean SVG markup, or '' when the
 * file is missing, outside the site, too large, not SVG or has nothing to draw.
 *
 * The divider uses the SVG as a CSS mask, where browsers never run scripts, so this is
 * defence in depth as much as tidying: only shapes, groups, gradients and clip paths
 * survive, with drawing attributes only. Scripts, event handlers, styles sheets, links,
 * images, foreign content, entities and every reference outside the file are dropped.
 * The root gets a viewBox and preserveAspectRatio="none", so the shape stretches to the
 * divider like the built-in ones.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

return static function (string $path, string $root = ''): string {
    static $cache = [];

    $root = rtrim(str_replace('\\', '/', $root !== '' ? $root : JPATH_ROOT), '/');

    // Site files only: no URLs, no parent folders; Joomla media suffixes are dropped.
    $path = trim(preg_replace('/[#?].*$/s', '', $path));

    if ($path === '' || preg_match('#^[a-z][a-z0-9+.-]*:|^//|\\\\|(^|/)\.\.(/|$)#i', $path) || strtolower(pathinfo($path, PATHINFO_EXTENSION)) !== 'svg') {
        return '';
    }

    $file = realpath($root . '/' . ltrim($path, '/'));

    if ($file === false || !is_file($file) || !str_starts_with(str_replace('\\', '/', $file), $root . '/') || filesize($file) > 256 * 1024) {
        return '';
    }

    $key = $file . ':' . filemtime($file);

    if (isset($cache[$key])) {
        return $cache[$key];
    }

    $xml = (string) file_get_contents($file);

    // No DTDs at all, so no entity tricks.
    if ($xml === '' || stripos($xml, '<!DOCTYPE') !== false || stripos($xml, '<!ENTITY') !== false) {
        return $cache[$key] = '';
    }

    $dom      = new DOMDocument();
    $previous = libxml_use_internal_errors(true);
    $loaded   = $dom->loadXML($xml, LIBXML_NONET | LIBXML_COMPACT);
    libxml_clear_errors();
    libxml_use_internal_errors($previous);

    $svg = $loaded ? $dom->documentElement : null;

    if (!$svg || strtolower($svg->localName) !== 'svg') {
        return $cache[$key] = '';
    }

    $elements = array_flip([
        'svg', 'g', 'defs', 'path', 'polygon', 'polyline', 'rect', 'circle', 'ellipse', 'line',
        'lineargradient', 'radialgradient', 'stop', 'clippath', 'mask',
    ]);
    $drawing = array_flip(['path', 'polygon', 'polyline', 'rect', 'circle', 'ellipse', 'line']);
    $attributes = array_flip([
        'id', 'd', 'points', 'x', 'y', 'width', 'height', 'cx', 'cy', 'r', 'rx', 'ry', 'x1', 'y1', 'x2', 'y2',
        'fx', 'fy', 'transform', 'fill', 'fill-opacity', 'fill-rule', 'opacity', 'stroke', 'stroke-width',
        'stroke-opacity', 'stroke-linecap', 'stroke-linejoin', 'stroke-miterlimit', 'clip-rule', 'clip-path',
        'mask', 'offset', 'stop-color', 'stop-opacity', 'gradientunits', 'gradienttransform', 'spreadmethod',
        'clippathunits', 'maskunits', 'maskcontentunits', 'viewbox',
    ]);
    $properties = array_flip(['fill', 'fill-opacity', 'fill-rule', 'opacity', 'stroke', 'stroke-width', 'stroke-opacity', 'stroke-linecap', 'stroke-linejoin', 'stop-color', 'stop-opacity']);

    // A value may only point inside the file (url(#id)) and holds no markup or script.
    $safe = static function (string $value): bool {
        if (preg_match('/[<>"\\\\]|javascript:|expression\s*\(|@import/i', $value)) {
            return false;
        }

        $value = preg_replace('/url\(\s*#[\w.-]+\s*\)/i', '', $value);

        return stripos($value, 'url(') === false && stripos($value, '&') === false;
    };

    $count = 0;

    $clean = static function (DOMElement $element) use (&$clean, &$count, $elements, $drawing, $attributes, $properties, $safe): void {
        // Inline style: kept only as the drawing properties it holds, as attributes. Like in
        // CSS, a style property wins over the attribute of the same name.
        if ($element->hasAttribute('style')) {
            foreach (explode(';', $element->getAttribute('style')) as $rule) {
                [$name, $value] = array_map('trim', explode(':', $rule, 2) + [1 => '']);
                $name = strtolower($name);

                if (isset($properties[$name]) && $value !== '' && $safe($value)) {
                    $element->setAttribute($name, $value);
                }
            }
        }

        foreach (iterator_to_array($element->attributes) as $attribute) {
            $name = strtolower($attribute->nodeName);

            if ($attribute->namespaceURI || !isset($attributes[$name]) || !$safe($attribute->nodeValue)) {
                $element->removeAttributeNode($attribute);
            }
        }

        if (isset($drawing[strtolower($element->localName)])) {
            $count++;
        }

        foreach (iterator_to_array($element->childNodes) as $child) {
            if ($child instanceof DOMElement && isset($elements[strtolower($child->localName)]) && $child->namespaceURI === $element->namespaceURI) {
                $clean($child);
            } elseif (!($child instanceof DOMText && trim($child->nodeValue) === '')) {
                // Scripts, styles, text, comments, images, links, foreign content, …
                $element->removeChild($child);
            }
        }
    };

    $width   = (float) $svg->getAttribute('width');
    $height  = (float) $svg->getAttribute('height');
    $viewBox = preg_split('/[\s,]+/', trim($svg->getAttribute('viewBox')));

    $clean($svg);

    if (count($viewBox) === 4 && is_numeric($viewBox[2]) && is_numeric($viewBox[3]) && $viewBox[2] > 0 && $viewBox[3] > 0) {
        $viewBox = implode(' ', array_map('floatval', $viewBox));
    } elseif ($width > 0 && $height > 0) {
        $viewBox = "0 0 $width $height";
    } else {
        return $cache[$key] = '';
    }

    if (!$count) {
        return $cache[$key] = '';
    }

    foreach (['width', 'height', 'x', 'y'] as $name) {
        $svg->removeAttribute($name);
    }

    $svg->setAttribute('viewBox', $viewBox);
    $svg->setAttribute('preserveAspectRatio', 'none');

    // Plain SVG namespace markup, without the XML declaration.
    $out = $dom->saveXML($svg);
    $out = preg_replace('/\s+xmlns:\w+="[^"]*"/', '', (string) $out);

    if (!str_contains($out, 'xmlns="http://www.w3.org/2000/svg"')) {
        $out = preg_replace('/^<svg/', '<svg xmlns="http://www.w3.org/2000/svg"', $out);
    }

    return $cache[$key] = $out;
};
