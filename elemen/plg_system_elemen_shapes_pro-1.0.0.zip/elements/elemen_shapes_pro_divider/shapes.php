<?php

/**
 * Shape Divider shapes, drawn for Elemen.
 *
 * Every shape is drawn in a 1200 x 100 box as one or more open curves from the left edge
 * (x = 0) to the right edge (x = 1200), using absolute commands only. The divider closes
 * each curve along the section edge (y = 0), so the area between the edge and the curve
 * is filled. Inverting closes it along the far side and mirrors it back to the edge.
 * Layers are drawn in order with their opacity, the last one on top.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

// Repeating teeth, drops and bumps, so the source stays readable.
$teeth = static function (int $count, int $depth): string {
    $w = 1200 / $count;
    $d = 'M0,0';

    for ($i = 0; $i < $count; $i++) {
        $d .= sprintf(' L%s,%d L%s,0', round($i * $w + $w / 2, 2), $depth, round(($i + 1) * $w, 2));
    }

    return $d;
};

$bumps = static function (array $widths, array $depths, int $base): string {
    $x = 0;
    $d = "M0,$base";

    foreach ($widths as $i => $w) {
        $y  = $base + $depths[$i % count($depths)];
        $d .= sprintf(' C%d,%d %d,%d %d,%d', $x, $y, $x + $w, $y, $x + $w, $base);
        $x += $w;
    }

    return $d;
};

$drops = static function (array $points, int $base): string {
    // Each drop: [centre x, half width, length below the band].
    $d = "M0,$base";

    foreach ($points as [$x, $r, $len]) {
        $d .= sprintf(
            ' L%d,%d C%d,%d %d,%d %d,%d C%d,%d %d,%d %d,%d',
            $x - $r, $base,
            $x - $r / 3, $base + 4, $x - $r, $base + $len, $x, $base + $len,
            $x + $r, $base + $len, $x + $r / 3, $base + 4, $x + $r, $base
        );
    }

    return $d . " L1200,$base";
};

return [
    'wave' => [
        'title'  => 'Wave',
        'layers' => [['M0,55 C200,105 400,5 600,55 C800,105 1000,5 1200,55', 1]],
    ],
    'waves' => [
        'title'  => 'Waves (Layered)',
        'layers' => [
            ['M0,80 C150,100 330,40 520,70 C720,100 900,30 1200,75', .3],
            ['M0,55 C220,95 380,25 600,60 C820,95 1000,20 1200,50', .6],
            ['M0,30 C180,70 420,0 650,35 C860,65 1030,5 1200,25', 1],
        ],
    ],
    'curve' => [
        'title'  => 'Curve',
        'layers' => [['M0,0 Q600,200 1200,0', 1]],
    ],
    'curve_asymmetric' => [
        'title'  => 'Curve (Asymmetric)',
        'layers' => [['M0,0 C250,140 900,110 1200,0', 1]],
    ],
    'arc_layers' => [
        'title'  => 'Arcs (Layered)',
        'layers' => [
            ['M0,0 Q600,200 1200,0', .3],
            ['M0,0 Q600,140 1200,0', .6],
            ['M0,0 Q600,80 1200,0', 1],
        ],
    ],
    'tilt' => [
        'title'  => 'Tilt',
        'layers' => [['M0,0 L1200,100', 1]],
    ],
    'tilt_layers' => [
        'title'  => 'Tilt (Layered)',
        'layers' => [
            ['M0,40 L1200,100', .3],
            ['M0,20 L1200,70', .6],
            ['M0,0 L1200,40', 1],
        ],
    ],
    'triangle' => [
        'title'  => 'Triangle',
        'layers' => [['M0,0 L600,100 L1200,0', 1]],
    ],
    'triangle_asymmetric' => [
        'title'  => 'Triangle (Asymmetric)',
        'layers' => [['M0,0 L850,100 L1200,0', 1]],
    ],
    'arrow' => [
        'title'  => 'Arrow',
        'layers' => [['M0,0 L540,0 L600,100 L660,0 L1200,0', 1]],
    ],
    'split' => [
        'title'  => 'Split',
        'layers' => [['M0,60 L520,60 L600,0 L680,60 L1200,60', 1]],
    ],
    'book' => [
        'title'  => 'Book',
        'layers' => [['M0,0 Q420,30 600,100 Q780,30 1200,0', 1]],
    ],
    'zigzag' => [
        'title'  => 'Zigzag',
        'layers' => [[$teeth(24, 100), 1]],
    ],
    'clouds' => [
        'title'  => 'Clouds',
        'layers' => [
            [$bumps([110, 160, 90, 140, 120, 180, 100, 150, 150], [40, 55, 35, 50, 45, 60, 38, 52, 46], 45), .5],
            [$bumps([150, 100, 170, 120, 90, 160, 140, 130, 140], [30, 42, 36, 46, 28, 40, 34, 44, 32], 20), 1],
        ],
    ],
    'mountains' => [
        'title'  => 'Mountains',
        'layers' => [
            ['M0,60 L90,85 L210,40 L330,95 L460,50 L560,80 L700,30 L820,90 L950,45 L1080,85 L1200,55', .5],
            ['M0,20 L120,65 L240,30 L380,80 L520,25 L640,60 L760,15 L900,70 L1020,35 L1120,60 L1200,30', 1],
        ],
    ],
    'drops' => [
        'title'  => 'Drops',
        'layers' => [[$drops([[90, 22, 45], [260, 18, 70], [410, 26, 40], [590, 20, 65], [760, 24, 50], [930, 18, 72], [1100, 22, 42]], 25), 1]],
    ],
    'pyramids' => [
        'title'  => 'Pyramids',
        'layers' => [['M0,0 L360,0 L360,25 L460,25 L460,50 L540,50 L540,75 L660,75 L660,50 L740,50 L740,25 L840,25 L840,0 L1200,0', 1]],
    ],
];
