<?php

/**
 * Builder transforms for Shape Dividers Pro.
 *
 * prerender (layout): runs before its sections, and notes on every section the color of
 * the section before and after it, for dividers set to Auto.
 *
 * prerender (section): runs before its rows and columns, and notes on every column the
 * color of the section, for column dividers set to Auto.
 *
 * prerender (section, column): an element with a top or bottom shape gets a divider node
 * for each, as its first children, so they render inside it like any other child. In a
 * column they render inside its panel (style, background, image or video box), so a column
 * without one shows no divider. The divider nodes exist only while rendering; the saved
 * layout is never changed.
 *
 * render: runs after YOOtheme's element transform, so the element keeps its own classes
 * and gains the class the divider styles hang on.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

$sides = static function (object $node): array {
    $props = (array) ($node->props ?? []);

    return array_values(array_filter(['top', 'bottom'], static fn (string $side): bool => !empty($props["elemen_shape_$side"])));
};

// The color a section shows to its neighbours, as divider color props.
$colorOf = static function (?object $section): array {
    if (!$section) {
        return ['color' => 'default'];
    }

    $props = (array) ($section->props ?? []);
    $media = !empty($props['image']) || !empty($props['video']);

    // Image or video: its background color, if set, is what surrounds the media.
    if ($media && !empty($props['media_background'])) {
        return ['color' => 'custom', 'color_custom' => $props['media_background']];
    }

    if (in_array($props['style'] ?? '', ['default', 'muted', 'primary', 'secondary'], true)) {
        return ['color' => $props['style']];
    }

    if (!$media && (!empty($props['background_color']) || !empty($props['background_color_gradient']))) {
        return [
            'color'          => 'custom',
            'color_custom'   => $props['background_color'] ?? '',
            'color_gradient' => $props['background_color_gradient'] ?? '',
        ];
    }

    // No background of its own: the page background shows, which the default style matches.
    return ['color' => 'default'];
};

// A column shows dividers only in its panel: the box YOOtheme draws for a style, background
// color, image or video. Without one the column is only a grid cell with gutter padding.
$hasPanel = static function (object $node): bool {
    $props = (array) ($node->props ?? []);

    foreach (['style', 'background_color', 'background_color_gradient', 'image', 'video'] as $key) {
        if (!empty($props[$key])) {
            return true;
        }
    }

    return false;
};

// Every column inside a node (rows, and rows nested in columns), depth first.
$columns = static function (object $node) use (&$columns): array {
    $found = [];

    foreach ((array) ($node->children ?? []) as $child) {
        if (!is_object($child)) {
            continue;
        }

        if (($child->type ?? '') === 'column') {
            $found[] = $child;
        }

        array_push($found, ...$columns($child));
    }

    return $found;
};

$shows = static fn (object $node): bool => match ($node->type ?? '') {
    'section' => (bool) $sides($node),
    'column'  => $sides($node) && $hasPanel($node),
    default   => false,
};

return [
    'prerender' => static function (object $node) use ($sides, $colorOf, $columns, $shows): void {
        if (($node->type ?? '') === 'layout') {
            $sections = array_values(array_filter(
                (array) ($node->children ?? []),
                static fn ($child): bool => is_object($child) && ($child->type ?? '') === 'section'
                    && (((array) ($child->props ?? []))['status'] ?? '') !== 'disabled'
            ));

            foreach ($sections as $i => $section) {
                if (!$sides($section)) {
                    continue;
                }

                $section->props = (array) ($section->props ?? []);
                $section->props['_elemen_shape_auto'] = [
                    'top'    => $colorOf($sections[$i - 1] ?? null),
                    'bottom' => $colorOf($sections[$i + 1] ?? null),
                ];
            }

            return;
        }

        if (($node->type ?? '') === 'section') {
            // Auto in a column: the section around it, so the shape looks cut out of the column.
            $around = null;

            foreach ($columns($node) as $column) {
                if ($sides($column)) {
                    $column->props = (array) ($column->props ?? []);
                    $around ??= $colorOf($node);
                    $column->props['_elemen_shape_auto'] = ['top' => $around, 'bottom' => $around];
                }
            }
        }

        if (!$shows($node)) {
            return;
        }

        $found    = $sides($node);
        $props    = (array) $node->props;
        $dividers = [];

        foreach ($found as $side) {
            $values = ['side' => $side];

            foreach ($props as $key => $value) {
                if (str_starts_with($key, "elemen_shape_$side")) {
                    $values[substr($key, strlen("elemen_shape_$side")) ?: 'shape'] = $value;
                }
            }

            $values = array_combine(
                array_map(static fn ($key) => ltrim((string) $key, '_'), array_keys($values)),
                $values
            );

            // Auto (empty): the neighbour's color, or the default style outside a layout.
            if (($values['color'] ?? '') === '' || $values['color'] === 'auto') {
                $auto   = $props['_elemen_shape_auto'][$side] ?? $colorOf(null);
                $values = ['auto' => true] + $auto + array_diff_key($values, array_flip(['color', 'color_custom']));
            }

            // Columns are smaller than sections: a lower default height.
            if ($node->type === 'column' && !is_numeric($values['height'] ?? null)) {
                $values['height'] = 60;
            }

            $dividers[] = (object) ['type' => 'elemen_shapes_pro_divider', 'props' => $values];
        }

        $node->children = array_merge($dividers, (array) ($node->children ?? []));
    },

    'render' => static function (object $node) use ($shows): void {
        if ($shows($node)) {
            $node->attrs['class'][] = "elemen-shapes-{$node->type}";
        }
    },
];
