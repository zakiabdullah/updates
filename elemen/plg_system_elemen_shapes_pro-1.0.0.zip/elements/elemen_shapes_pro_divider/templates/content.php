<?php

// Decorative only: nothing to index or search.
\defined('_JEXEC') or die;
