<?php

/**
 * Shape Divider: one shape along the top or bottom edge of a section.
 *
 * The shape is a CSS mask over a plain box. The box takes its color from the section
 * style classes (uk-section-default, -muted, …), so the divider matches the theme's
 * section colors exactly, including gradients, and follows style changes.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var array<string, mixed> $props
 */

use Joomla\CMS\Uri\Uri;
use YOOtheme\Metadata;

use function YOOtheme\app;

\defined('_JEXEC') or die;

$shapes = require \dirname(__DIR__) . '/shapes.php';

$side   = ($props['side'] ?? '') === 'bottom' ? 'bottom' : 'top';
$invert = !empty($props['invert']);
$flipY  = false;

if (($props['shape'] ?? '') === 'custom') {
    // Custom SVG: cleaned by svg.php; inverting flips it vertically.
    $svg   = (require \dirname(__DIR__) . '/svg.php')((string) ($props['svg'] ?? ''));
    $flipY = $invert;
} elseif ($shape = $shapes[$props['shape'] ?? ''] ?? null) {
    // Built-in: each curve closed along the section edge, or along the far side and
    // mirrored back when inverted, so the inverted shape still touches the edge.
    $paths = '';

    foreach ($shape['layers'] as [$d, $opacity]) {
        $paths .= sprintf(
            "<path d='%s %s'%s/>",
            $d,
            $invert ? 'L1200,100 L0,100 Z' : 'L1200,0 L0,0 Z',
            $opacity < 1 ? " fill-opacity='{$opacity}'" : ''
        );
    }

    if ($invert) {
        $paths = "<g transform='matrix(1 0 0 -1 0 100)'>{$paths}</g>";
    }

    $svg = "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1200 100' preserveAspectRatio='none'>{$paths}</svg>";
}

if (empty($svg)) {
    return;
}

// Unquoted: rawurlencode leaves no quotes, spaces or brackets, and Joomla's SEF plugin
// only recognises the data: scheme (and skips the URL) when it sees no &quot; before it.
$mask = 'url(data:image/svg+xml,' . rawurlencode($svg) . ')';

// Sizes in whole pixels and percent, within the ranges of the fields.
$number = static function ($value, int $min, int $max): ?int {
    return is_numeric($value) ? max($min, min($max, (int) round((float) $value))) : null;
};

$height  = $number($props['height'] ?? null, 1, 1000) ?? 100;
$heightS = $number($props['height_s'] ?? null, 1, 1000);
$width   = $number($props['width'] ?? null, 100, 500) ?? 100;

// Color: a section style, or a custom color or gradient (Auto passes the neighbour's
// background this way). Only characters that colors and gradients use are allowed.
$clean    = static fn ($value): string => trim((string) preg_replace('/[^#a-zA-Z0-9(),.%\s-]/', '', (string) $value));
$color    = (string) ($props['color'] ?? 'default');
$custom   = $clean($props['color_custom'] ?? '');
$gradient = $clean($props['color_gradient'] ?? '');

if ($color === 'custom' && $custom === '' && $gradient === '') {
    $color = 'default';
}

$style = [
    "--esd-mask: {$mask}",
    "--esd-w: {$width}%",
    '--esd-fx: ' . (!empty($props['flip']) ? -1 : 1),
];

if ($flipY) {
    $style[] = '--esd-fy: -1';
}

if ($color === 'custom' && $custom !== '') {
    $style[] = "background-color: {$custom}";
}

if ($color === 'custom' && $gradient !== '') {
    $style[] = "background-image: {$gradient}";
}

// Assets: loaded once per page, only when a divider is shown.
$assets   = \dirname(__DIR__) . '/assets';
$assetUrl = static fn (string $file): string => Uri::root(true) . '/'
    . str_replace('\\', '/', substr($assets, strlen(JPATH_ROOT) + 1)) . "/{$file}?v=" . @filemtime("{$assets}/{$file}");

app(Metadata::class)->set('style:elemen-shapes', ['href' => $assetUrl('shapes.css')]);

// Plain markup: the mask is a data URI, which YOOtheme's attribute expressions must not parse.
$e       = static fn (string $value): string => htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
$classes = array_filter([
    'elemen-shapes',
    "elemen-shapes-{$side}",
    !empty($props['front']) ? 'elemen-shapes-front' : '',
    !empty($props['auto']) ? 'elemen-shapes-auto' : '',
    in_array($props['visibility'] ?? '', ['s', 'm'], true) ? "uk-visible@{$props['visibility']}" : '',
]);

$animation = in_array($props['animation'] ?? '', ['sway', 'breathe'], true) ? $props['animation'] : '';
$speed     = in_array($props['animation_speed'] ?? '', ['slow', 'fast'], true) ? $props['animation_speed'] : '';
$vars = "--esd-h: {$height}px;" . ($heightS ? " --esd-h-s: {$heightS}px;" : '');
$tone = in_array($color, ['default', 'muted', 'primary', 'secondary'], true) ? " uk-section-{$color}" : '';
?>
<div class="<?= $e(implode(' ', $classes)) ?>" style="<?= $e($vars) ?>" aria-hidden="true"><div class="elemen-shapes-shape<?= $tone ?><?= $animation ? " elemen-shapes-{$animation}" : '' ?><?= $animation && $speed ? " elemen-shapes-{$speed}" : '' ?>" style="<?= $e(implode('; ', $style) . ';') ?>"></div></div>
