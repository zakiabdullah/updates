<?php

/**
 * Adds Shape Divider settings to YOOtheme's Section and Column elements in the builder: a
 * button in the Settings tab opens a Shape Divider panel with the top and bottom options.
 *
 * The types are extended when the editor loads its configuration, so saved layouts and
 * the core element files stay untouched. Field names start with "elemen_shape_" so
 * they never clash with YOOtheme's own options.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

return [
    'builder.type' => static function (array $type): array {
        $element = (string) ($type['name'] ?? '');
        $panel   = "elemen-shapes-$element";

        if (!in_array($element, ['section', 'column'], true) || isset($type['panels'][$panel])) {
            return $type;
        }

        $column = $element === 'column';

        $shapes = ['None' => ''];

        foreach (require __DIR__ . '/shapes.php' as $name => $shape) {
            $shapes[$shape['title']] = $name;
        }

        $shapes['Custom SVG'] = 'custom';

        $fields = $groups = [];

        foreach (['top' => 'Top', 'bottom' => 'Bottom'] as $side => $label) {
            $p = "elemen_shape_$side";

            $fields += [
                $p => [
                    'label'       => "$label Shape",
                    'description' => "A shape along the $side edge of the $element."
                        . ($column ? ' Shown when the column has a style, background color, image or video.' : ''),
                    'type'    => 'select',
                    'options' => $shapes,
                ],
                "{$p}_svg" => [
                    'label'       => 'SVG',
                    'description' => 'An SVG file from the site. It is stretched to the divider and drawn in the divider color; only its shapes are used. Draw it with the filled part along the top edge.',
                    'type'        => 'image',
                    'show'        => "$p == 'custom'",
                ],
                "{$p}_color" => [
                    'label'   => 'Color',
                    'type'    => 'select',
                    'description' => match (true) {
                        $column         => 'Auto uses the background of the section around the column, so the shape looks cut out of the column.',
                        $side === 'top' => 'Auto uses the background of the section above, or the default style for the first section.',
                        default         => 'Auto uses the background of the section below, or the default style for the last section.',
                    },
                    'options' => [
                        'Auto'      => '',
                        'Default'   => 'default',
                        'Muted'     => 'muted',
                        'Primary'   => 'primary',
                        'Secondary' => 'secondary',
                        'Custom'    => 'custom',
                    ],
                    'show' => $p,
                ],
                "{$p}_color_custom" => [
                    'label' => 'Custom Color',
                    'type'  => 'color',
                    'show'  => "$p && {$p}_color == 'custom'",
                ],
                "{$p}_height" => [
                    'label'       => 'Height',
                    'description' => 'Height in pixels. Phone sets a smaller height below 640px; leave it empty to use the same height.',
                    'type'        => 'range',
                    'attrs'       => ['type' => 'number', 'min' => 10, 'max' => 400, 'step' => 5, 'placeholder' => $column ? '60' : '100'],
                    'show'        => $p,
                ],
                "{$p}_height_s" => [
                    'label' => 'Height Phone',
                    'type'  => 'range',
                    'attrs' => ['type' => 'number', 'min' => 10, 'max' => 400, 'step' => 5],
                    'show'  => $p,
                ],
                "{$p}_width" => [
                    'label'       => 'Width',
                    'description' => "Stretch the shape wider than the $element, in percent. The part outside the $element is cut off.",
                    'type'        => 'range',
                    'attrs'       => ['type' => 'number', 'min' => 100, 'max' => 300, 'step' => 10, 'placeholder' => '100'],
                    'show'        => $p,
                ],
                "{$p}_flip" => [
                    'type' => 'checkbox',
                    'text' => 'Flip horizontally',
                    'show' => $p,
                ],
                "{$p}_invert" => [
                    'type' => 'checkbox',
                    'text' => 'Invert the shape',
                    'show' => $p,
                ],
                "{$p}_animation" => [
                    'label'       => 'Animation',
                    'description' => 'A slow, endless movement. Visitors who prefer reduced motion see the shape still.',
                    'type'        => 'select',
                    'options'     => [
                        'None'                    => '',
                        'Sway (side to side)'     => 'sway',
                        'Breathe (grow and shrink)' => 'breathe',
                    ],
                    'show' => $p,
                ],
                "{$p}_animation_speed" => [
                    'label'   => 'Speed',
                    'type'    => 'select',
                    'options' => ['Slow' => 'slow', 'Medium' => '', 'Fast' => 'fast'],
                    'show'    => "$p && {$p}_animation",
                ],
                "{$p}_visibility" => [
                    'label'       => 'Visibility',
                    'description' => 'Hide the shape on small screens, where it can crowd the content.',
                    'type'        => 'select',
                    'options'     => [
                        'Always'                 => '',
                        'Hide on phones (< 640px)' => 's',
                        'Hide below tablet landscape (< 960px)' => 'm',
                    ],
                    'show' => $p,
                ],
                "{$p}_front" => [
                    'type' => 'checkbox',
                    'text' => 'Show in front of the content',
                    'show' => $p,
                ],
            ];

            array_push($groups, $p, "{$p}_svg", "{$p}_color", "{$p}_color_custom", "{$p}_height", "{$p}_height_s", "{$p}_width", "{$p}_flip", "{$p}_invert", "{$p}_front", "{$p}_animation", "{$p}_animation_speed", "{$p}_visibility");
        }

        // Own panel, opened from the Settings tab like YOOtheme's Image/Video and Parallax
        // panels, so the section keeps its tabs and nothing crowds the tab bar.
        $type['panels'][$panel] = [
            'title'    => 'Shape Divider',
            'width'    => 500,
            'fields'   => $fields,
            'fieldset' => ['default' => ['fields' => $groups]],
        ];

        $button = [
            'label'       => 'Shape Divider',
            'description' => "Add a shape along the top or bottom edge of the $element, e.g. a wave or a curve.",
            'type'        => 'button-panel',
            'text'        => 'Edit Settings',
            'panel'       => $panel,
        ];

        $type['fields']['_elemen_shape_button'] = $button;

        // In the Settings tab after the background color options, else at its end.
        foreach ($type['fieldset']['default']['fields'] ?? [] as $i => $tab) {
            if (!is_array($tab) || ($tab['title'] ?? '') !== 'Settings' || !is_array($tab['fields'] ?? null)) {
                continue;
            }

            $list = $tab['fields'];
            $at   = array_search('_background_parallax_button', $list, true);
            $at   = $at === false ? array_search('background_color', $list, true) : $at;
            $at   = $at === false ? count($list) : $at + 1;

            // Fields without a label (e.g. the column's "Round corners" checkbox, which
            // carries the background description) continue the option above them.
            while (isset($list[$at]) && is_string($list[$at]) && empty($type['fields'][$list[$at]]['label'])) {
                $at++;
            }

            array_splice($list, $at, 0, ['_elemen_shape_button']);
            $type['fieldset']['default']['fields'][$i]['fields'] = $list;
            break;
        }

        return $type;
    },
];
