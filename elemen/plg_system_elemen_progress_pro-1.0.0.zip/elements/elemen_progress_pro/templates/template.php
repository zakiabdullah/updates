<?php

/**
 * Progress Bar Pro: bars, circles or half circles that fill when they scroll into view.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var \YOOtheme\Builder $builder
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<int, object> $children
 */

use Joomla\CMS\Uri\Uri;
use YOOtheme\Metadata;

use function YOOtheme\app;

\defined('_JEXEC') or die;

// Display options: fields of every item can be hidden without deleting them. Layouts saved
// before the options existed don't have them, so they count as shown.
$hidden = [];

foreach (['title' => ['title'], 'content' => ['content'], 'goal' => ['goal', 'goal_label']] as $option => $fields) {
    if (!($props["show_{$option}"] ?? true)) {
        array_push($hidden, ...$fields);
    }
}

foreach ($hidden ? $children : [] as $child) {
    foreach ($hidden as $field) {
        if (is_array($child->props ?? null)) {
            $child->props[$field] = '';
        } elseif (is_object($child->props ?? null)) {
            $child->props->{$field} = '';
        }
    }
}

// Render the items first: if all are empty, render nothing and load no assets.
$items = [];

foreach ($children as $i => $child) {
    $html = (string) $builder->render($child, ['element' => $props, 'index' => $i]);

    if (trim($html) !== '') {
        $items[] = $html;
    }
}

if (!$items) {
    return;
}

// Assets. The URL is worked out from this file's location, so it follows the plugin folder.
$assets   = \dirname(__DIR__) . '/assets';
$assetUrl = static fn (string $file): string => Uri::root(true) . '/'
    . str_replace('\\', '/', substr($assets, strlen(JPATH_ROOT) + 1)) . "/{$file}?v=" . @filemtime("{$assets}/{$file}");
$metadata = app(Metadata::class);

$metadata->set('style:elemen-progress-pro', ['href' => $assetUrl('progress-pro.css')]);
$metadata->set('script:elemen-progress-pro', ['src' => $assetUrl('progress-pro.js'), 'defer' => true]);

$color = static fn ($value): string => preg_match('/^[#(),.%\w\s-]+$/', trim((string) $value)) ? trim((string) $value) : '';
$vars  = ['--pp-duration: ' . (int) ($props['duration'] ?: 1500) . 'ms'];

if ($props['layout'] === 'bar') {
    $vars[] = '--pp-height: ' . (int) ($props['bar_height'] ?: 10) . 'px';
}

if ($color($props['track_color'])) {
    $vars[] = '--pp-track: ' . $color($props['track_color']);
}

$el = $this->el('div', [

    'class' => [
        'elemen-progress-pro',
        'pp-layout-{layout}',
        'pp-rounded' => $props['layout'] === 'bar' ? $props['bar_rounded'] : $props['circle_rounded'],
        'pp-striped {@layout: bar} {@bar_striped}',
        'pp-stripes-animated {@layout: bar} {@bar_striped} {@bar_stripes_animated}',
        'pp-label-{label_position} {@layout: bar}',
    ],

    'style'          => implode('; ', $vars),
    'data-pp-repeat' => $props['repeat'] ? 'true' : false,

]);

$grid = $this->el('div', [

    'class' => [
        'uk-child-width-1-{grid_default}',
        'uk-child-width-1-{grid_small}@s',
        'uk-child-width-1-{grid_medium}@m',
        'uk-child-width-1-{grid_large}@l',
        'uk-grid-column-{grid_column_gap}',
        'uk-grid-row-{grid_row_gap}',
        'uk-flex-center {@layout: circle|semicircle}',
    ],

    'uk-grid' => true,

]);

?>
<?= $el($props, $attrs) ?>
    <?= $grid($props) ?>
        <?php foreach ($items as $html) : ?>
        <div><?= $html ?></div>
        <?php endforeach ?>
    <?= $grid->end() ?>
<?= $el->end() ?>
