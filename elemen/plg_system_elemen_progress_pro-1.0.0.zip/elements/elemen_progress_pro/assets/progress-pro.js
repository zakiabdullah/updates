/* Elemen: Progress Bar Pro — fills bars and circles when they scroll into view. No dependencies. */
(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const ease = (t) => 1 - Math.pow(1 - t, 3);

    function countUp(el, duration, delay) {
        const to = Number(el.dataset.ppTo) || 0;
        const decimals = Number(el.dataset.ppDecimals) || 0;

        cancelAnimationFrame(el.ppFrame);
        clearTimeout(el.ppTimer);

        if (reduce) {
            el.textContent = to.toFixed(decimals);
            return;
        }

        el.textContent = (0).toFixed(decimals);
        el.ppTimer = setTimeout(() => {
            let begin = null;
            const step = (now) => {
                begin ??= now;
                const t = Math.min(1, (now - begin) / duration);
                el.textContent = (to * ease(t)).toFixed(decimals);

                if (t < 1) {
                    el.ppFrame = requestAnimationFrame(step);
                }
            };

            el.ppFrame = requestAnimationFrame(step);
        }, delay);
    }

    function start(root) {
        root.classList.add('pp-in-view');

        const duration = parseFloat(getComputedStyle(root).getPropertyValue('--pp-duration')) || 1500;

        root.querySelectorAll('.pp-item').forEach((item) => {
            const delay = parseFloat(getComputedStyle(item).getPropertyValue('--pp-delay')) || 0;
            item.querySelectorAll('.pp-count').forEach((el) => countUp(el, duration, delay));
        });
    }

    function reset(root) {
        root.classList.remove('pp-in-view');
        root.querySelectorAll('.pp-count').forEach((el) => {
            cancelAnimationFrame(el.ppFrame);
            clearTimeout(el.ppTimer);
            el.textContent = (0).toFixed(Number(el.dataset.ppDecimals) || 0);
        });
    }

    const observer = 'IntersectionObserver' in window
        ? new IntersectionObserver((entries) => {
            entries.forEach(({ target, isIntersecting }) => {
                if (isIntersecting) {
                    start(target);

                    if (target.dataset.ppRepeat !== 'true') {
                        observer.unobserve(target);
                    }
                } else if (target.dataset.ppRepeat === 'true' && !reduce) {
                    reset(target);
                }
            });
        }, { threshold: 0.3 })
        : null;

    function init(root) {
        root.querySelectorAll('.elemen-progress-pro:not([data-pp-ready])').forEach((el) => {
            if (!observer) {
                return; // Old browsers keep the filled bars from the HTML.
            }

            el.setAttribute('data-pp-ready', '');

            if (!reduce) {
                el.querySelectorAll('.pp-count').forEach((count) => {
                    count.textContent = (0).toFixed(Number(count.dataset.ppDecimals) || 0);
                });
            }

            observer.observe(el);
        });
    }

    const boot = () => {
        init(document);

        // The YOOtheme builder preview (an iframe) replaces elements while editing.
        if (window.self !== window.top) {
            new MutationObserver(() => init(document)).observe(document.body, { childList: true, subtree: true });
        }
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
