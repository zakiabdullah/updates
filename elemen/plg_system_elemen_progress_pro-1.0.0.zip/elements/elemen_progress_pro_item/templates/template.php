<?php

/**
 * Progress Bar Pro item: one bar, circle or half circle. Settings come from the parent
 * element ($element); the fill and the value are final in the HTML, the script only
 * animates them.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<string, mixed> $element
 * @var int|null $index
 */

use Joomla\CMS\Factory;

\defined('_JEXEC') or die;

$number = static function ($value): ?float {
    $value = str_replace([' ', ','], ['', '.'], trim(strip_tags((string) $value)));

    return $value !== '' && is_numeric($value) ? (float) $value : null;
};

$value = $number($props['value']);
$max   = $number($props['max']);
$max   = $max !== null && $max > 0 ? $max : 100.0; // Empty, zero or negative: out of 100.
$title = trim((string) $props['title']);

if ($value === null && $title === '') {
    return;
}

$value   = max(0.0, min($max, $value ?? 0.0));
$percent = round($value / $max * 100, 2);
$layout  = $element['layout'] ?: 'bar';
$index   = (int) ($index ?? 0);

// Shown value: the item's own text, or the element's format. Numbers are wrapped so the
// script can count them up.
$decimals = static fn (float $n): int => (int) (fmod($n, 1.0) !== 0.0 ? strlen(substr(strrchr(rtrim((string) $n, '0'), '.'), 1)) : 0);
$count    = static fn (float $n): string => $element['count_value']
    ? '<span class="pp-count" data-pp-to="' . $n . '" data-pp-decimals="' . $decimals($n) . '">' . number_format($n, $decimals($n), '.', '') . '</span>'
    : number_format($n, $decimals($n), '.', '');

$valueHtml = '';

if ($element['show_value']) {
    if (trim((string) $props['value_text']) !== '') {
        $valueHtml = $props['value_text'];
    } elseif ($element['value_format'] === 'value') {
        $valueHtml = $count($value) . $element['value_suffix'];
    } elseif ($element['value_format'] === 'fraction') {
        $valueHtml = $count($value) . '/' . number_format($max, $decimals($max), '.', '');
    } else {
        $valueHtml = $count(round($percent)) . '%';
    }
}

// Color: the item's own, else the element's.
$color      = static fn ($v): string => preg_match('/^[#(),.%\w\s-]+$/', trim((string) $v)) ? trim((string) $v) : '';
$itemColor  = $color($props['color']);
$mode       = $itemColor ? 'custom' : ($element['bar_color'] ?: 'primary');
$customHex  = $itemColor ?: $color($element['bar_color_custom']);
$gradFrom   = $color($element['bar_gradient_start']) ?: '#1e87f0';
$gradTo     = $color($element['bar_gradient_end']) ?: '#f0506e';
$themeClass = !in_array($mode, ['custom', 'gradient'], true) ? "uk-text-{$mode}" : '';

$vars = [
    '--pp-value: ' . $percent . '%',
    '--pp-value-number: ' . $percent,
    '--pp-delay: ' . ($index * (int) $element['stagger']) . 'ms',
];

if ($mode === 'custom' && $customHex) {
    $vars[] = '--pp-color: ' . $customHex;
}

if ($mode === 'gradient') {
    $vars[] = "--pp-from: {$gradFrom}";
    $vars[] = "--pp-to: {$gradTo}";
}

$el = $this->el('div', [

    'class' => [
        'el-item pp-item',
        'pp-mode-' . $mode,
    ],

    'style' => implode('; ', $vars),

]);

$titleEl = $this->el('div', [
    'class' => ['el-title pp-title', 'uk-' . $element['title_style'] => (bool) $element['title_style'], 'uk-text-' . $element['title_color'] => (bool) $element['title_color'], 'uk-margin-remove'],
]);

$valueEl = $this->el('div', [
    'class' => ['el-value pp-value', 'uk-' . ($element['value_style'] ?: ($layout === 'bar' ? 'h6' : 'h3')) => $element['value_style'] !== 'none', 'uk-text-' . $element['value_color'] => (bool) $element['value_color'], 'uk-margin-remove'],
]);

$aria = [
    'role'          => 'progressbar',
    'aria-valuemin' => '0',
    'aria-valuemax' => (string) $max,
    'aria-valuenow' => (string) $value,
    'aria-label'    => $title !== '' ? strip_tags($title) : false,
    'aria-valuetext' => trim((string) $props['value_text']) !== '' ? strip_tags((string) $props['value_text']) : false,
];

$titleHtml = $title !== '' ? $titleEl($element, $title) : '';
$valueBox  = $valueHtml !== '' ? $valueEl($element, $valueHtml) : '';
$content   = trim((string) $props['content']) !== '' ? '<div class="el-content pp-content uk-text-small uk-margin-xsmall-top">' . $props['content'] . '</div>' : '';

// Goal: a mark at the target value, with an optional label; screen readers get it as text.
$goal        = $number($props['goal']);
$goalPercent = $goal !== null ? round(max(0.0, min($max, $goal)) / $max * 100, 2) : null;
$goalLabel   = trim((string) $props['goal_label']);
$goalColor   = $color($element['goal_color']);
$goalName    = static function (): string {
    $language = Factory::getApplication()->getLanguage();
    $language->load('plg_system_elemen_progress_pro', JPATH_ADMINISTRATOR);

    return $language->_('PLG_SYSTEM_ELEMEN_PROGRESS_PRO_GOAL');
};
$goalText    = $goal !== null
    ? '<span class="uk-hidden-visually">' . ($goalLabel !== '' ? strip_tags($goalLabel) : htmlspecialchars($goalName())) . ': ' . number_format($goal, $decimals($goal), '.', '') . '</span>'
    : '';
$goalStyle   = $goalColor ? "; --pp-goal: {$goalColor}" : '';

?>
<?= $el($props, $attrs) ?>

<?php if ($layout === 'bar') :
    $position = $element['label_position'] ?: 'above';
    $tooltip  = $position === 'tooltip' && $valueBox !== '';
    $head     = ($titleHtml || ($valueBox && !$tooltip)) ? '<div class="pp-head uk-flex uk-flex-between uk-flex-bottom">' . ($titleHtml ?: '<span></span>') . ($tooltip ? '' : $valueBox) . '</div>' : '';
    $track    = $this->el('div', ['class' => ['pp-track']] + $aria);
    ?>

    <?php if ($position === 'above' || $position === 'tooltip') : ?><?= $head ?><?php endif ?>

    <div class="pp-track-wrap<?= $goalPercent !== null && $goalLabel !== '' ? ' pp-has-goal-label' : '' ?><?= $tooltip ? ' pp-has-tooltip' : '' ?>">
        <?php if ($tooltip) : ?>
        <div class="pp-tooltip <?= $themeClass ?>"><?= $valueBox ?></div>
        <?php endif ?>
        <?= $track($element) ?>
            <div class="pp-bar <?= $themeClass ?>">
                <?php if ($position === 'inside') : ?><?= $head ?><?php endif ?>
            </div>
        <?= $track->end() ?>
        <?php if ($goalPercent !== null) : ?>
        <div class="pp-goal" style="--pp-goal-at: <?= $goalPercent ?>%<?= $goalStyle ?>" aria-hidden="true">
            <?php if ($goalLabel !== '') : ?><span class="pp-goal-label"><?= $goalLabel ?></span><?php endif ?>
        </div>
        <?= $goalText ?>
        <?php endif ?>
    </div>

    <?php if ($position === 'below') : ?><?= $head ?><?php endif ?>

<?php else :
    $size   = max(40, (int) ($element['circle_size'] ?: 160));
    $stroke = max(1, min((int) ($element['circle_stroke'] ?: 10), (int) floor($size / 2) - 1));
    $r      = ($size - $stroke) / 2;
    $half   = $layout === 'semicircle';
    $height = $half ? $size / 2 + $stroke / 2 : $size;
    $d      = $half
        ? sprintf('M %1$s %2$s A %3$s %3$s 0 0 1 %4$s %2$s', $stroke / 2, $size / 2, $r, $size - $stroke / 2)
        : sprintf('M %1$s %2$s A %3$s %3$s 0 1 1 %1$s %4$s A %3$s %3$s 0 1 1 %1$s %2$s', $size / 2, $stroke / 2, $r, $size - $stroke / 2);
    $gradId = $mode === 'gradient' ? 'pp-grad-' . substr(md5(uniqid('', true)), 0, 8) : '';
    $svgAttrs = $this->el('div', [
        'class' => ['pp-circle'],
        'style' => "--pp-size: {$size}px; --pp-ratio: {$size} / {$height}",
    ] + $aria);
    ?>

    <?= $svgAttrs($element) ?>
        <svg viewBox="0 0 <?= $size ?> <?= $height ?>" aria-hidden="true" focusable="false">
            <?php if ($gradId) : ?>
            <defs><linearGradient id="<?= $gradId ?>" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="<?= $gradFrom ?>"/><stop offset="1" stop-color="<?= $gradTo ?>"/></linearGradient></defs>
            <?php endif ?>
            <path class="pp-ring-track" d="<?= $d ?>" stroke-width="<?= $stroke ?>" pathLength="100"/>
            <path class="pp-ring <?= $themeClass ?>" d="<?= $d ?>" stroke-width="<?= $stroke ?>" pathLength="100"<?= $gradId ? " style=\"stroke: url(#{$gradId})\"" : '' ?>/>
            <?php if ($goalPercent !== null) :
                // A short radial line across the ring at the goal: clockwise from the top for
                // a circle, from the left over the top for a half circle.
                $angle = deg2rad($half ? 180 * $goalPercent / 100 : 360 * $goalPercent / 100);
                [$cx, $cy] = [$size / 2, $size / 2];
                [$ux, $uy] = $half ? [-cos($angle), -sin($angle)] : [sin($angle), -cos($angle)];
                $inner = $r - $stroke * 0.9;
                $outer = $r + $stroke * 0.9;
                ?>
            <line class="pp-goal-tick" x1="<?= round($cx + $ux * $inner, 2) ?>" y1="<?= round($cy + $uy * $inner, 2) ?>" x2="<?= round($cx + $ux * $outer, 2) ?>" y2="<?= round($cy + $uy * $outer, 2) ?>" style="stroke-width: <?= max(2, round($stroke / 4)) ?>px<?= $goalStyle ?>"/>
            <?php endif ?>
        </svg>
        <div class="pp-circle-text<?= $half ? ' pp-circle-text-half' : '' ?>">
            <?= $valueBox ?>
            <?php if ($element['circle_title_position'] === 'inside') : ?><?= $titleHtml ?><?php endif ?>
        </div>
    <?= $svgAttrs->end() ?>

    <?php if ($element['circle_title_position'] !== 'inside') : ?>
    <div class="uk-text-center uk-margin-small-top"><?= $titleHtml ?></div>
    <?php endif ?>

    <?php if ($goalPercent !== null) : ?>
    <div class="pp-goal-caption uk-text-center uk-text-meta"<?= $goalColor ? ' style="--pp-goal: ' . $goalColor . '"' : '' ?>>
        <?= $goalLabel !== '' ? $goalLabel . ': ' : '' ?><?= number_format($goal, $decimals($goal), '.', '') ?>
    </div>
    <?php endif ?>

<?php endif ?>

    <?= $content ?>

<?= $el->end() ?>
