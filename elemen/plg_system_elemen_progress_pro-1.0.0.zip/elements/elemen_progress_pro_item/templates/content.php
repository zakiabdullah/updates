<?php

/**
 * Plain HTML stored in the article text, used by search and when the builder is off.
 *
 * @var array<string, mixed> $props
 */

\defined('_JEXEC') or die;

?>
<?php $shown = trim((string) ($props['value_text'] ?? '')) !== '' ? $props['value_text'] : trim((string) ($props['value'] ?? '')) ?>
<?= $props['title'] ?><?php if ($shown !== '') : ?><?= trim((string) $props['title']) !== '' ? ': ' : '' ?><?= $shown ?><?php endif ?>
<?php if ($props['content']) : ?>
<?= $props['content'] ?>
<?php endif ?>
