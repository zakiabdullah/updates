<?php

/**
 * Tabs Pro: tabs or an accordion in one element.
 *
 * Every item renders an accordion heading and a panel; in the tabs view a tab list sits
 * above (or beside) the panels. Below the chosen breakpoint CSS hides the tab list and
 * shows the accordion headings, and the script switches the ARIA roles to match. Closed
 * panels are hidden="until-found", so the browser's find in page can open them; without
 * JavaScript every panel is shown with its heading.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var \YOOtheme\Builder $builder
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<int, object> $children
 */

use Joomla\CMS\Uri\Uri;
use YOOtheme\Metadata;

use function YOOtheme\app;

\defined('_JEXEC') or die;

// Display options: fields of every item can be hidden without deleting them. Layouts saved
// before the options existed don't have them, so they count as shown.
$hidden = [];

foreach (['badge' => ['badge'], 'icon' => ['icon', 'icon_lucide'], 'image' => ['image'], 'link' => ['link', 'link_text']] as $option => $fields) {
    if (!($props["show_{$option}"] ?? true)) {
        array_push($hidden, ...$fields);
    }
}

foreach ($hidden ? $children : [] as $child) {
    foreach ($hidden as $field) {
        if (is_array($child->props ?? null)) {
            $child->props[$field] = '';
        } elseif (is_object($child->props ?? null)) {
            $child->props->{$field} = '';
        }
    }
}

$has = static fn ($value): bool => trim((string) $value) !== '';

// Items with nothing to show are left out, from the tab list too.
$items = [];

foreach ($children as $child) {
    $p = (array) ($child->props ?? []);

    if ($has($p['title'] ?? '') || $has($p['content'] ?? '') || !empty($p['image'])) {
        $items[] = [$child, $p];
    }
}

if (!$items) {
    return;
}

// Assets. The URL is worked out from this file's location, so it follows the plugin folder.
$assets   = \dirname(__DIR__) . '/assets';
$assetUrl = static fn (string $file): string => Uri::root(true) . '/'
    . str_replace('\\', '/', substr($assets, strlen(JPATH_ROOT) + 1)) . "/{$file}?v=" . @filemtime("{$assets}/{$file}");
$metadata = app(Metadata::class);

$metadata->set('style:elemen-tabs-pro', ['href' => $assetUrl('tabs-pro.css')]);
$metadata->set('script:elemen-tabs-pro', ['src' => $assetUrl('tabs-pro.js'), 'defer' => true]);

$color = static fn ($value): string => preg_match('/^[#(),.%\w\s-]+$/', trim((string) $value)) ? trim((string) $value) : '';

// Anchors: from the item setting or the title, unique on the page so that links and
// aria-controls always point to one panel.
$used   = &$GLOBALS['elemen_tabs_pro_anchors'];
$used ??= [];
$slug   = static function (string $text): string {
    $text = trim((string) preg_replace('/[^\p{L}\p{N}_]+/u', '-', mb_strtolower(strip_tags($text))), '-');

    return $text !== '' ? $text : 'tab';
};

$view   = $props['view'] === 'accordion' ? 'accordion' : 'tabs';
$count  = count($items);
$active = $has($props['active']) ? (int) $props['active'] : 1;

if ($active > $count || ($active < 1 && $view === 'tabs')) {
    $active = 1;
}

// Title shared by the tab and the accordion heading: number, icon, text and badge.
// A Lucide icon from Icon Pro's "Lucide Icon" field, when Icon Pro is installed.
$lucide = static function ($name, int $size): string {
    $file = JPATH_PLUGINS . '/system/elemen_icon_pro/elements/elemen_icon_pro/icons/Icons.php';

    if (trim((string) $name) === '' || !is_file($file)) {
        return '';
    }

    require_once $file;

    return \Elemen\IconPro\Icons::svg((string) $name, ['size' => $size]);
};

$label = static function (array $p, int $n) use ($props, $has, $lucide): string {
    $html = $props['numbers'] ? '<span class="tp-num">' . str_pad((string) $n, 2, '0', STR_PAD_LEFT) . '</span>' : '';

    if ($svg = $lucide($p['icon_lucide'] ?? '', 20)) {
        $html .= '<span class="tp-icon">' . $svg . '</span>';
    } elseif ($has($p['icon'] ?? '')) {
        $html .= '<span class="tp-icon" uk-icon="icon: ' . htmlspecialchars((string) $p['icon']) . '"></span>';
    }

    $html .= '<span class="tp-text">' . ($has($p['title'] ?? '') ? $p['title'] : (string) $n) . '</span>';

    if ($has($p['badge'] ?? '')) {
        $html .= '<span class="tp-badge uk-label' . ($props['badge_color'] ? ' uk-label-' . $props['badge_color'] : '') . '">' . $p['badge'] . '</span>';
    }

    return $html;
};

$tabs   = [];
$panels = [];

foreach ($items as $i => [$child, $p]) {
    $anchor = $slug($has($p['anchor'] ?? '') ? (string) $p['anchor'] : (string) ($p['title'] ?? ''));
    $unique = $anchor;

    for ($n = 2; isset($used[$unique]); $n++) {
        $unique = "{$anchor}-{$n}";
    }

    $used[$unique] = true;
    $open          = $i + 1 === $active;
    $text          = $label($p, $i + 1);

    $tabs[] = '<button type="button" class="el-tab tp-tab' . ($open ? ' is-active' : '') . '" role="tab" id="' . $unique . '-tab"'
        . ' aria-controls="' . $unique . '" aria-selected="' . ($open ? 'true' : 'false') . '" tabindex="' . ($open ? '0' : '-1') . '">' . $text . '</button>';

    $panels[] = $builder->render($child, [
        'element' => $props,
        'index'   => $i,
        'anchor'  => $unique,
        'open'    => $open,
        'label'   => $text,
        'view'    => $view,
    ]);
}

$options = [
    'breakpoint'  => $view === 'tabs' ? (string) $props['breakpoint'] : '',
    'deep'        => (bool) $props['deep_link'],
    'multiple'    => (bool) $props['multiple'],
    'collapsible' => (bool) $props['collapsible'],
    'animation'   => (string) $props['switch_animation'],
];

$tabStyle  = in_array($props['tab_style'], ['pill', 'segmented'], true) ? $props['tab_style'] : 'underline';
$left      = $props['tab_position'] === 'left';
$custom    = $props['tab_color'] === 'custom' ? $color($props['tab_color_custom']) : '';
$indicator = $custom
    ? '<span class="tp-indicator" style="color: ' . $custom . '" aria-hidden="true"></span>'
    : '<span class="tp-indicator uk-text-' . (in_array($props['tab_color'], ['secondary', 'emphasis'], true) ? $props['tab_color'] : 'primary') . '" aria-hidden="true"></span>';

$el = $this->el('div', [

    'class' => [
        'elemen-tabs-pro tp',
        "tp-view-{$view}",
        'tp-acc-below-{breakpoint}' => $view === 'tabs' && in_array($props['breakpoint'], ['s', 'm'], true),
        "tp-style-{$tabStyle}" => $view === 'tabs',
        'tp-left' => $view === 'tabs' && $left,
        'tp-align-{tab_align}' => $view === 'tabs' && !$left,
        'tp-nav-{nav_width}' => $view === 'tabs' && $left,
        'tp-icon-top' => $props['icon_position'] === 'top',
        'tp-title-{title_size} {@title_size}',
        'tp-acc-{accordion_style}',
        'tp-acc-icon-left' => $props['accordion_icon_position'] === 'left',
    ],

    'data-tp' => json_encode($options),

]);

// Without JavaScript: every panel open under its heading, no tab list. Printed once per page.
$noscript = empty($GLOBALS['elemen_tabs_pro_noscript']);
$GLOBALS['elemen_tabs_pro_noscript'] = true;

?>
<?= $el($props, $attrs) ?>

    <?php if ($view === 'tabs') : ?>
    <div class="el-nav tp-nav">
        <div class="tp-tablist" role="tablist"<?= $left ? ' aria-orientation="vertical"' : '' ?>>
            <?= implode("\n            ", $tabs) ?>

            <?= $indicator ?>

        </div>
    </div>
    <?php endif ?>

    <div class="tp-panels">
        <?= implode("\n", $panels) ?>
    </div>

    <?php if ($noscript) : ?>
    <noscript><style>.elemen-tabs-pro .tp-nav{display:none}.elemen-tabs-pro.tp-left{display:block}.elemen-tabs-pro .tp-acc-heading{display:block}.elemen-tabs-pro .tp-panel[hidden]{display:block!important;content-visibility:visible}</style></noscript>
    <?php endif ?>

<?= $el->end() ?>
