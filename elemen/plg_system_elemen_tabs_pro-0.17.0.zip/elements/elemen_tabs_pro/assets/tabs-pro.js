/* Elemen: Tabs Pro — tabs that turn into an accordion, a sliding indicator, keyboard
   support, #name links and find in page. No dependencies. */
(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const queries = { s: '(max-width: 639.98px)', m: '(max-width: 959.98px)' };
    const keyframes = {
        fade: [{ opacity: 0 }, { opacity: 1 }],
        slide: [{ opacity: 0, transform: 'translateY(12px)' }, { opacity: 1, transform: 'none' }],
    };

    function setup(tp) {
        tp.setAttribute('data-tp-ready', '');

        let options = {};

        try {
            options = JSON.parse(tp.getAttribute('data-tp') || '{}');
        } catch (e) {
            // keep the defaults
        }

        const items = [...tp.querySelectorAll(':scope > .tp-panels > .tp-item')];
        const tablist = tp.querySelector(':scope > .tp-nav > .tp-tablist');
        const tabs = tablist ? [...tablist.querySelectorAll(':scope > .tp-tab')] : [];
        const indicator = tablist && tablist.querySelector(':scope > .tp-indicator');
        const query = tabs.length && queries[options.breakpoint] ? window.matchMedia(queries[options.breakpoint]) : null;
        const vertical = tp.classList.contains('tp-left');
        const fill = tp.classList.contains('tp-style-pill') || tp.classList.contains('tp-style-segmented');

        const panel = (item) => item.querySelector(':scope > .tp-panel');
        const button = (item) => item.querySelector(':scope > .tp-acc-heading > .tp-acc-btn');
        const isOpen = (item) => item.classList.contains('is-open');
        const accordion = () => !tabs.length || (query ? query.matches : false);

        if (!items.length) {
            return;
        }

        // Opens or closes one item. Accordion panels slide; tab panels fade in.
        function set(item, open, animate) {
            const p = panel(item);
            const tab = tabs[items.indexOf(item)];

            item.classList.toggle('is-open', open);
            button(item)?.setAttribute('aria-expanded', String(open));

            if (tab) {
                tab.classList.toggle('is-active', open);
                tab.setAttribute('aria-selected', String(open));
                tab.tabIndex = open ? 0 : -1;
            }

            p.getAnimations().forEach((animation) => animation.cancel());
            const motion = animate && !reduce && p.animate;

            if (open) {
                p.removeAttribute('hidden');

                if (motion && accordion()) {
                    p.style.overflow = 'hidden';
                    p.animate([{ height: '0px', opacity: 0 }, { height: `${p.scrollHeight}px`, opacity: 1 }], { duration: 300, easing: 'ease-out' })
                        .finished.then(() => (p.style.overflow = ''), () => {});
                } else if (motion && keyframes[options.animation]) {
                    p.animate(keyframes[options.animation], { duration: 300, easing: 'ease-out' });
                }
            } else if (motion && accordion() && !p.hasAttribute('hidden')) {
                p.style.overflow = 'hidden';
                p.animate([{ height: `${p.offsetHeight}px` }, { height: '0px' }], { duration: 250, easing: 'ease-in' })
                    .finished.then(() => {
                        p.style.overflow = '';

                        if (!isOpen(item)) {
                            p.setAttribute('hidden', 'until-found');
                        }
                    }, () => {});
            } else {
                p.setAttribute('hidden', 'until-found');
            }
        }

        function place() {
            if (!indicator || accordion()) {
                return;
            }

            const tab = tabs.find((t) => t.classList.contains('is-active'));

            if (!tab) {
                indicator.style.opacity = '0';
                return;
            }

            const style = indicator.style;
            style.opacity = '';

            if (vertical || fill) {
                style.top = `${tab.offsetTop}px`;
                style.height = `${tab.offsetHeight}px`;
            }

            if (!vertical || fill) {
                style.left = `${tab.offsetLeft}px`;
                style.width = `${tab.offsetWidth}px`;
            }

            if (!tp.classList.contains('tp-ready')) {
                tp.classList.add('tp-ready');
                // Slide only from the second placement on, not in from the corner.
                requestAnimationFrame(() => requestAnimationFrame(() => tp.classList.add('tp-animate')));
            }
        }

        // Tabs: exactly one open. Accordion: as the options allow.
        function activate(item, animate) {
            if (!accordion()) {
                if (isOpen(item)) {
                    return;
                }

                items.forEach((other) => other !== item && set(other, false, false));
                set(item, true, animate);
                place();

                const tab = tabs[items.indexOf(item)];

                if (tab && tablist.scrollWidth > tablist.clientWidth) {
                    tablist.scrollTo({ left: tab.offsetLeft - (tablist.clientWidth - tab.offsetWidth) / 2, behavior: reduce ? 'auto' : 'smooth' });
                }

                return;
            }

            if (isOpen(item)) {
                if (options.collapsible || items.filter(isOpen).length > 1) {
                    set(item, false, animate);
                }

                return;
            }

            if (!options.multiple) {
                items.forEach((other) => other !== item && isOpen(other) && set(other, false, animate));
            }

            set(item, true, animate);
        }

        function remember(item) {
            if (options.deep && window.history.replaceState) {
                window.history.replaceState(null, '', `#${encodeURIComponent(panel(item).id)}`);
            }
        }

        // Tabs and accordion share the open state; roles and labels follow the mode.
        function mode() {
            const acc = accordion();

            items.forEach((item, i) => {
                const p = panel(item);
                p.setAttribute('role', acc ? 'region' : 'tabpanel');
                p.setAttribute('aria-labelledby', acc ? button(item).id : tabs[i].id);

                if (acc) {
                    p.removeAttribute('tabindex');
                } else {
                    p.tabIndex = 0;
                }
            });

            if (!acc) {
                const open = items.filter(isOpen);
                const keep = open[0] || items[0];
                items.forEach((item) => item !== keep && isOpen(item) && set(item, false, false));

                if (!isOpen(keep)) {
                    set(keep, true, false);
                }

                place();
            }
        }

        // Opens the item a #name link points to; true when it found one.
        function follow(scroll) {
            let id = '';

            try {
                id = decodeURIComponent(window.location.hash.slice(1));
            } catch (e) {
                return false;
            }

            const item = id && items.find((it) => panel(it).id === id || panel(it).id + '-tab' === id || panel(it).id + '-btn' === id);

            if (!item) {
                return false;
            }

            if (!isOpen(item)) {
                activate(item, false);
            }

            if (scroll) {
                requestAnimationFrame(() => (accordion() ? item : tp).scrollIntoView({ block: 'start', behavior: reduce ? 'auto' : 'smooth' }));
            }

            return true;
        }

        tabs.forEach((tab, i) => {
            tab.addEventListener('click', () => {
                activate(items[i], true);
                remember(items[i]);
            });
        });

        // Arrow keys move between tabs and open them; Home and End jump to the ends.
        tablist?.addEventListener('keydown', (event) => {
            const i = tabs.indexOf(document.activeElement);

            if (i < 0) {
                return;
            }

            const rtl = getComputedStyle(tp).direction === 'rtl';
            const next = vertical ? 'ArrowDown' : (rtl ? 'ArrowLeft' : 'ArrowRight');
            const prev = vertical ? 'ArrowUp' : (rtl ? 'ArrowRight' : 'ArrowLeft');
            let to = -1;

            if (event.key === next) {
                to = (i + 1) % tabs.length;
            } else if (event.key === prev) {
                to = (i - 1 + tabs.length) % tabs.length;
            } else if (event.key === 'Home') {
                to = 0;
            } else if (event.key === 'End') {
                to = tabs.length - 1;
            }

            if (to >= 0) {
                event.preventDefault();
                tabs[to].focus();
                activate(items[to], true);
                remember(items[to]);
            }
        });

        items.forEach((item) => {
            button(item)?.addEventListener('click', () => {
                activate(item, true);

                if (isOpen(item)) {
                    remember(item);
                }
            });

            // Find in page found text in a closed panel: open it.
            panel(item).addEventListener('beforematch', () => activate(item, false));
        });

        query?.addEventListener('change', mode);

        if (tablist && 'ResizeObserver' in window) {
            new ResizeObserver(place).observe(tablist);
        }

        window.addEventListener('resize', place);
        document.fonts?.ready.then(place);

        if (options.deep) {
            window.addEventListener('hashchange', () => follow(true));
        }

        mode();

        if (options.deep) {
            follow(true);
        }
    }

    const init = (root) => root.querySelectorAll('.elemen-tabs-pro:not([data-tp-ready])').forEach(setup);

    const boot = () => {
        init(document);

        // The YOOtheme builder preview replaces elements while editing.
        new MutationObserver(() => init(document)).observe(document.body, { childList: true, subtree: true });
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
