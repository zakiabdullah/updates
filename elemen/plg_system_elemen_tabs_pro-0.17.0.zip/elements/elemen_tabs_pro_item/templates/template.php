<?php

/**
 * Tabs Pro item: its accordion heading and its panel. The parent element works out the
 * anchor, the title and whether it starts open, and passes them in.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<string, mixed> $element
 * @var string|null $anchor
 * @var bool|null $open
 * @var string|null $label
 * @var string|null $view
 */

\defined('_JEXEC') or die;

$has = static fn ($value): bool => trim((string) $value) !== '';

if (!$has($props['title']) && !$has($props['content']) && !$props['image']) {
    return;
}

$anchor = (string) ($anchor ?? 'tab');
$open   = (bool) ($open ?? false);
$tabs   = ($view ?? 'tabs') === 'tabs';

// Image
$image    = '';
$position = in_array($element['image_position'], ['bottom', 'left', 'right'], true) ? $element['image_position'] : 'top';

if ($props['image']) {
    $image = $this->el('image', [
        'class'     => ['el-image tp-image', 'uk-border-' . $element['image_border'] => (bool) $element['image_border']],
        'src'       => $props['image'],
        'alt'       => $props['image_alt'],
        'width'     => $element['image_width'],
        'height'    => $element['image_height'],
        'loading'   => 'lazy',
        'thumbnail' => true,
    ])->render([]);
    $image = '<div class="tp-media">' . $image . '</div>';
}

// Content and link
$content = $has($props['content'])
    ? '<div class="el-content tp-content uk-panel' . ($element['content_style'] ? ' uk-' . $element['content_style'] : '') . '">' . $props['content'] . '</div>'
    : '';
$link = '';

if ($props['link'] && $has($props['link_text'])) {
    $style = $element['link_style'] ?: 'text';
    $link  = $this->el('a', [
        'class'  => [$style === 'link' ? 'el-link uk-link' : "el-link uk-button uk-button-{$style}"],
        'href'   => ['{link}'],
        'target' => $element['link_target'] ? '_blank' : false,
    ])->render($props, $props['link_text']);
    $link = '<div class="tp-link uk-margin-top">' . $link . '</div>';
}

$body = $position === 'bottom' ? $content . $image . $link : ($position === 'top' ? $image . $content . $link : $image . '<div class="tp-body">' . $content . $link . '</div>');

// Panel box
$style = $element['panel_style'];
$inner = $this->el('div', [
    'class' => [
        'tp-panel-inner',
        "tp-media-{$position}" => (bool) $image,
        'uk-card uk-card-body uk-card-' . $style => in_array($style, ['default', 'primary', 'secondary'], true),
        'uk-background-muted uk-padding' => $style === 'muted',
    ],
]);

$heading = $element['title_element'] ?: 'h3';

$el = $this->el('div', [
    'class' => ['el-item tp-item', 'is-open' => $open],
]);

?>
<?= $el($props, $attrs) ?>
    <<?= $heading ?> class="tp-acc-heading">
        <button type="button" class="el-title tp-acc-btn" id="<?= $anchor ?>-btn" aria-expanded="<?= $open ? 'true' : 'false' ?>" aria-controls="<?= $anchor ?>">
            <span class="tp-acc-label"><?= $label ?></span><span class="tp-acc-icon tp-acc-icon-<?= in_array($element['accordion_icon'], ['chevron', 'none'], true) ? $element['accordion_icon'] : 'plus' ?>" aria-hidden="true"></span>
        </button>
    </<?= $heading ?>>
    <div class="tp-panel" id="<?= $anchor ?>" role="<?= $tabs ? 'tabpanel' : 'region' ?>" aria-labelledby="<?= $anchor ?>-<?= $tabs ? 'tab' : 'btn' ?>"<?= $tabs ? ' tabindex="0"' : '' ?><?= $open ? '' : ' hidden="until-found"' ?>>
        <?= $inner($props, $body) ?>
    </div>
<?= $el->end() ?>
