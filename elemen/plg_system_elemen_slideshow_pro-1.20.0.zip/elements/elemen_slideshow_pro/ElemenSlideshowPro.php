<?php

/**
 * Slideshow Pro helpers: checked settings, slide schedule and colours.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

use Joomla\CMS\Factory;

\defined('_JEXEC') or die;

if (class_exists('ElemenSlideshowPro', false)) {
    return;
}

final class ElemenSlideshowPro
{
    /** Settings with fixed values; the first is the default. */
    public const OPTIONS = [
        'height'            => ['viewport', 'ratio', 'fixed'],
        'ratio'             => ['16:7', '16:9', '21:9', '3:1', '4:3'],
        'transition'        => ['slide', 'fade', 'scale', 'pull', 'push', 'wipe', 'curtain', 'circle', 'diagonal', 'blinds'],
        'layout'            => ['overlay', 'split'],
        'split_side'        => ['start', 'end'],
        'split_width'       => ['1-2', '3-5', '2-3'],
        'split_panel'       => ['default', 'muted', 'primary', 'secondary'],
        'content_card'      => ['none', 'box', 'glass', 'primary', 'secondary'],
        'button_icon_position' => ['end', 'start'],
        'transition_speed'  => ['normal', 'slow', 'fast'],
        'kenburns'          => ['', 'zoom-in', 'zoom-out', 'pan-left', 'pan-right', 'auto'],
        'overlay'           => ['dark', 'none', 'light', 'primary', 'secondary', 'custom'],
        'overlay_type'      => ['solid', 'bottom', 'start', 'vignette'],
        'content_position'  => ['center-left', 'top-left', 'top-center', 'top-right', 'center', 'center-right', 'bottom-left', 'bottom-center', 'bottom-right'],
        'content_width'     => ['medium', 'small', 'large', 'xlarge'],
        'text_color'        => ['light', 'dark'],
        'eyebrow_style'     => ['kicker', 'label', 'meta'],
        'title_style'       => ['heading-medium', 'heading-small', 'heading-large', 'heading-xlarge', 'h1', 'h2'],
        'title_element'     => ['h2', 'h1-first', 'h1', 'h3', 'div'],
        'content_style'     => ['lead', '', 'small'],
        'button1_style'     => ['primary', 'secondary', 'default', 'text'],
        'button2_style'     => ['default', 'primary', 'secondary', 'text'],
        'button_size'       => ['', 'large', 'small'],
        'content_animation' => ['fade-up', 'slide', 'blur', 'mask', 'words', 'fade', 'none'],
        'nav'               => ['dots', 'lines', 'titles', 'thumbs', 'none'],
        'nav_position'      => ['center', 'start', 'end', 'below'],
        'arrow_style'       => ['minimal', 'circle', 'square', 'glass'],
        'arrow_position'    => ['sides', 'bar'],
        'progress'          => ['', 'bottom', 'top'],
        'progress_color'    => ['auto', 'primary', 'secondary', 'gradient'],
    ];

    /** Item settings that override the element's; '' = as the element. */
    public const ITEM_OPTIONS = [
        'kenburns'         => ['', 'none', 'zoom-in', 'zoom-out', 'pan-left', 'pan-right'],
        'overlay'          => ['', 'none', 'dark', 'light', 'primary', 'secondary'],
        'content_position' => ['', 'center-left', 'top-left', 'top-center', 'top-right', 'center', 'center-right', 'bottom-left', 'bottom-center', 'bottom-right'],
        'text_color'       => ['', 'light', 'dark'],
        'split_side'       => ['', 'start', 'end'],
        'image_focal'      => ['', 'top-left', 'top-center', 'top-right', 'center-left', 'center-right', 'bottom-left', 'bottom-center', 'bottom-right'],
        'image_mobile_focal' => ['', 'top-left', 'top-center', 'top-right', 'center-left', 'center-right', 'bottom-left', 'bottom-center', 'bottom-right'],
    ];

    /** Order of the Auto Ken Burns effects, one per slide. */
    public const KENBURNS_AUTO = ['zoom-in', 'pan-left', 'zoom-out', 'pan-right'];

    /**
     * Ready-made looks: values for these settings, which the builder hides while a preset
     * is picked. Colours, heights, durations and texts stay the user's.
     */
    public const PRESETS = [
        'corporate' => [
            'layout' => 'overlay', 'transition' => 'fade', 'kenburns' => 'auto', 'overlay' => 'dark', 'overlay_type' => 'start',
            'content_position' => 'center-left', 'content_card' => 'none', 'split_panel' => 'default', 'eyebrow_style' => 'kicker',
            'title_style' => 'heading-medium', 'content_animation' => 'fade-up', 'nav' => 'titles', 'nav_position' => 'center',
            'arrow_style' => 'minimal', 'arrow_position' => 'sides', 'progress' => '', 'counter' => true,
        ],
        'product' => [
            'layout' => 'overlay', 'transition' => 'circle', 'kenburns' => 'zoom-out', 'overlay' => 'dark', 'overlay_type' => 'vignette',
            'content_position' => 'center', 'content_card' => 'none', 'split_panel' => 'default', 'eyebrow_style' => 'label',
            'title_style' => 'heading-large', 'content_animation' => 'words', 'nav' => 'thumbs', 'nav_position' => 'below',
            'arrow_style' => 'circle', 'arrow_position' => 'bar', 'progress' => 'bottom', 'counter' => false,
        ],
        'split' => [
            'layout' => 'split', 'transition' => 'wipe', 'kenburns' => 'zoom-in', 'overlay' => 'none', 'overlay_type' => 'solid',
            'content_position' => 'center-left', 'content_card' => 'none', 'split_panel' => 'muted', 'eyebrow_style' => 'kicker',
            'title_style' => 'heading-small', 'content_animation' => 'mask', 'nav' => 'lines', 'nav_position' => 'start',
            'arrow_style' => 'square', 'arrow_position' => 'bar', 'progress' => '', 'counter' => true,
        ],
        'testimonial' => [
            'layout' => 'overlay', 'transition' => 'fade', 'kenburns' => '', 'overlay' => 'dark', 'overlay_type' => 'solid',
            'content_position' => 'center', 'content_card' => 'glass', 'split_panel' => 'default', 'eyebrow_style' => 'meta',
            'title_style' => 'h2', 'content_animation' => 'blur', 'nav' => 'dots', 'nav_position' => 'center',
            'arrow_style' => 'glass', 'arrow_position' => 'sides', 'progress' => '', 'counter' => false,
        ],
        'minimal' => [
            'layout' => 'overlay', 'transition' => 'fade', 'kenburns' => 'zoom-in', 'overlay' => 'dark', 'overlay_type' => 'bottom',
            'content_position' => 'bottom-left', 'content_card' => 'none', 'split_panel' => 'default', 'eyebrow_style' => 'meta',
            'title_style' => 'heading-small', 'content_animation' => 'fade', 'nav' => 'lines', 'nav_position' => 'end',
            'arrow_style' => 'minimal', 'arrow_position' => 'bar', 'progress' => 'bottom', 'counter' => false,
        ],
    ];

    /** Transitions drawn by slideshow-pro.js over UIkit's Fade. */
    public const CLIP = ['wipe', 'curtain', 'circle', 'diagonal', 'blinds'];

    /** UIkit velocity per transition speed. */
    public const VELOCITY = ['slow' => 0.6, 'normal' => 1, 'fast' => 1.6];

    /**
     * The settings with every value checked.
     *
     * @param  array<string, mixed> $props
     * @return array<string, mixed>
     */
    public static function settings(array $props): array
    {
        // Layouts saved before Navigation existed only have the Dots checkbox.
        if (!isset($props['nav']) && isset($props['dots'])) {
            $props['nav'] = $props['dots'] ? 'dots' : 'none';
        }

        $preset = (string) ($props['preset'] ?? '');
        $preset = isset(self::PRESETS[$preset]) ? $preset : '';

        if ($preset !== '') {
            $props = self::PRESETS[$preset] + $props;
        }

        $s = ['preset' => $preset];

        foreach (self::OPTIONS as $key => $allowed) {
            $value   = (string) ($props[$key] ?? $allowed[0]);
            $s[$key] = in_array($value, $allowed, true) ? $value : $allowed[0];
        }

        $int = static fn (string $key, int $default, int $min, int $max): int => max($min, min($max, ($v = trim((string) ($props[$key] ?? ''))) === '' ? $default : (int) $v));

        $s['height_value']    = $int('height_value', $s['height'] === 'fixed' ? 600 : 100, $s['height'] === 'fixed' ? 200 : 20, $s['height'] === 'fixed' ? 1600 : 100);
        $s['min_height']      = $int('min_height', 400, 0, 1200);
        $s['duration']        = $int('duration', 6, 2, 60);
        $s['overlay_opacity'] = $int('overlay_opacity', 40, 0, 100);
        $s['anim_delay']      = $int('anim_delay', 250, 0, 2000);
        $s['anim_stagger']    = $int('anim_stagger', 120, 0, 1000);
        $s['anim_duration']   = $int('anim_duration', 800, 200, 3000);
        $s['progress_height'] = $int('progress_height', 3, 1, 8);
        $s['overlay_color']   = self::color($props['overlay_color'] ?? '');

        foreach (['viewport_offset' => true, 'autoplay' => true, 'pause_hover' => true, 'pause_button' => true, 'arrows' => true, 'arrows_hover' => false, 'counter' => false, 'scroll_hint' => false, 'content_container' => true, 'button_target' => false, 'image_eager' => true, 'video_wait' => false, 'video_phones' => true] as $key => $default) {
            $s[$key] = (bool) ($props[$key] ?? $default);
        }

        if ($s['overlay'] === 'custom' && $s['overlay_color'] === '') {
            $s['overlay'] = 'dark';
        }

        // A content card only sits over the image.
        if ($s['layout'] === 'split') {
            $s['content_card'] = 'none';
        }

        $s['clip'] = in_array($s['transition'], self::CLIP, true);

        return $s;
    }

    /**
     * Text colours of a slide: 'header' over the image (the transparent header and the
     * controls follow it) and 'content' for the text, which a split panel or a content card
     * can change. A slide's own Text Colour wins.
     *
     * @param  array<string, mixed> $s
     * @return array{header: string, content: string}
     */
    public static function colors(array $s, string $own): array
    {
        $dark = static fn (string $surface): string => in_array($surface, ['primary', 'secondary'], true) ? 'light' : 'dark';

        if ($s['layout'] === 'split') {
            $color = $own ?: $dark($s['split_panel']);

            return ['header' => $color, 'content' => $color];
        }

        $header  = $own ?: $s['text_color'];
        $content = match ($s['content_card']) {
            'box'                  => 'dark',
            'primary', 'secondary' => 'light',
            default                => $header,
        };

        return ['header' => $header, 'content' => $content];
    }

    /**
     * An icon field: Icon Pro's icon ("<field>_lucide", while Icon Pro is installed) wins
     * over the UIkit icon. '' when neither is set.
     *
     * @param array<string, mixed> $props
     */
    public static function icon(array $props, string $field, int $size = 20): string
    {
        $lucide = trim((string) ($props["{$field}_lucide"] ?? ''));

        if ($lucide !== '') {
            $file = JPATH_PLUGINS . '/system/elemen_icon_pro/elements/elemen_icon_pro/icons/Icons.php';

            if (is_file($file)) {
                require_once $file;
                $svg = \Elemen\IconPro\Icons::svg($lucide, ['size' => $size]);

                if ($svg !== '') {
                    return $svg;
                }
            }
        }

        $uikit = trim((string) ($props[$field] ?? ''));

        return $uikit !== '' ? '<span uk-icon="icon: ' . htmlspecialchars($uikit, ENT_QUOTES, 'UTF-8') . '; ratio: ' . round($size / 20, 2) . '"></span>' : '';
    }

    /**
     * A slide's video from its URL or file: YouTube, Vimeo, Facebook or a video file
     * (mp4, webm, ogv, mov). null when it isn't one.
     *
     * @return array{type: string, id?: string, hash?: string, src?: string, href?: string}|null
     */
    public static function video(string $url): ?array
    {
        $url = trim($url);

        if ($url === '') {
            return null;
        }

        if (preg_match('#(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?|shorts|live)/|.*[?&]v=)|youtu\.be/)([\w-]{11})#i', $url, $m)) {
            return ['type' => 'youtube', 'id' => $m[1]];
        }

        if (preg_match('#vimeo\.com/(?:video/|channels/[\w-]+/|groups/[\w-]+/videos/)?(\d+)(?:/([0-9a-f]{6,}))?#i', $url, $m)) {
            $hash = $m[2] ?? '';

            if ($hash === '' && preg_match('#[?&]h=([0-9a-f]+)#i', $url, $h)) {
                $hash = $h[1];
            }

            return ['type' => 'vimeo', 'id' => $m[1]] + ($hash !== '' ? ['hash' => $hash] : []);
        }

        if (preg_match('#^https?://(?:www\.|m\.|web\.)?(?:facebook\.com/.+/videos?/|facebook\.com/(?:watch|reel|share/v)|fb\.watch/)#i', $url)) {
            return ['type' => 'facebook', 'href' => $url];
        }

        if (preg_match('#\.(mp4|webm|ogv|mov)(?:[?\#].*)?$#i', $url)) {
            $src = preg_match('#^(https?:)?//|^/#i', $url) ? $url : \Joomla\CMS\Uri\Uri::root(true) . '/' . ltrim($url, '/');

            return ['type' => 'file', 'src' => $src];
        }

        return null;
    }

    /**
     * The YOOtheme consent service ("category.service") for YouTube or Vimeo when the theme
     * asks visitors for consent first; marks the consent script as needed. '' otherwise.
     */
    public static function consent(string $type): string
    {
        static $services = [];

        $types = ['youtube' => 'script-youtube', 'vimeo' => 'script-vimeo'];

        if (!isset($types[$type]) || !class_exists(\YOOtheme\Theme\ThemeConfig::class)) {
            return '';
        }

        if (isset($services[$type])) {
            return $services[$type];
        }

        $services[$type] = '';

        try {
            $theme = \YOOtheme\app(\YOOtheme\Theme\ThemeConfig::class);

            foreach ($theme->scripts as &$script) {
                if (($script['type'] ?? '') === $types[$type]) {
                    $script['active']  = true;
                    $services[$type] = "{$script['category']}.{$script['service']}";
                    break;
                }
            }
        } catch (\Throwable $e) {
            // No consent settings.
        }

        return $services[$type];
    }

    /** An item setting: one of the allowed values, or '' (as the element). */
    public static function item(array $props, string $key): string
    {
        $value = (string) ($props[$key] ?? '');

        return in_array($value, self::ITEM_OPTIONS[$key], true) ? $value : '';
    }

    /** A CSS colour from a colour field, or '' when it isn't one. */
    public static function color($value): string
    {
        $value = trim((string) $value);

        return preg_match('/^(#[0-9a-f]{3,8}|(rgb|rgba|hsl|hsla|oklch|oklab)\([0-9.,%\s\/+-]+(deg)?\))$/i', $value) ? $value : '';
    }

    /** CSS object-position for a focal point such as "top-left"; '' for the centre. */
    public static function focal(string $focal): string
    {
        if ($focal === '') {
            return '';
        }

        [$y, $x] = array_pad(explode('-', $focal), 2, 'center');

        return ['left' => '0%', 'center' => '50%', 'right' => '100%'][$x] . ' ' . ['top' => '0%', 'center' => '50%', 'bottom' => '100%'][$y];
    }

    /**
     * Whether a slide is outside its show from/until dates, in the site's time zone.
     *
     * @param array<string, mixed> $props
     */
    public static function outOfSchedule(array $props, ?int $now = null): bool
    {
        static $zone = null;

        if ($zone === null) {
            try {
                $zone = new DateTimeZone((string) (Factory::getApplication()->get('offset') ?: 'UTC'));
            } catch (Throwable $e) {
                $zone = new DateTimeZone('UTC');
            }
        }

        $time = static function ($value) use ($zone): int {
            if (trim((string) $value) === '') {
                return 0;
            }

            try {
                return (new DateTime((string) $value, $zone))->getTimestamp();
            } catch (Exception $e) {
                return 0;
            }
        };

        $now ??= time();
        $from  = $time($props['show_from'] ?? '');
        $until = $time($props['show_until'] ?? '');

        return ($from && $now < $from) || ($until && $now >= $until);
    }
}
