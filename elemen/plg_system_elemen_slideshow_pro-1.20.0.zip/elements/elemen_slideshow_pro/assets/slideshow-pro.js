/* Elemen: Slideshow Pro — content entrance, Ken Burns restarts and its own autoplay on top of
   UIkit's Slideshow. The autoplay pauses on hover, keyboard focus, off-screen, in hidden tabs
   and with the Pause button, and every slide can have its own duration. No dependencies. */
(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)');

    // Title word by word: wrap every word in a span, numbered for the stagger.
    function split(title) {
        let n = 0;

        const walk = (node) => {
            [...node.childNodes].forEach((child) => {
                if (child.nodeType === Node.TEXT_NODE) {
                    if (!child.textContent.trim()) {
                        return;
                    }

                    const parts = document.createDocumentFragment();

                    child.textContent.split(/(\s+)/).forEach((part) => {
                        if (!part) {
                            return;
                        }

                        if (/^\s+$/.test(part)) {
                            parts.append(part);
                            return;
                        }

                        const word = document.createElement('span');
                        word.className = 'ssp-word';
                        word.textContent = part;
                        word.style.setProperty('--ssp-w', n++);
                        parts.append(word);
                    });

                    child.replaceWith(parts);
                } else if (child.nodeType === Node.ELEMENT_NODE && !child.matches('br, img, svg, .uk-hidden-visually')) {
                    walk(child);
                }
            });
        };

        walk(title);
        title.setAttribute('data-ssp-split', '');
    }

    // The theme's primary and secondary colours for progress fills, read once from UIkit's
    // background classes outside any dark section.
    let colors = null;

    function themeColors(root) {
        if (!/\bssp-fill-(primary|secondary|gradient)\b/.test(root.className)) {
            return;
        }

        if (!colors) {
            const probe = (cls) => {
                const el = document.createElement('div');
                el.className = cls;
                el.style.cssText = 'position:absolute;width:0;height:0;visibility:hidden';
                document.body.append(el);
                const color = getComputedStyle(el).backgroundColor;
                el.remove();
                return color;
            };

            colors = { primary: probe('uk-background-primary'), secondary: probe('uk-background-secondary') };

            // Many themes have a near-grey secondary colour; a gradient into it looks like a
            // shadow, so it ends in a lighter primary instead.
            const [r, g, b] = (colors.secondary.match(/\d+(\.\d+)?/g) || []).map(Number);
            const grey = Math.max(r, g, b) - Math.min(r, g, b) < 24;
            colors.end = grey ? `color-mix(in srgb, ${colors.primary} 55%, #fff)` : colors.secondary;
        }

        root.style.setProperty('--ssp-primary', colors.primary);
        root.style.setProperty('--ssp-secondary', colors.secondary);
        root.style.setProperty('--ssp-gradient-end', colors.end);
    }

    // Background video of a slide: YouTube and Vimeo over postMessage, Facebook as a plain
    // iframe (loaded while shown, removed when hidden) and video files. Muted, no controls,
    // looping unless the slideshow waits for the end. on(event, value): 'playing', 'ended',
    // 'progress' (0-1). Loaded only once the slide is shown (and consent is given).
    function player(box, wait, on) {
        let info = {};

        try {
            info = JSON.parse(box.getAttribute('data-ssp-video') || '{}');
        } catch (e) {
            return null;
        }

        const type = info.type;
        const loop = wait ? 0 : 1;
        let el = null;
        let wanted = false;
        let ready = false;

        const playing = () => {
            box.classList.add('is-playing');
            on('playing');
        };

        const frame = (src) => {
            const f = document.createElement('iframe');
            f.src = src;
            f.allow = 'autoplay; encrypted-media; picture-in-picture';
            f.setAttribute('tabindex', '-1');
            f.setAttribute('title', 'Video');
            f.setAttribute('frameborder', '0');
            return f;
        };

        const post = (data) => el && el.contentWindow && el.contentWindow.postMessage(JSON.stringify(data), '*');

        const listen = (origin, handle) => window.addEventListener('message', (event) => {
            if (!el || event.source !== el.contentWindow || !origin.test(event.origin)) {
                return;
            }

            let data = event.data;

            try {
                data = typeof data === 'string' ? JSON.parse(data) : data;
            } catch (e) {
                return;
            }

            handle(data || {});
        });

        const create = () => {
            if (type === 'file') {
                el = document.createElement('video');
                el.muted = true;
                el.defaultMuted = true;
                el.playsInline = true;
                el.loop = !wait;
                el.preload = 'auto';
                el.setAttribute('muted', '');
                el.setAttribute('playsinline', '');
                el.src = info.src;
                el.addEventListener('playing', playing);
                el.addEventListener('ended', () => on('ended'));
                el.addEventListener('timeupdate', () => el.duration && on('progress', el.currentTime / el.duration));
                ready = true;
            } else if (type === 'youtube') {
                el = frame(`https://www.youtube-nocookie.com/embed/${info.id}?autoplay=1&mute=1&controls=0&loop=${loop}&playlist=${info.id}&playsinline=1&rel=0&disablekb=1&iv_load_policy=3&modestbranding=1&enablejsapi=1&origin=${encodeURIComponent(location.origin)}`);
                el.addEventListener('load', () => {
                    ready = true;
                    post({ event: 'listening', id: 1, channel: 'widget' });
                    post({ event: 'command', func: wanted ? 'playVideo' : 'pauseVideo', args: [] });
                });
                let shown = false;

                listen(/^https:\/\/www\.youtube(-nocookie)?\.com$/, (data) => {
                    const i = data.info || {};

                    if (i.playerState === 1) {
                        // YouTube shows its controls for a moment when it starts; fade in after.
                        if (!shown) {
                            shown = true;
                            setTimeout(playing, 2500);
                        }
                    } else if (i.playerState === 0) {
                        on('ended');
                    }

                    if (i.currentTime && i.duration) {
                        on('progress', i.currentTime / i.duration);
                    }
                });
            } else if (type === 'vimeo') {
                el = frame(`https://player.vimeo.com/video/${info.id}?${info.hash ? `h=${info.hash}&` : ''}background=1&autoplay=1&muted=1&loop=${loop}&autopause=0&dnt=1&playsinline=1`);
                el.addEventListener('load', () => {
                    ready = true;
                    ['play', 'ended', 'timeupdate'].forEach((value) => post({ method: 'addEventListener', value }));
                    post({ method: wanted ? 'play' : 'pause' });
                });
                listen(/^https:\/\/player\.vimeo\.com$/, (data) => {
                    if (data.event === 'play' || data.event === 'ready' && wanted) {
                        playing();
                    } else if (data.event === 'ended') {
                        on('ended');
                    } else if (data.event === 'timeupdate' && data.data) {
                        on('progress', Number(data.data.percent) || 0);
                    }
                });
            } else {
                return false;
            }

            box.append(el);
            return true;
        };

        box.classList.add(`ssp-video-${type}`);

        return {
            play() {
                wanted = true;

                if (!el && !create()) {
                    return;
                }

                if (type === 'file') {
                    const promise = el.play();
                    promise && promise.catch(() => {});
                } else if (type === 'youtube' && ready) {
                    post({ event: 'command', func: 'playVideo', args: [] });
                } else if (type === 'vimeo' && ready) {
                    post({ method: 'play' });
                }
            },

            pause() {
                wanted = false;

                if (!el) {
                    return;
                }

                if (type === 'file') {
                    el.pause();
                } else if (type === 'youtube') {
                    post({ event: 'command', func: 'pauseVideo', args: [] });
                } else if (type === 'vimeo') {
                    post({ method: 'pause' });
                }
            },

            // Back to the start for the next time the slide is shown.
            rewind() {
                if (type === 'file' && el) {
                    el.currentTime = 0;
                } else if (type === 'youtube') {
                    post({ event: 'command', func: 'seekTo', args: [0, true] });
                } else if (type === 'vimeo') {
                    post({ method: 'setCurrentTime', value: 0 });
                }
            },
        };
    }

    function setup(root) {
        const UIkit = window.UIkit;
        const slideshow = UIkit && UIkit.getComponent(root, 'slideshow');

        if (!slideshow) {
            return false;
        }

        root.setAttribute('data-ssp-ready', '');
        root.classList.add('ssp-js');

        let options = {};

        try {
            options = JSON.parse(root.getAttribute('data-ssp') || '{}');
        } catch (e) {
            // Keep the defaults.
        }

        const stage = root.querySelector(':scope > .ssp-stage');
        const slides = [...stage.querySelectorAll(':scope > .ssp-items > .ssp-slide')];
        const ui = [...stage.querySelectorAll(':scope > .ssp-ui')];
        const bar = root.querySelector(':scope > .ssp-bar, :scope > .ssp-stage > .ssp-bar');
        const button = bar && bar.querySelector('.ssp-pause');
        const counter = bar && bar.querySelector('.ssp-counter-current');
        const barFill = stage.querySelector(':scope > .ssp-progress > .ssp-fill');
        const navFills = bar ? [...bar.querySelectorAll('.ssp-nav-list > li .ssp-fill')] : [];
        const own = (event) => slides.includes(event.target);
        let current = 0;

        themeColors(root);

        root.querySelectorAll('[data-ssp-words]:not([data-ssp-split])').forEach(split);

        const durationOf = (slide) => (Number(slide && slide.getAttribute('data-ssp-duration')) || Number(options.duration) || 6) * 1000;

        // Controls take the text colour of the shown slide.
        const paint = (slide) => {
            const light = !slide.classList.contains('uk-inverse-dark');

            ui.forEach((el) => {
                el.classList.toggle('uk-light', light);
                el.classList.toggle('uk-dark', !light);
            });
        };

        // Ken Burns restarts each time a slide is shown.
        const kenburns = (slide) => {
            slide.style.setProperty('--ssp-kb-dur', `${durationOf(slide) / 1000 + 4}s`);
            slide.classList.remove('ssp-kb-run');
            void slide.offsetWidth;
            slide.classList.add('ssp-kb-run');
        };

        // Two frames, so the hidden state is painted before the entrance starts.
        const enter = (slide) => requestAnimationFrame(() => requestAnimationFrame(() => slide.classList.add('ssp-in')));

        // Progress fills (the edge bar and the shown slide's Lines/Titles/Thumbnails item):
        // set to a fraction, then optionally run to full in `ms` milliseconds.
        const fill = (targets, fraction, ms = 0, ease = '') => targets.forEach((el) => {
            el.style.transition = 'none';
            el.style.transform = `scaleX(${fraction})`;

            if (ms) {
                void el.offsetWidth;
                el.style.transition = `transform ${ms}ms ${ease || 'linear'}`;
                el.style.transform = `scaleX(${ease ? fraction : 1})`;
            }
        });

        const fills = () => [barFill, navFills[current]].filter(Boolean);

        // Without autoplay the edge bar shows how far through the slides the visitor is.
        const position = () => {
            fill(navFills.filter((el, i) => i !== current), 0);

            if (barFill) {
                fill([barFill], (current + 1) / slides.length, 400, 'ease');
            }

            if (navFills[current]) {
                fill([navFills[current]], 1, 400, 'ease');
            }
        };

        // Autoplay: one timer for the shown slide; any pause reason stops it, the rest of the
        // time is kept.
        const reasons = new Set();
        let timer = 0;
        let started = 0;
        let remaining = 0;
        let total = 0;

        const halt = () => {
            if (timer) {
                clearTimeout(timer);
                timer = 0;
                remaining = Math.max(0, remaining - (Date.now() - started));
            }

            if (options.autoplay && total) {
                fill(fills(), 1 - remaining / total);
            }

            root.classList.remove('is-running');
        };

        const run = () => {
            halt();

            if (!options.autoplay || reasons.size || remaining <= 0) {
                return;
            }

            started = Date.now();
            timer = setTimeout(() => {
                timer = 0;
                remaining = 0;
                slideshow.show('next');
            }, remaining);
            fill(fills(), 1 - remaining / total, remaining);
            root.classList.add('is-running');
        };

        // Videos: the shown slide's video plays unless the visitor paused the slideshow, it is
        // off-screen or the tab is hidden. With "wait", autoplay moves on when it ends and the
        // fills follow the video. No video with reduced motion, before consent, or on phones
        // when switched off; the image stays.
        const phone = window.matchMedia('(max-width: 639.98px)');
        const players = new Map();
        const waitForVideo = Boolean(options.autoplay && options.wait);
        let waiting = false;
        let fallback = 0;

        const consented = (box) => {
            const service = box.getAttribute('data-ssp-consent');
            const consent = window.yootheme && window.yootheme.consent;

            return !service || !consent || consent.hasConsent(service);
        };

        const playerOf = (slide) => {
            if (!players.has(slide)) {
                const box = slide.querySelector(':scope > .ssp-media > .ssp-video');
                const allowed = box && !reduce.matches && (options.phones !== false || !phone.matches) && consented(box);

                players.set(slide, allowed ? player(box, waitForVideo, (type, value) => onVideo(slide, type, value)) : null);
            }

            return players.get(slide);
        };

        const blocked = () => ['user', 'offscreen', 'tab', 'lightbox'].some((reason) => reasons.has(reason));

        const syncVideo = () => {
            const slide = slides[current];
            const p = slide && playerOf(slide);

            if (p) {
                blocked() ? p.pause() : p.play();
            }
        };

        function onVideo(slide, type, value) {
            if (slides[current] !== slide || !waiting) {
                return;
            }

            if (type === 'playing') {
                clearTimeout(fallback);
            } else if (type === 'progress') {
                fill(fills(), Math.min(1, Math.max(0, value)));
            } else if (type === 'ended') {
                waiting = false;
                clearTimeout(fallback);
                total = remaining = 1;
                run();
            }
        }

        const restart = (slide) => {
            clearTimeout(timer);
            timer = 0;
            syncVideo();

            const p = waitForVideo ? playerOf(slide) : null;

            if (p) {
                // Wait for the end; if the video never starts, fall back to the duration.
                waiting = true;
                total = remaining = 0;
                root.classList.remove('is-running');
                fallback = setTimeout(() => {
                    if (waiting && slides[current] === slide) {
                        waiting = false;
                        total = remaining = durationOf(slide);
                        run();
                    }
                }, 10000);
                return;
            }

            total = remaining = durationOf(slide);
            run();
        };

        // Play video (Facebook): a UIkit lightbox; the slideshow pauses while it is open.
        root.addEventListener('click', (event) => {
            const open = event.target.closest('[data-ssp-lightbox]');

            if (!open || !root.contains(open) || !UIkit.lightboxPanel) {
                return;
            }

            event.preventDefault();

            const panel = UIkit.lightboxPanel({ items: [{ source: open.getAttribute('data-ssp-lightbox'), type: 'iframe' }] });

            pause('lightbox');
            UIkit.util.on(panel.$el, 'hidden', () => {
                resume('lightbox');
                panel.$destroy(true);
                open.focus();
            });
            panel.show();
        });

        document.addEventListener('yootheme:consent.video', (event) => {
            slides.forEach((slide) => {
                const box = slide.querySelector(':scope > .ssp-media > .ssp-video');

                if (box && box.getAttribute('data-ssp-consent') === event.detail) {
                    players.delete(slide);
                }
            });
            syncVideo();
        });

        // A new slide: the counter, empty fills and a fresh time (the timer starts once the
        // transition has finished).
        const select = (slide) => {
            clearTimeout(timer);
            clearTimeout(fallback);
            timer = 0;
            waiting = false;
            fill(fills(), 0);
            current = Math.max(0, slides.indexOf(slide));
            total = remaining = durationOf(slide);

            if (counter) {
                counter.textContent = String(current + 1).padStart(2, '0');
            }

            if (options.autoplay) {
                fill(fills(), 0);
            } else {
                position();
            }
        };

        const pause = (reason) => {
            reasons.add(reason);
            halt();
            root.classList.add('is-paused');
            syncVideo();
        };

        const resume = (reason) => {
            if (!reasons.delete(reason)) {
                return;
            }

            syncVideo();

            if (reasons.size) {
                return;
            }

            root.classList.remove('is-paused');
            run();
        };

        // Clip transitions: the new slide is drawn over the old one during UIkit's fade, in
        // the same time (UIkit: half the width divided by the velocity, plus 300ms).
        const clip = root.classList.contains('ssp-clip');
        const rtl = getComputedStyle(root).direction === 'rtl';

        const clipStart = (slide) => {
            const next = slides.indexOf(slide);
            const n = slides.length;
            const dir = typeof slideshow.dir === 'number' && slideshow.dir ? slideshow.dir : ((next - current + n) % n <= n / 2 ? 1 : -1);
            const ms = Math.round((0.5 * stage.offsetWidth) / (Number(slideshow.velocity) || 1) + 300);

            root.style.setProperty('--ssp-clip-dur', `${ms}ms`);
            slide.classList.toggle('ssp-back', (dir < 0) !== rtl);
            slide.classList.add('ssp-entering');
        };

        root.addEventListener('beforeitemshow', (event) => {
            if (own(event)) {
                if (clip) {
                    clipStart(event.target);
                }

                select(event.target);
                paint(event.target);
                kenburns(event.target);
                syncVideo();
            }
        });

        root.addEventListener('beforeitemhide', (event) => {
            if (own(event)) {
                event.target.classList.remove('ssp-in');
                event.target.classList.add('ssp-out');

                if (clip) {
                    event.target.classList.add('ssp-leaving');
                }
            }
        });

        root.addEventListener('itemshow', (event) => {
            if (own(event)) {
                enter(event.target);
            }
        });

        root.addEventListener('itemshown', (event) => {
            if (own(event)) {
                event.target.classList.remove('ssp-entering');
                restart(event.target);
            }
        });

        root.addEventListener('itemhidden', (event) => {
            if (own(event)) {
                event.target.classList.remove('ssp-kb-run', 'ssp-in', 'ssp-out', 'ssp-leaving');

                const p = players.get(event.target);

                if (p) {
                    p.pause();
                    p.rewind();
                }
            }
        });

        // UIkit's dragging is off for clip transitions; a swipe still changes the slide.
        if (clip) {
            let start = null;

            stage.addEventListener('pointerdown', (event) => {
                start = event.isPrimary ? { x: event.clientX, y: event.clientY } : null;
            }, { passive: true });

            stage.addEventListener('pointerup', (event) => {
                if (!start) {
                    return;
                }

                const dx = event.clientX - start.x;
                const dy = event.clientY - start.y;
                start = null;

                if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.5) {
                    slideshow.show((dx < 0) !== rtl ? 'next' : 'previous');
                }
            });

            stage.addEventListener('pointercancel', () => {
                start = null;
            });
        }

        // Room for a Shape Divider shown in front at the bottom of the section, when the
        // slideshow reaches the section's bottom edge.
        const section = root.closest('.elemen-shapes-section');

        if (section) {
            const room = () => {
                const divider = section.querySelector(':scope > .elemen-shapes-bottom.elemen-shapes-front');
                const flush = divider && section.getBoundingClientRect().bottom - stage.getBoundingClientRect().bottom < 4;

                root.style.setProperty('--ssp-under', flush ? `${Math.round(divider.getBoundingClientRect().height)}px` : '0px');
            };

            room();

            if ('ResizeObserver' in window) {
                new ResizeObserver(room).observe(section);
            }
        }

        if (options.autoplay) {
            if (options.hover) {
                root.addEventListener('pointerenter', (event) => event.pointerType === 'mouse' && pause('hover'));
                root.addEventListener('pointerleave', () => resume('hover'));
            }

            // Keyboard focus inside the slideshow pauses it (WCAG 2.2.2); mouse clicks don't.
            root.addEventListener('focusin', (event) => {
                if (event.target.matches(':focus-visible')) {
                    pause('focus');
                }
            });

            root.addEventListener('focusout', (event) => {
                if (!root.contains(event.relatedTarget)) {
                    resume('focus');
                }
            });

            document.addEventListener('visibilitychange', () => (document.hidden ? pause('tab') : resume('tab')));

            if ('IntersectionObserver' in window) {
                new IntersectionObserver(([entry]) => (entry.isIntersecting ? resume('offscreen') : pause('offscreen')), { threshold: 0.2 }).observe(root);
            }

            if (button) {
                button.addEventListener('click', () => {
                    const paused = reasons.has('user');

                    paused ? resume('user') : pause('user');
                    root.classList.toggle('is-paused-user', !paused);
                    button.setAttribute('data-ssp-state', paused ? 'playing' : 'paused');
                    button.setAttribute('aria-label', button.getAttribute(paused ? 'data-ssp-pause' : 'data-ssp-play'));
                });
            }
        }

        // Scroll-down hint: to the end of the slideshow, below a sticky header.
        const scroll = stage.querySelector(':scope > .ssp-scroll');

        if (scroll) {
            scroll.addEventListener('click', () => {
                const header = document.querySelector('.uk-sticky-fixed, .uk-navbar-sticky');
                const offset = header ? header.getBoundingClientRect().height : 0;

                window.scrollTo({
                    top: window.scrollY + root.getBoundingClientRect().bottom - offset,
                    behavior: reduce.matches ? 'auto' : 'smooth',
                });
            });
        }

        // The slide shown at the start.
        const active = slides.find((slide) => slide.classList.contains('uk-active')) || slides[0];

        if (active) {
            select(active);
            paint(active);
            kenburns(active);
            enter(active);
            restart(active);
        }

        return true;
    }

    // UIkit may connect its Slideshow after this script runs (and after builder updates), so
    // slideshows that aren't ready yet are tried again for a short while.
    let tries = 0;

    const init = () => {
        let waiting = false;

        document.querySelectorAll('.elemen-slideshow-pro:not([data-ssp-ready])').forEach((root) => {
            waiting = !setup(root) || waiting;
        });

        if (waiting && tries++ < 120) {
            requestAnimationFrame(init);
        } else if (!waiting) {
            tries = 0;
        }
    };

    const boot = () => {
        init();

        // The YOOtheme builder preview replaces elements while editing.
        new MutationObserver(() => {
            tries = 0;
            init();
        }).observe(document.body, { childList: true, subtree: true });
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
