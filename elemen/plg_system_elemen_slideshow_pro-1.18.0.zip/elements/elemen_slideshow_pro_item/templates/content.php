<?php

/**
 * Plain HTML stored in the article text, used by search and when the builder is off.
 *
 * @var array<string, mixed> $props
 */

\defined('_JEXEC') or die;

?>
<?php if ($props['eyebrow'] ?? '') : ?>
<p><?= $props['eyebrow'] ?></p>
<?php endif ?>
<?php if ($props['title'] ?? '') : ?>
<h2><?= $props['title'] ?></h2>
<?php endif ?>
<?php if ($props['content'] ?? '') : ?>
<?= $props['content'] ?>
<?php endif ?>
<?php foreach ([1, 2] as $n) : ?>
<?php if (($props["button{$n}_link"] ?? '') && ($props["button{$n}_text"] ?? '')) : ?>
<p><a href="<?= htmlspecialchars((string) $props["button{$n}_link"], ENT_QUOTES, 'UTF-8') ?>"><?= $props["button{$n}_text"] ?></a></p>
<?php endif ?>
<?php endforeach ?>
