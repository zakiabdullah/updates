/* Elemen: Slideshow Pro — content entrance, Ken Burns restarts and its own autoplay on top of
   UIkit's Slideshow. The autoplay pauses on hover, keyboard focus, off-screen, in hidden tabs
   and with the Pause button, and every slide can have its own duration. No dependencies. */
(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)');

    // Title word by word: wrap every word in a span, numbered for the stagger.
    function split(title) {
        let n = 0;

        const walk = (node) => {
            [...node.childNodes].forEach((child) => {
                if (child.nodeType === Node.TEXT_NODE) {
                    if (!child.textContent.trim()) {
                        return;
                    }

                    const parts = document.createDocumentFragment();

                    child.textContent.split(/(\s+)/).forEach((part) => {
                        if (!part) {
                            return;
                        }

                        if (/^\s+$/.test(part)) {
                            parts.append(part);
                            return;
                        }

                        const word = document.createElement('span');
                        word.className = 'ssp-word';
                        word.textContent = part;
                        word.style.setProperty('--ssp-w', n++);
                        parts.append(word);
                    });

                    child.replaceWith(parts);
                } else if (child.nodeType === Node.ELEMENT_NODE && !child.matches('br, img, svg, .uk-hidden-visually')) {
                    walk(child);
                }
            });
        };

        walk(title);
        title.setAttribute('data-ssp-split', '');
    }

    // The theme's primary and secondary colours for progress fills, read once from UIkit's
    // background classes outside any dark section.
    let colors = null;

    function themeColors(root) {
        if (!/\bssp-fill-(primary|secondary|gradient)\b/.test(root.className)) {
            return;
        }

        if (!colors) {
            const probe = (cls) => {
                const el = document.createElement('div');
                el.className = cls;
                el.style.cssText = 'position:absolute;width:0;height:0;visibility:hidden';
                document.body.append(el);
                const color = getComputedStyle(el).backgroundColor;
                el.remove();
                return color;
            };

            colors = { primary: probe('uk-background-primary'), secondary: probe('uk-background-secondary') };

            // Many themes have a near-grey secondary colour; a gradient into it looks like a
            // shadow, so it ends in a lighter primary instead.
            const [r, g, b] = (colors.secondary.match(/\d+(\.\d+)?/g) || []).map(Number);
            const grey = Math.max(r, g, b) - Math.min(r, g, b) < 24;
            colors.end = grey ? `color-mix(in srgb, ${colors.primary} 55%, #fff)` : colors.secondary;
        }

        root.style.setProperty('--ssp-primary', colors.primary);
        root.style.setProperty('--ssp-secondary', colors.secondary);
        root.style.setProperty('--ssp-gradient-end', colors.end);
    }

    function setup(root) {
        const UIkit = window.UIkit;
        const slideshow = UIkit && UIkit.getComponent(root, 'slideshow');

        if (!slideshow) {
            return false;
        }

        root.setAttribute('data-ssp-ready', '');
        root.classList.add('ssp-js');

        let options = {};

        try {
            options = JSON.parse(root.getAttribute('data-ssp') || '{}');
        } catch (e) {
            // Keep the defaults.
        }

        const stage = root.querySelector(':scope > .ssp-stage');
        const slides = [...stage.querySelectorAll(':scope > .ssp-items > .ssp-slide')];
        const ui = [...stage.querySelectorAll(':scope > .ssp-ui')];
        const bar = root.querySelector(':scope > .ssp-bar, :scope > .ssp-stage > .ssp-bar');
        const button = bar && bar.querySelector('.ssp-pause');
        const counter = bar && bar.querySelector('.ssp-counter-current');
        const barFill = stage.querySelector(':scope > .ssp-progress > .ssp-fill');
        const navFills = bar ? [...bar.querySelectorAll('.ssp-nav-list > li .ssp-fill')] : [];
        const own = (event) => slides.includes(event.target);
        let current = 0;

        themeColors(root);

        root.querySelectorAll('[data-ssp-words]:not([data-ssp-split])').forEach(split);

        const durationOf = (slide) => (Number(slide && slide.getAttribute('data-ssp-duration')) || Number(options.duration) || 6) * 1000;

        // Controls take the text colour of the shown slide.
        const paint = (slide) => {
            const light = !slide.classList.contains('uk-inverse-dark');

            ui.forEach((el) => {
                el.classList.toggle('uk-light', light);
                el.classList.toggle('uk-dark', !light);
            });
        };

        // Ken Burns restarts each time a slide is shown.
        const kenburns = (slide) => {
            slide.style.setProperty('--ssp-kb-dur', `${durationOf(slide) / 1000 + 4}s`);
            slide.classList.remove('ssp-kb-run');
            void slide.offsetWidth;
            slide.classList.add('ssp-kb-run');
        };

        // Two frames, so the hidden state is painted before the entrance starts.
        const enter = (slide) => requestAnimationFrame(() => requestAnimationFrame(() => slide.classList.add('ssp-in')));

        // Progress fills (the edge bar and the shown slide's Lines/Titles/Thumbnails item):
        // set to a fraction, then optionally run to full in `ms` milliseconds.
        const fill = (targets, fraction, ms = 0, ease = '') => targets.forEach((el) => {
            el.style.transition = 'none';
            el.style.transform = `scaleX(${fraction})`;

            if (ms) {
                void el.offsetWidth;
                el.style.transition = `transform ${ms}ms ${ease || 'linear'}`;
                el.style.transform = `scaleX(${ease ? fraction : 1})`;
            }
        });

        const fills = () => [barFill, navFills[current]].filter(Boolean);

        // Without autoplay the edge bar shows how far through the slides the visitor is.
        const position = () => {
            fill(navFills.filter((el, i) => i !== current), 0);

            if (barFill) {
                fill([barFill], (current + 1) / slides.length, 400, 'ease');
            }

            if (navFills[current]) {
                fill([navFills[current]], 1, 400, 'ease');
            }
        };

        // Autoplay: one timer for the shown slide; any pause reason stops it, the rest of the
        // time is kept.
        const reasons = new Set();
        let timer = 0;
        let started = 0;
        let remaining = 0;
        let total = 0;

        const halt = () => {
            if (timer) {
                clearTimeout(timer);
                timer = 0;
                remaining = Math.max(0, remaining - (Date.now() - started));
            }

            if (options.autoplay && total) {
                fill(fills(), 1 - remaining / total);
            }

            root.classList.remove('is-running');
        };

        const run = () => {
            halt();

            if (!options.autoplay || reasons.size || remaining <= 0) {
                return;
            }

            started = Date.now();
            timer = setTimeout(() => {
                timer = 0;
                remaining = 0;
                slideshow.show('next');
            }, remaining);
            fill(fills(), 1 - remaining / total, remaining);
            root.classList.add('is-running');
        };

        const restart = (slide) => {
            clearTimeout(timer);
            timer = 0;
            total = remaining = durationOf(slide);
            run();
        };

        // A new slide: the counter, empty fills and a fresh time (the timer starts once the
        // transition has finished).
        const select = (slide) => {
            clearTimeout(timer);
            timer = 0;
            fill(fills(), 0);
            current = Math.max(0, slides.indexOf(slide));
            total = remaining = durationOf(slide);

            if (counter) {
                counter.textContent = String(current + 1).padStart(2, '0');
            }

            if (options.autoplay) {
                fill(fills(), 0);
            } else {
                position();
            }
        };

        const pause = (reason) => {
            reasons.add(reason);
            halt();
            root.classList.add('is-paused');
        };

        const resume = (reason) => {
            if (!reasons.delete(reason) || reasons.size) {
                return;
            }

            root.classList.remove('is-paused');
            run();
        };

        root.addEventListener('beforeitemshow', (event) => {
            if (own(event)) {
                select(event.target);
                paint(event.target);
                kenburns(event.target);
            }
        });

        root.addEventListener('beforeitemhide', (event) => {
            if (own(event)) {
                event.target.classList.remove('ssp-in');
            }
        });

        root.addEventListener('itemshow', (event) => {
            if (own(event)) {
                enter(event.target);
            }
        });

        root.addEventListener('itemshown', (event) => {
            if (own(event)) {
                restart(event.target);
            }
        });

        root.addEventListener('itemhidden', (event) => {
            if (own(event)) {
                event.target.classList.remove('ssp-kb-run', 'ssp-in');
            }
        });

        if (options.autoplay) {
            if (options.hover) {
                root.addEventListener('pointerenter', (event) => event.pointerType === 'mouse' && pause('hover'));
                root.addEventListener('pointerleave', () => resume('hover'));
            }

            // Keyboard focus inside the slideshow pauses it (WCAG 2.2.2); mouse clicks don't.
            root.addEventListener('focusin', (event) => {
                if (event.target.matches(':focus-visible')) {
                    pause('focus');
                }
            });

            root.addEventListener('focusout', (event) => {
                if (!root.contains(event.relatedTarget)) {
                    resume('focus');
                }
            });

            document.addEventListener('visibilitychange', () => (document.hidden ? pause('tab') : resume('tab')));

            if ('IntersectionObserver' in window) {
                new IntersectionObserver(([entry]) => (entry.isIntersecting ? resume('offscreen') : pause('offscreen')), { threshold: 0.2 }).observe(root);
            }

            if (button) {
                button.addEventListener('click', () => {
                    const paused = reasons.has('user');

                    paused ? resume('user') : pause('user');
                    root.classList.toggle('is-paused-user', !paused);
                    button.setAttribute('data-ssp-state', paused ? 'playing' : 'paused');
                    button.setAttribute('aria-label', button.getAttribute(paused ? 'data-ssp-pause' : 'data-ssp-play'));
                });
            }
        }

        // Scroll-down hint: to the end of the slideshow, below a sticky header.
        const scroll = stage.querySelector(':scope > .ssp-scroll');

        if (scroll) {
            scroll.addEventListener('click', () => {
                const header = document.querySelector('.uk-sticky-fixed, .uk-navbar-sticky');
                const offset = header ? header.getBoundingClientRect().height : 0;

                window.scrollTo({
                    top: window.scrollY + root.getBoundingClientRect().bottom - offset,
                    behavior: reduce.matches ? 'auto' : 'smooth',
                });
            });
        }

        // The slide shown at the start.
        const active = slides.find((slide) => slide.classList.contains('uk-active')) || slides[0];

        if (active) {
            select(active);
            paint(active);
            kenburns(active);
            enter(active);
            restart(active);
        }

        return true;
    }

    // UIkit may connect its Slideshow after this script runs (and after builder updates), so
    // slideshows that aren't ready yet are tried again for a short while.
    let tries = 0;

    const init = () => {
        let waiting = false;

        document.querySelectorAll('.elemen-slideshow-pro:not([data-ssp-ready])').forEach((root) => {
            waiting = !setup(root) || waiting;
        });

        if (waiting && tries++ < 120) {
            requestAnimationFrame(init);
        } else if (!waiting) {
            tries = 0;
        }
    };

    const boot = () => {
        init();

        // The YOOtheme builder preview replaces elements while editing.
        new MutationObserver(() => {
            tries = 0;
            init();
        }).observe(document.body, { childList: true, subtree: true });
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
