<?php

/**
 * Slideshow Pro helpers: checked settings, slide schedule and colours.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

use Joomla\CMS\Factory;

\defined('_JEXEC') or die;

if (class_exists('ElemenSlideshowPro', false)) {
    return;
}

final class ElemenSlideshowPro
{
    /** Settings with fixed values; the first is the default. */
    public const OPTIONS = [
        'height'            => ['viewport', 'ratio', 'fixed'],
        'ratio'             => ['16:7', '16:9', '21:9', '3:1', '4:3'],
        'transition'        => ['slide', 'fade', 'scale', 'pull', 'push'],
        'transition_speed'  => ['normal', 'slow', 'fast'],
        'kenburns'          => ['', 'zoom-in', 'zoom-out', 'pan-left', 'pan-right', 'auto'],
        'overlay'           => ['dark', 'none', 'light', 'primary', 'secondary', 'custom'],
        'overlay_type'      => ['solid', 'bottom', 'start', 'vignette'],
        'content_position'  => ['center-left', 'top-left', 'top-center', 'top-right', 'center', 'center-right', 'bottom-left', 'bottom-center', 'bottom-right'],
        'content_width'     => ['medium', 'small', 'large', 'xlarge'],
        'text_color'        => ['light', 'dark'],
        'eyebrow_style'     => ['kicker', 'label', 'meta'],
        'title_style'       => ['heading-medium', 'heading-small', 'heading-large', 'heading-xlarge', 'h1', 'h2'],
        'title_element'     => ['h2', 'h1-first', 'h1', 'h3', 'div'],
        'content_style'     => ['lead', '', 'small'],
        'button1_style'     => ['primary', 'secondary', 'default', 'text'],
        'button2_style'     => ['default', 'primary', 'secondary', 'text'],
        'button_size'       => ['', 'large', 'small'],
        'content_animation' => ['fade-up', 'slide', 'blur', 'mask', 'words', 'fade', 'none'],
        'nav'               => ['dots', 'lines', 'titles', 'thumbs', 'none'],
        'nav_position'      => ['center', 'start', 'end', 'below'],
        'arrow_style'       => ['minimal', 'circle', 'square', 'glass'],
        'arrow_position'    => ['sides', 'bar'],
        'progress'          => ['', 'bottom', 'top'],
        'progress_color'    => ['auto', 'primary', 'secondary', 'gradient'],
    ];

    /** Item settings that override the element's; '' = as the element. */
    public const ITEM_OPTIONS = [
        'kenburns'         => ['', 'none', 'zoom-in', 'zoom-out', 'pan-left', 'pan-right'],
        'overlay'          => ['', 'none', 'dark', 'light', 'primary', 'secondary'],
        'content_position' => ['', 'center-left', 'top-left', 'top-center', 'top-right', 'center', 'center-right', 'bottom-left', 'bottom-center', 'bottom-right'],
        'text_color'       => ['', 'light', 'dark'],
        'image_focal'      => ['', 'top-left', 'top-center', 'top-right', 'center-left', 'center-right', 'bottom-left', 'bottom-center', 'bottom-right'],
        'image_mobile_focal' => ['', 'top-left', 'top-center', 'top-right', 'center-left', 'center-right', 'bottom-left', 'bottom-center', 'bottom-right'],
    ];

    /** Order of the Auto Ken Burns effects, one per slide. */
    public const KENBURNS_AUTO = ['zoom-in', 'pan-left', 'zoom-out', 'pan-right'];

    /** UIkit velocity per transition speed. */
    public const VELOCITY = ['slow' => 0.6, 'normal' => 1, 'fast' => 1.6];

    /**
     * The settings with every value checked.
     *
     * @param  array<string, mixed> $props
     * @return array<string, mixed>
     */
    public static function settings(array $props): array
    {
        // Layouts saved before Navigation existed only have the Dots checkbox.
        if (!isset($props['nav']) && isset($props['dots'])) {
            $props['nav'] = $props['dots'] ? 'dots' : 'none';
        }

        $s = [];

        foreach (self::OPTIONS as $key => $allowed) {
            $value   = (string) ($props[$key] ?? $allowed[0]);
            $s[$key] = in_array($value, $allowed, true) ? $value : $allowed[0];
        }

        $int = static fn (string $key, int $default, int $min, int $max): int => max($min, min($max, ($v = trim((string) ($props[$key] ?? ''))) === '' ? $default : (int) $v));

        $s['height_value']    = $int('height_value', $s['height'] === 'fixed' ? 600 : 100, $s['height'] === 'fixed' ? 200 : 20, $s['height'] === 'fixed' ? 1600 : 100);
        $s['min_height']      = $int('min_height', 400, 0, 1200);
        $s['duration']        = $int('duration', 6, 2, 60);
        $s['overlay_opacity'] = $int('overlay_opacity', 40, 0, 100);
        $s['anim_delay']      = $int('anim_delay', 250, 0, 2000);
        $s['anim_stagger']    = $int('anim_stagger', 120, 0, 1000);
        $s['anim_duration']   = $int('anim_duration', 800, 200, 3000);
        $s['progress_height'] = $int('progress_height', 3, 1, 8);
        $s['overlay_color']   = self::color($props['overlay_color'] ?? '');

        foreach (['viewport_offset' => true, 'autoplay' => true, 'pause_hover' => true, 'pause_button' => true, 'arrows' => true, 'arrows_hover' => false, 'counter' => false, 'scroll_hint' => false, 'content_container' => true, 'button_target' => false, 'image_eager' => true] as $key => $default) {
            $s[$key] = (bool) ($props[$key] ?? $default);
        }

        if ($s['overlay'] === 'custom' && $s['overlay_color'] === '') {
            $s['overlay'] = 'dark';
        }

        return $s;
    }

    /** An item setting: one of the allowed values, or '' (as the element). */
    public static function item(array $props, string $key): string
    {
        $value = (string) ($props[$key] ?? '');

        return in_array($value, self::ITEM_OPTIONS[$key], true) ? $value : '';
    }

    /** A CSS colour from a colour field, or '' when it isn't one. */
    public static function color($value): string
    {
        $value = trim((string) $value);

        return preg_match('/^(#[0-9a-f]{3,8}|(rgb|rgba|hsl|hsla|oklch|oklab)\([0-9.,%\s\/+-]+(deg)?\))$/i', $value) ? $value : '';
    }

    /** CSS object-position for a focal point such as "top-left"; '' for the centre. */
    public static function focal(string $focal): string
    {
        if ($focal === '') {
            return '';
        }

        [$y, $x] = array_pad(explode('-', $focal), 2, 'center');

        return ['left' => '0%', 'center' => '50%', 'right' => '100%'][$x] . ' ' . ['top' => '0%', 'center' => '50%', 'bottom' => '100%'][$y];
    }

    /**
     * Whether a slide is outside its show from/until dates, in the site's time zone.
     *
     * @param array<string, mixed> $props
     */
    public static function outOfSchedule(array $props, ?int $now = null): bool
    {
        static $zone = null;

        if ($zone === null) {
            try {
                $zone = new DateTimeZone((string) (Factory::getApplication()->get('offset') ?: 'UTC'));
            } catch (Throwable $e) {
                $zone = new DateTimeZone('UTC');
            }
        }

        $time = static function ($value) use ($zone): int {
            if (trim((string) $value) === '') {
                return 0;
            }

            try {
                return (new DateTime((string) $value, $zone))->getTimestamp();
            } catch (Exception $e) {
                return 0;
            }
        };

        $now ??= time();
        $from  = $time($props['show_from'] ?? '');
        $until = $time($props['show_until'] ?? '');

        return ($from && $now < $from) || ($until && $now >= $until);
    }
}
