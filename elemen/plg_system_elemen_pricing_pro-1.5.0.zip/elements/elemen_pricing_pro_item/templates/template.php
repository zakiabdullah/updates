<?php

/**
 * Pricing Pro plan: a card with the badge, icon or image, name, description, both prices,
 * the note, the features and the button. The parent passes its settings and labels.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<string, mixed> $element
 * @var array<string, string> $labels
 */

\defined('_JEXEC') or die;

require_once \dirname(__DIR__, 2) . '/elemen_pricing_pro/ElemenPricingPro.php';

$element ??= [];
$labels  ??= [];
$has       = static fn ($value): bool => trim((string) $value) !== '';
$highlight = !empty($props['highlight']);
$style     = $highlight && ($element['highlight_style'] ?? '') === 'primary' ? 'primary' : ($element['card_style'] ?? 'default');

// Prices: an empty yearly price shows the monthly one, with its period.
$monthly = trim((string) ($props['price_monthly'] ?? ''));
$yearly  = trim((string) ($props['price_yearly'] ?? ''));
$prices  = [
    'monthly' => $monthly !== '' ? ElemenPricingPro::price($monthly, (string) ($labels['period_monthly'] ?? ''), $element) : '',
    'yearly'  => $yearly !== ''
        ? ElemenPricingPro::price($yearly, (string) ($labels['period_yearly'] ?? ''), $element)
        : ($monthly !== '' ? ElemenPricingPro::price($monthly, (string) ($labels['period_monthly'] ?? ''), $element) : ''),
];

$titleTag = in_array($element['title_element'] ?? '', ['h2', 'h3', 'h4', 'div'], true) ? $element['title_element'] : 'h3';
$button   = $highlight ? ($element['highlight_button_style'] ?? 'primary') : ($element['button_style'] ?? 'default');
$button   = in_array($button, ['default', 'primary', 'secondary', 'text'], true) ? $button : 'default';

$el = $this->el('div', ['class' => ['el-item pp-item', 'pp-item-highlight' => $highlight]]);

$card = $this->el('div', [
    'class' => [
        'pp-card',
        "uk-card uk-card-{$style} uk-card-body" => in_array($style, ['default', 'primary', 'secondary'], true),
        'uk-background-muted uk-card-body' => $style === 'muted',
        'pp-card-none' => $style === 'none',
        'uk-light' => in_array($style, ['primary', 'secondary'], true),
    ],
]);

?>
<?= $el($props, $attrs) ?>
    <?= $card() ?>

        <?php if ($highlight && ($element['highlight_style'] ?? '') === 'border') : ?>
        <span class="pp-ring uk-text-primary" aria-hidden="true"></span>
        <?php endif ?>

        <?php if ($has($props['badge'] ?? '')) : ?>
        <div class="pp-badge"><span class="uk-label"><?= $props['badge'] ?></span></div>
        <?php endif ?>

        <?php if (!empty($props['image'])) : ?>
        <div class="pp-media"><?= $this->el('image', ['class' => ['el-image pp-image'], 'src' => $props['image'], 'alt' => $props['image_alt'] ?? '', 'loading' => 'lazy', 'thumbnail' => true])->render([]) ?></div>
        <?php elseif ($has($props['icon'] ?? '')) : ?>
        <div class="pp-media"><span class="pp-icon" uk-icon="icon: <?= htmlspecialchars((string) $props['icon']) ?>; ratio: 2" aria-hidden="true"></span></div>
        <?php endif ?>

        <?php if ($has($props['title'] ?? '')) : ?>
        <<?= $titleTag ?> class="el-title pp-title uk-margin-remove<?= $element['title_style'] ?? '' ? ' uk-' . $element['title_style'] : '' ?>"><?= $props['title'] ?></<?= $titleTag ?>>
        <?php endif ?>

        <?php if ($has($props['description'] ?? '')) : ?>
        <div class="pp-description uk-text-meta"><?= $props['description'] ?></div>
        <?php endif ?>

        <?php if ($prices['monthly'] !== '' || $prices['yearly'] !== '') : ?>
        <div class="el-price pp-price">
            <div class="pp-price-monthly"><?= $prices['monthly'] ?></div>
            <div class="pp-price-yearly"><?= $prices['yearly'] ?></div>
        </div>
        <?php endif ?>

        <?php if ($has($props['note'] ?? '')) : ?>
        <div class="pp-note uk-text-small"><?= $props['note'] ?></div>
        <?php endif ?>

        <?php if ($features = ElemenPricingPro::features((string) ($props['features'] ?? ''))) : ?>
        <ul class="pp-features uk-list">
            <?php foreach ($features as [$text, $included]) : ?>
            <li class="<?= $included ? 'pp-yes' : 'pp-no' ?>"><span class="pp-mark" uk-icon="icon: <?= $included ? 'check' : 'close' ?>; ratio: .85" aria-hidden="true"></span><span class="uk-hidden-visually"><?= htmlspecialchars($included ? ($labels['included'] ?? '') : ($labels['not_included'] ?? '')) ?>: </span><span class="pp-feature"><?= $text ?></span></li>
            <?php endforeach ?>
        </ul>
        <?php endif ?>

        <?php if ($has($props['link'] ?? '') && $has($props['link_text'] ?? '')) : ?>
        <div class="pp-action">
            <?= $this->el('a', [
                'class'  => ['el-link uk-button', "uk-button-{$button}", 'uk-width-1-1' => !empty($element['button_full'])],
                'href'   => ['{link}'],
                'target' => !empty($element['link_target']) ? '_blank' : false,
                'rel'    => !empty($element['link_target']) ? 'noopener' : false,
            ])->render($props, $props['link_text']) ?>
        </div>
        <?php endif ?>

    <?= $card->end() ?>
<?= $el->end() ?>
