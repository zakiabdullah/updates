<?php

/**
 * Plain HTML stored in the article text, used by search and when the builder is off.
 *
 * @var array<string, mixed> $props
 */

\defined('_JEXEC') or die;

require_once \dirname(__DIR__, 2) . '/elemen_pricing_pro/ElemenPricingPro.php';

?>
<?php if ($props['title'] ?? '') : ?>
<h3><?= $props['title'] ?></h3>
<?php endif ?>
<?php if ($props['description'] ?? '') : ?>
<p><?= $props['description'] ?></p>
<?php endif ?>
<?php if (($props['price_monthly'] ?? '') !== '' || ($props['price_yearly'] ?? '') !== '') : ?>
<p><?= implode(' / ', array_filter([$props['price_monthly'] ?? '', $props['price_yearly'] ?? ''], 'strlen')) ?></p>
<?php endif ?>
<?php if ($features = ElemenPricingPro::features((string) ($props['features'] ?? ''))) : ?>
<ul>
    <?php foreach ($features as [$text, $included]) : ?>
    <?php if ($included) : ?>
    <li><?= $text ?></li>
    <?php endif ?>
    <?php endforeach ?>
</ul>
<?php endif ?>
