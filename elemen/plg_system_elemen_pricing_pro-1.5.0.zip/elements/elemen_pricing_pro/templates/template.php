<?php

/**
 * Pricing Pro: plans side by side, each with a monthly and a yearly price.
 *
 * Both prices are in the page; a class on the element (pp-yearly) shows one of them. The
 * Monthly / Yearly switch (pricing-pro.js) changes that class and is hidden until the
 * script runs, so without it the price shown first stays.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var \YOOtheme\Builder $builder
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<int, object> $children
 */

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;
use YOOtheme\Metadata;

use function YOOtheme\app;

\defined('_JEXEC') or die;

require_once \dirname(__DIR__) . '/ElemenPricingPro.php';

$has = static fn ($value): bool => trim((string) $value) !== '';

// Plans with a name or a price.
$plans = array_values(array_filter($children, static function (object $child) use ($has): bool {
    $p = (array) ($child->props ?? []);

    return $has($p['title'] ?? '') || $has($p['price_monthly'] ?? '') || $has($p['price_yearly'] ?? '');
}));

if (!$plans) {
    return;
}

Factory::getApplication()->getLanguage()->load('plg_system_elemen_pricing_pro', JPATH_ADMINISTRATOR);

$assets   = \dirname(__DIR__) . '/assets';
$assetUrl = static fn (string $file): string => Uri::root(true) . '/'
    . str_replace('\\', '/', substr($assets, strlen(JPATH_ROOT) + 1)) . "/{$file}?v=" . @filemtime("{$assets}/{$file}");
$metadata = app(Metadata::class);

$metadata->set('style:elemen-pricing-pro', ['href' => $assetUrl('pricing-pro.css')]);

$yearlyFirst = ($props['billing_default'] ?? '') === 'yearly';
$switch      = (bool) $props['billing'];

if ($switch) {
    $metadata->set('script:elemen-pricing-pro', ['src' => $assetUrl('pricing-pro.js'), 'defer' => true]);
}

$labels = [
    'monthly'        => $has($props['label_monthly'] ?? '') ? $props['label_monthly'] : Text::_('PLG_SYSTEM_ELEMEN_PRICING_PRO_MONTHLY'),
    'yearly'         => $has($props['label_yearly'] ?? '') ? $props['label_yearly'] : Text::_('PLG_SYSTEM_ELEMEN_PRICING_PRO_YEARLY'),
    'period_monthly' => $has($props['period_monthly'] ?? '') ? $props['period_monthly'] : Text::_('PLG_SYSTEM_ELEMEN_PRICING_PRO_PER_MONTH'),
    'period_yearly'  => $has($props['period_yearly'] ?? '') ? $props['period_yearly'] : Text::_('PLG_SYSTEM_ELEMEN_PRICING_PRO_PER_YEAR'),
    'included'       => Text::_('PLG_SYSTEM_ELEMEN_PRICING_PRO_INCLUDED'),
    'not_included'   => Text::_('PLG_SYSTEM_ELEMEN_PRICING_PRO_NOT_INCLUDED'),
];

[$widths, $split] = ElemenPricingPro::grid($props);

$gap = in_array($props['gap'] ?? '', ['small', 'large'], true) ? $props['gap'] : 'medium';

$el = $this->el('div', [
    'class' => [
        'elemen-pricing-pro pp',
        'pp-yearly' => $yearlyFirst,
        'pp-align-{text_align}',
        'pp-highlight-{highlight_style}',
        "pp-first-{$split}" => $props['featured_first'] && $split !== '' && $split !== 'all',
    ],
]);

$grid = $this->el('div', [
    'class' => ['pp-grid uk-grid uk-grid-match uk-flex-center', "uk-grid-{$gap}", ...$widths],
    'uk-grid' => true,
]);

?>
<?= $el($props, $attrs) ?>

    <?php if ($switch) : ?>
    <div class="pp-billing" role="group" aria-label="<?= htmlspecialchars(Text::_('PLG_SYSTEM_ELEMEN_PRICING_PRO_BILLING')) ?>" hidden>
        <button type="button" class="pp-billing-option" data-period="monthly" aria-pressed="<?= $yearlyFirst ? 'false' : 'true' ?>"><?= $labels['monthly'] ?></button>
        <button type="button" class="pp-billing-option" data-period="yearly" aria-pressed="<?= $yearlyFirst ? 'true' : 'false' ?>"><?= $labels['yearly'] ?><?php if ($has($props['save_badge'] ?? '')) : ?> <span class="pp-save uk-label uk-label-success"><?= $props['save_badge'] ?></span><?php endif ?></button>
    </div>
    <?php endif ?>

    <?= $grid() ?>
        <?php foreach ($plans as $i => $plan) : ?>
        <?= $builder->render($plan, ['element' => $props, 'labels' => $labels, 'index' => $i]) ?>
        <?php endforeach ?>
    <?= $grid->end() ?>

<?= $el->end() ?>
