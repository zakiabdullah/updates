<?php

/**
 * Plain HTML stored in the article text, used by search and when the builder is off.
 *
 * @var \YOOtheme\Builder $builder
 * @var array<string, mixed> $props
 * @var array<int, object> $children
 */

\defined('_JEXEC') or die;

?>
<?php foreach ($children as $child) : ?>
<?= $builder->render($child, ['element' => $props]) ?>
<?php endforeach ?>
