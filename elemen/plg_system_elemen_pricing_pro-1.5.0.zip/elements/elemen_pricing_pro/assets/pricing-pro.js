/**
 * Pricing Pro: the Monthly / Yearly switch. The prices of both periods are in the page; the
 * switch sets a class on the element and aria-pressed on its buttons.
 */
(() => {
    'use strict';

    function init(root) {
        if (root.ppReady) {
            return;
        }

        const billing = root.querySelector('.pp-billing');

        if (!billing) {
            return;
        }

        root.ppReady = true;
        const options = Array.from(billing.querySelectorAll('.pp-billing-option'));

        const select = (period) => {
            root.classList.toggle('pp-yearly', period === 'yearly');
            options.forEach((option) => option.setAttribute('aria-pressed', String(option.dataset.period === period)));
        };

        options.forEach((option) => option.addEventListener('click', () => select(option.dataset.period)));
        billing.hidden = false;
    }

    const start = () => document.querySelectorAll('.elemen-pricing-pro').forEach(init);

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start);
    } else {
        start();
    }

    // Elements added later, e.g. in the builder preview; at most once per frame.
    let queued = false;
    new MutationObserver(() => {
        if (!queued) {
            queued = true;
            requestAnimationFrame(() => {
                queued = false;
                start();
            });
        }
    }).observe(document.documentElement, { childList: true, subtree: true });
})();
