<?php

/**
 * Pricing Pro: prices with the currency, feature lists, and the layout classes.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

final class ElemenPricingPro
{
    /** Number separators: decimal mark and thousands separator. */
    public const SEPARATORS = [
        'comma' => ['.', ','],
        'dot'   => [',', '.'],
        'space' => [',', "\u{202F}"],
        'none'  => ['.', ''],
    ];

    private const BREAKPOINTS = ['grid_small' => 's', 'grid_medium' => 'm', 'grid_large' => 'l'];

    public static function plain(string $value): string
    {
        return trim(html_entity_decode(strip_tags($value), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    }

    /**
     * A number written with either decimal mark, as "1234.5", or null for other text:
     * "1,234.56" and "1.234,56" have both marks, the last is the decimal one; "1,200" and
     * "1.200.000" are thousands; "4,5" is a decimal comma.
     */
    public static function parseNumber(string $text): ?string
    {
        $text = str_replace(["\u{202F}", "\u{A0}", ' ', "'"], '', self::plain($text));

        if (!preg_match('/^[-+]?[\d.,]*\d[\d.,]*$/', $text)) {
            return null;
        }

        $comma = strrpos($text, ',');
        $dot   = strrpos($text, '.');

        if ($comma !== false && $dot !== false) {
            $decimal = $comma > $dot ? ',' : '.';
            $text    = str_replace($decimal === ',' ? '.' : ',', '', $text);
            $text    = str_replace(',', '.', $text);
        } elseif ($comma !== false || $dot !== false) {
            $mark      = $comma !== false ? ',' : '.';
            $parts     = explode($mark, $text);
            $thousands = \count($parts) > 2 || (\strlen(end($parts)) === 3 && \strlen(ltrim($parts[0], '-+')) <= 3 && $mark === ',');
            $text      = $thousands ? str_replace($mark, '', $text) : str_replace(',', '.', $text);
        }

        return is_numeric($text) ? $text : null;
    }

    /**
     * The HTML of a price: the currency, the amount and the period for a number; text such
     * as "Free" as written, without a period.
     *
     * @param  array<string, mixed>  $element  Pricing Pro props.
     */
    public static function price(string $value, string $period, array $element): string
    {
        $number = self::parseNumber($value);

        if ($number === null) {
            return '<span class="pp-amount pp-text">' . $value . '</span>';
        }

        $decimals = trim((string) ($element['decimals'] ?? ''));
        $decimals = $decimals === '' ? (str_contains($number, '.') ? \strlen(substr($number, strpos($number, '.') + 1)) : 0) : max(0, min(4, (int) $decimals));

        [$mark, $thousand] = self::SEPARATORS[$element['separator'] ?? ''] ?? self::SEPARATORS['comma'];

        $before = trim((string) ($element['currency_before'] ?? ''));
        $after  = trim((string) ($element['currency_after'] ?? ''));

        return ($before !== '' ? '<span class="pp-currency">' . htmlspecialchars($before) . '</span>' : '')
            . '<span class="pp-amount">' . number_format((float) $number, $decimals, $mark, $thousand) . '</span>'
            . ($after !== '' ? '<span class="pp-currency pp-currency-after">' . htmlspecialchars($after) . '</span>' : '')
            . ($period !== '' ? '<span class="pp-period">' . $period . '</span>' : '');
    }

    /**
     * Feature lines: [text, included]. A line starting with "x " (or ✗, ✘, -) is not included.
     *
     * @return list<array{0: string, 1: bool}>
     */
    public static function features(string $text): array
    {
        $features = [];

        foreach (preg_split('/\R|<br\s*\/?>/i', $text) ?: [] as $line) {
            $line = trim($line);

            if (self::plain($line) === '') {
                continue;
            }

            if (preg_match('/^(?:x|✗|✘|❌|-)\s+(.+)$/u', $line, $m)) {
                $features[] = [trim($m[1]), false];
            } else {
                $features[] = [preg_replace('/^(?:\+|✓|✔)\s+/u', '', $line), true];
            }
        }

        return $features;
    }

    /**
     * Grid width classes per screen size (each falls back to the one below), and the first
     * screen size with more than one column (highlighted plans come first below it).
     *
     * @param  array<string, mixed>  $props
     *
     * @return array{0: list<string>, 1: string}
     */
    public static function grid(array $props): array
    {
        $last    = max(1, min(6, (int) ($props['grid_default'] ?? 1) ?: 1));
        $classes = ["uk-child-width-1-{$last}"];
        $split   = $last > 1 ? 'all' : '';

        foreach (self::BREAKPOINTS as $key => $bp) {
            $value = (int) ($props[$key] ?? 0);

            if ($value > 0) {
                $last      = max(1, min(6, $value));
                $classes[] = "uk-child-width-1-{$last}@{$bp}";
            }

            if ($split === '' && $last > 1) {
                $split = $bp;
            }
        }

        return [$classes, $split];
    }
}
