<?php

/**
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

namespace Elemen\Plugin\System\PricingPro\Extension;

use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Event\SubscriberInterface;
use YOOtheme\Application;

\defined('_JEXEC') or die;

/**
 * Adds the Elemen Pricing Pro builder element to YOOtheme Pro.
 */
final class PricingPro extends CMSPlugin implements SubscriberInterface
{
    protected $autoloadLanguage = true;

    public static function getSubscribedEvents(): array
    {
        // The YOOtheme system plugin boots its application on onAfterInitialise at
        // high priority; this runs afterwards at normal priority.
        return ['onAfterInitialise' => 'onAfterInitialise'];
    }

    public function onAfterInitialise(): void
    {
        // YOOtheme Pro is not installed or not the active template: nothing to extend.
        if (!class_exists(Application::class, false)) {
            return;
        }

        Application::getInstance()->load(\dirname(__DIR__, 2) . '/bootstrap.php');
    }
}
