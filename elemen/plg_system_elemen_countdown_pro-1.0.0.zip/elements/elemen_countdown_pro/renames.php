<?php

/**
 * Renamed settings of Countdown Pro. Layouts saved with the old names load with the new
 * ones, dynamic content mappings included (see the plugin's bootstrap).
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

return [
    'props'  => [
        'labels'       => 'label_language',
        'pad'          => 'pad_numbers',
        'color'        => 'number_color',
        'color_custom' => 'number_color_custom',
        'separator'    => 'show_separator',
    ],
    'values' => [
        // Malay labels: now the page's language (Malay on Malay pages).
        'label_language' => ['ms' => ''],
    ],
];
