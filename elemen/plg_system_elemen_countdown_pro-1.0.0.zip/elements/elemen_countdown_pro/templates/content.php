<?php

/**
 * Plain HTML stored in the article text, used by search and when the builder is off.
 *
 * @var array<string, mixed> $props
 */

\defined('_JEXEC') or die;

?>
<?php if ($props['mode'] === 'date' && $props['date']) : ?>
<p><?= htmlspecialchars((string) $props['date']) ?></p>
<?php endif ?>
