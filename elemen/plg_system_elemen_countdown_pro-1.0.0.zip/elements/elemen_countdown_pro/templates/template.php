<?php

/**
 * Countdown Pro: counts down to a date, to a time every day, or for a time after the
 * visitor's first visit (evergreen).
 *
 * The page already shows the time left when it was made, so it reads correctly without
 * JavaScript; the script ticks it down, keeps the evergreen deadline in the visitor's
 * browser and acts when the time is up.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 */

use Joomla\CMS\Factory;
use Joomla\CMS\Language\LanguageFactoryInterface;
use Joomla\CMS\Uri\Uri;
use YOOtheme\Metadata;

use function YOOtheme\app;

\defined('_JEXEC') or die;

$app = Factory::getApplication();

try {
    $zone = new DateTimeZone((string) ($app->get('offset') ?: 'UTC'));
} catch (Exception $e) {
    $zone = new DateTimeZone('UTC');
}

$now    = time();
$mode   = in_array($props['mode'], ['daily', 'evergreen'], true) ? $props['mode'] : 'date';
$end    = 0;
$period = 0;
$daily  = [];

if ($mode === 'date') {
    if (!trim((string) $props['date'])) {
        return;
    }

    try {
        $end = (new DateTime((string) $props['date'], $zone))->getTimestamp();
    } catch (Exception $e) {
        return;
    }
} elseif ($mode === 'daily') {
    if (!preg_match('/^(\d{1,2}):(\d{2})$/', trim((string) ($props['daily_time'] ?: '23:59')), $m) || $m[1] > 23 || $m[2] > 59) {
        return;
    }

    $next = (new DateTime('now', $zone))->setTime((int) $m[1], (int) $m[2]);

    if ($next->getTimestamp() <= $now) {
        $next->modify('+1 day');
    }

    $end    = $next->getTimestamp();
    $period = 86400;
    $daily  = ['zone' => $zone->getName(), 'time' => [(int) $m[1], (int) $m[2]]];
} else {
    $period = max(0, (int) $props['evergreen_hours']) * 3600 + max(0, min(59, (int) $props['evergreen_minutes'])) * 60;

    if (!$period) {
        return;
    }

    $end = $now + $period;
}

$left     = max(0, $end - $now);
$finished = $mode === 'date' && !$left;
$finish   = in_array($props['finish'], ['zero', 'hide', 'redirect'], true) ? $props['finish'] : 'message';
$message  = trim((string) $props['finish_message']);

if ($finished && ($finish === 'hide' || ($finish === 'message' && $message === ''))) {
    return;
}

// Units: hidden larger units fold into the next one shown (no days: hours go past 24).
$sizes = ['d' => 86400, 'h' => 3600, 'm' => 60, 's' => 1];
$units = array_keys(array_filter([
    'd' => $props['show_days'],
    'h' => $props['show_hours'],
    'm' => $props['show_minutes'],
    's' => $props['show_seconds'],
])) ?: ['d', 'h', 'm', 's'];

$values = [];
$rest   = $left;

foreach ($units as $unit) {
    $values[$unit] = intdiv($rest, $sizes[$unit]);
    $rest         -= $values[$unit] * $sizes[$unit];
}

// Labels from the plugin's language files, in the page's language or always in English.
$language = $props['label_language'] === 'en' ? 'en-GB' : null;
$language = $language ? Factory::getContainer()->get(LanguageFactoryInterface::class)->createLanguage($language) : $app->getLanguage();
$language->load('plg_system_elemen_countdown_pro', JPATH_ADMINISTRATOR);
$label    = static fn (string $key): string => $language->_('PLG_SYSTEM_ELEMEN_COUNTDOWN_PRO_' . $key);
$labels   = [
    'd' => [$label('DAY'), $label('DAYS')],
    'h' => [$label('HOUR'), $label('HOURS')],
    'm' => [$label('MINUTE'), $label('MINUTES')],
    's' => [$label('SECOND'), $label('SECONDS')],
];

$assets   = \dirname(__DIR__) . '/assets';
$assetUrl = static fn (string $file): string => Uri::root(true) . '/'
    . str_replace('\\', '/', substr($assets, strlen(JPATH_ROOT) + 1)) . "/{$file}?v=" . @filemtime("{$assets}/{$file}");
$metadata = app(Metadata::class);

$metadata->set('style:elemen-countdown-pro', ['href' => $assetUrl('countdown-pro.css')]);
$metadata->set('script:elemen-countdown-pro', ['src' => $assetUrl('countdown-pro.js'), 'defer' => true]);

$color  = static fn ($value): string => preg_match('/^[#(),.%\w\s-]+$/', trim((string) $value)) ? trim((string) $value) : '';
$props['number_color'] = in_array($props['number_color'], ['primary', 'secondary', 'emphasis', 'custom'], true) ? $props['number_color'] : '';
$custom = $props['number_color'] === 'custom' ? $color($props['number_color_custom']) : '';
$style  = in_array($props['style'], ['plain', 'circles', 'flip'], true) ? $props['style'] : 'boxes';
$boxed  = in_array($style, ['boxes', 'flip'], true);
$box    = in_array($props['box_style'], ['default', 'primary', 'secondary'], true) ? $props['box_style'] : 'muted';

$link = '';

if ($finish === 'redirect' && trim((string) $props['finish_link']) !== '') {
    $link = (string) $props['finish_link'];
}

$options = [
    'mode'     => $mode,
    'end'      => $end * 1000,
    'period'   => $period * 1000,
    'key'      => 'elemen-countdown-' . (preg_replace('/[^\w-]+/', '-', trim((string) $props['evergreen_name'])) ?: "{$props['evergreen_hours']}h{$props['evergreen_minutes']}m"),
    'loop'     => (bool) $props['evergreen_loop'],
    'units'    => $units,
    'pad'      => (bool) $props['pad_numbers'],
    'labels'   => $labels,
    'finish'   => $finish,
    'link'     => $link,
] + $daily;

$format = static fn (int $value): string => $props['pad_numbers'] ? str_pad((string) $value, 2, '0', STR_PAD_LEFT) : (string) $value;

// Circles: how full each ring is. Days count against the days left at the start.
$fraction = static fn (string $unit, int $value): float => match ($unit) {
    'd'     => $value ? 1.0 : 0.0,
    'h'     => $units[0] === 'h' ? ($value ? 1.0 : 0.0) : $value / 24,
    'm'     => $units[0] === 'm' ? ($value ? 1.0 : 0.0) : $value / 60,
    default => $units[0] === 's' ? ($value ? 1.0 : 0.0) : $value / 60,
};

$el = $this->el('div', [

    'class' => [
        'elemen-countdown-pro cd',
        "cd-style-{$style}",
        'cd-size-{size}',
        'cd-align-{align}',
        'cd-finished' => $finished,
    ],

    'style'   => $custom ? "--cd-color: {$custom}" : false,
    'data-cd' => json_encode($options),

]);

$numberClass = 'el-number cd-num' . ($props['number_color'] && !$custom ? ' uk-text-' . $props['number_color'] : '');
$unitClass   = 'el-unit cd-unit' . ($boxed ? ($box === 'muted' ? ' cd-box-muted' : " uk-card uk-card-{$box}") : '');
$labelClass  = 'el-label cd-label' . ($props['label_style'] === 'uppercase' ? ' cd-label-upper uk-text-small' : ($props['label_style'] ? ' uk-' . $props['label_style'] : ''));

?>
<?= $el($props, $attrs) ?>

    <?php if (!$finished || $finish !== 'message') : ?>
    <div class="cd-timer" role="timer">
        <?php foreach ($units as $i => $unit) : ?>
        <?php if ($i && $props['show_separator'] && $style !== 'circles') : ?>
        <span class="cd-sep<?= $props['number_color'] && !$custom ? ' uk-text-' . $props['number_color'] : '' ?>" aria-hidden="true">:</span>
        <?php endif ?>
        <div class="<?= $unitClass ?> cd-unit-<?= $unit ?>" data-unit="<?= $unit ?>">
            <?php if ($style === 'circles') : ?>
            <svg class="cd-ring<?= $props['number_color'] && !$custom ? ' uk-text-' . $props['number_color'] : '' ?>" viewBox="0 0 100 100" aria-hidden="true">
                <circle class="cd-ring-track" cx="50" cy="50" r="45" />
                <circle class="cd-ring-bar" cx="50" cy="50" r="45" pathLength="100" style="stroke-dashoffset: <?= round(100 - $fraction($unit, $values[$unit]) * 100, 2) ?>" />
            </svg>
            <?php endif ?>
            <span class="<?= $numberClass ?>"><?= $format($values[$unit]) ?></span>
            <?php if ($props['show_labels']) : ?>
            <span class="<?= $labelClass ?>"><?= $labels[$unit][$values[$unit] === 1 ? 0 : 1] ?></span>
            <?php else : ?>
            <span class="cd-label uk-hidden-visually"><?= $labels[$unit][1] ?></span>
            <?php endif ?>
        </div>
        <?php endforeach ?>
    </div>
    <?php endif ?>

    <?php if ($finish === 'message' && $message !== '') : ?>
    <div class="el-message cd-message uk-panel"<?= $finished ? '' : ' hidden' ?>><?= $message ?></div>
    <?php endif ?>

<?= $el->end() ?>
