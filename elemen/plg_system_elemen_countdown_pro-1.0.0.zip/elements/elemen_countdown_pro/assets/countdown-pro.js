/* Elemen: Countdown Pro — ticks the countdown, keeps evergreen deadlines and acts when
   time is up. No dependencies. */
(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const sizes = { d: 86400, h: 3600, m: 60, s: 1 };

    const storage = {
        get(key) {
            try {
                return Number(window.localStorage.getItem(key)) || 0;
            } catch (e) {
                return 0;
            }
        },
        set(key, value) {
            try {
                window.localStorage.setItem(key, String(value));
            } catch (e) {
                // private mode: the deadline lasts for this page view only
            }
        },
    };

    /* Every day: the next time of day in the site's time zone after a moment. Days are not
       always 24 hours long (daylight saving time), so it is worked out from the clock in
       that zone. Without time zone support it falls back to whole days. */
    function zoneOffset(time, zone) {
        const parts = {};

        new Intl.DateTimeFormat('en-US', {
            timeZone: zone, hourCycle: 'h23', year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric',
        }).formatToParts(new Date(time)).forEach(({ type, value }) => {
            parts[type] = Number(value);
        });

        return Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour % 24, parts.minute, parts.second) - Math.floor(time / 1000) * 1000;
    }

    function nextDaily(o, after) {
        try {
            const today = new Date(after + zoneOffset(after, o.zone));

            for (let day = 0; day < 3; day++) {
                const wall = Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate() + day, o.time[0], o.time[1]);
                // The offsets before and after a clock change that day: the earlier time that
                // reads as the wanted time, or the later one if the clock skips it.
                const times = [wall - zoneOffset(wall - 43200000, o.zone), wall - zoneOffset(wall + 43200000, o.zone)].sort((x, y) => x - y);
                const time = times.find((t) => t + zoneOffset(t, o.zone) === wall) || times[1];

                if (time > after) {
                    return time;
                }
            }
        } catch (e) {
            // No time zone support: whole days below.
        }

        let end = Number(o.end) || after;

        while (end <= after) {
            end += o.period;
        }

        return end;
    }

    function setup(cd) {
        cd.setAttribute('data-cd-ready', '');

        let o = {};

        try {
            o = JSON.parse(cd.getAttribute('data-cd') || '{}');
        } catch (e) {
            return;
        }

        const units = (o.units || []).filter((unit) => sizes[unit]);
        const timer = cd.querySelector(':scope > .cd-timer');
        const message = cd.querySelector(':scope > .cd-message');
        const nodes = {};
        let end = Number(o.end) || 0;
        let first = 0;
        let done = false;
        let shown = false; // no flip on the first update

        if (!units.length) {
            return;
        }

        (timer ? [...timer.querySelectorAll(':scope > .cd-unit')] : []).forEach((unit) => {
            nodes[unit.getAttribute('data-unit')] = {
                num: unit.querySelector('.cd-num'),
                label: unit.querySelector('.cd-label:not(.uk-hidden-visually)'),
                bar: unit.querySelector('.cd-ring-bar'),
            };
        });

        // Evergreen: the deadline is set on the first visit and kept in the browser.
        if (o.mode === 'evergreen') {
            end = storage.get(o.key);

            if (!end || (end <= Date.now() && o.loop)) {
                end = Date.now() + o.period;
                storage.set(o.key, end);
            }
        }

        // Every day: move to the next occurrence if the page was made before it passed.
        if (o.mode === 'daily' && o.period && end <= Date.now()) {
            end = nextDaily(o, Date.now());
        }

        const format = (value) => (o.pad && value < 10 ? `0${value}` : String(value));

        function finish() {
            done = true;
            cd.classList.add('cd-finished');

            if (o.finish === 'hide') {
                cd.hidden = true;
            } else if (o.finish === 'message' && message) {
                if (timer) {
                    timer.hidden = true;
                }

                message.hidden = false;
            } else if (o.finish === 'redirect' && o.link && window.self === window.top) {
                // Not inside the builder preview (an iframe).
                window.location.href = o.link;
            }
        }

        function render(left) {
            let rest = left;

            units.forEach((unit, i) => {
                const value = Math.floor(rest / sizes[unit]);
                const node = nodes[unit];
                rest -= value * sizes[unit];

                if (!node || !node.num) {
                    return;
                }

                const text = format(value);

                if (node.num.textContent !== text) {
                    node.num.textContent = text;

                    if (shown && !reduce && cd.classList.contains('cd-style-flip') && node.num.animate) {
                        node.num.animate([{ transform: 'rotateX(-90deg)', opacity: 0.2 }, { transform: 'none', opacity: 1 }], { duration: 380, easing: 'ease-out' });
                    }
                }

                if (node.label && o.labels && o.labels[unit]) {
                    node.label.textContent = o.labels[unit][value === 1 ? 0 : 1];
                }

                if (node.bar) {
                    // The first unit has no unit above it: count against its value at the start.
                    let full = unit === 'h' ? 24 : 60;

                    if (i === 0) {
                        first = first || Math.max(1, value);
                        full = first;
                    }

                    node.bar.style.strokeDashoffset = String(100 - Math.min(1, value / full) * 100);
                }
            });

            shown = true;
        }

        function tick() {
            if (done || !cd.isConnected) {
                return;
            }

            let left = Math.max(0, Math.ceil((end - Date.now()) / 1000));

            if (!left) {
                if (o.mode === 'daily' && o.period) {
                    end = nextDaily(o, Math.max(end, Date.now()));
                    left = Math.ceil((end - Date.now()) / 1000);
                } else if (o.mode === 'evergreen' && o.loop) {
                    end = Date.now() + o.period;
                    storage.set(o.key, end);
                    left = Math.ceil(o.period / 1000);
                } else {
                    render(0);
                    finish();
                    return;
                }
            }

            render(left);
            setTimeout(tick, 1000 - (Date.now() % 1000) + 20);
        }

        tick();
    }

    const init = (root) => root.querySelectorAll('.elemen-countdown-pro:not([data-cd-ready])').forEach(setup);

    const boot = () => {
        init(document);

        // The YOOtheme builder preview (an iframe) replaces elements while editing.
        if (window.self !== window.top) {
            new MutationObserver(() => init(document)).observe(document.body, { childList: true, subtree: true });
        }
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
