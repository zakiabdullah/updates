<?php

/**
 * Package installer script for Elemen (copied into the package as script.php).
 *
 * Sites with the package get their updates from package.xml, which lists only the
 * package, so Joomla's update list shows one "Elemen" row. The plugins inside the package
 * register no update server of their own. Joomla matches every entry of every update
 * server it knows to the installed extensions, and only ever adds servers, so the shared
 * updates.xml (registered by earlier packages or by single plugin zips, and listing every
 * plugin) is removed here; otherwise each changed plugin would show a row of its own next
 * to the package. Sites with single plugin zips and no package keep updates.xml.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\Database\DatabaseInterface;
use Joomla\Database\ParameterType;

return new class () implements InstallerScriptInterface {
    public function install(InstallerAdapter $adapter): bool
    {
        return true;
    }

    public function update(InstallerAdapter $adapter): bool
    {
        return true;
    }

    public function uninstall(InstallerAdapter $adapter): bool
    {
        return true;
    }

    public function preflight(string $type, InstallerAdapter $adapter): bool
    {
        return true;
    }

    public function postflight(string $type, InstallerAdapter $adapter): bool
    {
        if (!in_array($type, ['install', 'update', 'discover_install'], true)) {
            return true;
        }

        // Joomla registers package.xml after this script runs, from the package manifest.
        $db  = Factory::getContainer()->get(DatabaseInterface::class);
        $ids = $db->setQuery(
            $db->createQuery()
                ->select($db->quoteName('update_site_id'))
                ->from($db->quoteName('#__update_sites'))
                ->where($db->quoteName('location') . ' LIKE ' . $db->quote('%/elemen/updates.xml'))
        )->loadColumn();

        $ids = array_map('intval', $ids);

        if (!$ids) {
            return true;
        }

        foreach (['#__updates', '#__update_sites_extensions', '#__update_sites'] as $table) {
            $db->setQuery(
                $db->createQuery()
                    ->delete($db->quoteName($table))
                    ->whereIn($db->quoteName('update_site_id'), $ids, ParameterType::INTEGER)
            )->execute();
        }

        return true;
    }
};
