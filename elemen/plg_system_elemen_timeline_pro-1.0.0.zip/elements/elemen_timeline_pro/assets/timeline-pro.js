/* Elemen: Timeline Pro — line fill while scrolling and items that appear. No dependencies. */
(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const timelines = new Set();

    const reveal = 'IntersectionObserver' in window
        ? new IntersectionObserver((entries) => {
            entries.forEach(({ target, isIntersecting }) => {
                if (isIntersecting) {
                    target.classList.add('is-visible');
                    reveal.unobserve(target);
                }
            });
        }, { threshold: 0.2, rootMargin: '0px 0px -10% 0px' })
        : null;

    // The fill runs from the first marker to the point 60% down the screen.
    function update(tl) {
        const markers = [...tl.querySelectorAll(':scope > .tl-item > .tl-marker')];
        const progress = tl.querySelector(':scope > .tl-progress');

        if (!markers.length || !progress) {
            return;
        }

        const box = tl.getBoundingClientRect();
        const centre = (marker) => {
            const rect = marker.getBoundingClientRect();
            return rect.top + rect.height / 2 - box.top;
        };
        const first = centre(markers[0]);
        const last = centre(markers[markers.length - 1]);
        const point = window.innerHeight * 0.6 - box.top;
        const end = Math.max(first, Math.min(last, point));

        progress.style.top = `${first}px`;
        progress.style.height = `${end - first}px`;

        markers.forEach((marker) => marker.classList.toggle('is-active', centre(marker) <= point));
    }

    let frame = 0;
    const schedule = () => {
        cancelAnimationFrame(frame);
        frame = requestAnimationFrame(() => timelines.forEach((tl) => (tl.isConnected ? update(tl) : timelines.delete(tl))));
    };

    // Horizontal layout: previous/next buttons scroll by one item and hide when everything fits.
    function navigation(tl) {
        const scroller = tl.querySelector(':scope > .tl-scroller');
        const nav = tl.querySelector(':scope > .tl-nav');

        if (!scroller || !nav) {
            return;
        }

        const rtl = getComputedStyle(tl).direction === 'rtl';
        const step = () => (scroller.querySelector('.tl-item')?.offsetWidth || 300) + parseFloat(getComputedStyle(scroller).columnGap || 0);
        const update = () => {
            const max = scroller.scrollWidth - scroller.clientWidth;
            const pos = Math.abs(scroller.scrollLeft);

            nav.hidden = max < 2;
            nav.querySelector('.tl-nav-prev').classList.toggle('uk-invisible', pos < 2);
            nav.querySelector('.tl-nav-next').classList.toggle('uk-invisible', pos > max - 2);
        };

        nav.addEventListener('click', (event) => {
            const button = event.target.closest('.tl-nav-prev, .tl-nav-next');

            if (button) {
                event.preventDefault();
                const forward = button.classList.contains('tl-nav-next') ? 1 : -1;
                scroller.scrollBy({ left: forward * (rtl ? -1 : 1) * step(), behavior: reduce ? 'auto' : 'smooth' });
            }
        });

        scroller.addEventListener('scroll', update, { passive: true });
        window.addEventListener('resize', update);
        update();
    }

    function init(root) {
        root.querySelectorAll('.elemen-timeline-pro:not([data-tl-ready])').forEach((tl) => {
            tl.setAttribute('data-tl-ready', '');

            if (tl.classList.contains('tl-reveal')) {
                tl.querySelectorAll(':scope > .tl-item, :scope > .tl-scroller > .tl-item').forEach((item) => {
                    if (reveal && !reduce) {
                        reveal.observe(item);
                    } else {
                        item.classList.add('is-visible');
                    }
                });
            }

            if (tl.classList.contains('tl-layout-horizontal')) {
                navigation(tl);
            }

            if (tl.classList.contains('tl-has-progress')) {
                timelines.add(tl);
            }
        });

        schedule();
    }

    const boot = () => {
        init(document);
        window.addEventListener('scroll', schedule, { passive: true });
        window.addEventListener('resize', schedule);

        // The YOOtheme builder preview replaces elements while editing.
        new MutationObserver(() => init(document)).observe(document.body, { childList: true, subtree: true });
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
