<?php

/**
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

use Elemen\Plugin\System\TablePro\Extension\TablePro;
use Joomla\CMS\Extension\PluginInterface;
use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(
            PluginInterface::class,
            function (Container $container) {
                $plugin = new TablePro((array) PluginHelper::getPlugin('system', 'elemen_table_pro'));
                $plugin->setApplication(Factory::getApplication());

                return $plugin;
            }
        );
    }
};
