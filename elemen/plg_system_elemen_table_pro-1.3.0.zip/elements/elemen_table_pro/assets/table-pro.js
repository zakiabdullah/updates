/**
 * Table Pro: search with highlights, sorting, filter dropdowns and pages, in the browser.
 *
 * The page carries everything: options in data-tp on the element; on every cell data-col,
 * and data-sort / data-filter (a JSON list) where the column sorts or filters. Rows are
 * shown or hidden and put in order; nothing is loaded from the server.
 */
(() => {
    'use strict';

    // Lower case, and without accents when asked: "Café" and "cafe" are the same.
    const fold = (text, diacritics) => {
        const lower = String(text).toLocaleLowerCase();

        return diacritics ? lower.normalize('NFD').replace(/[̀-ͯ]/g, '') : lower;
    };

    const cellOf = (row, col) => row.querySelector(`td[data-col="${col}"]`);

    const filterValues = (td) => {
        try {
            return JSON.parse(td?.dataset.filter || '[]');
        } catch {
            return [];
        }
    };

    function unmark(root) {
        root.querySelectorAll('mark.tp-mark').forEach((mark) => {
            const parent = mark.parentNode;
            mark.replaceWith(document.createTextNode(mark.textContent));
            parent.normalize();
        });
    }

    // Wrap the parts of a cell's text that match the search terms in <mark>.
    function markCell(td, terms, diacritics) {
        const walker = document.createTreeWalker(td, NodeFilter.SHOW_TEXT, {
            acceptNode: (node) => (node.parentElement.closest('svg, script, style') ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT),
        });
        const nodes = [];

        while (walker.nextNode()) {
            nodes.push(walker.currentNode);
        }

        nodes.forEach((node) => {
            const chars = Array.from(node.data);
            const start = [];
            let folded = '';
            let offset = 0;
            const map = [];

            chars.forEach((char, i) => {
                start[i] = offset;
                offset += char.length;
                const f = fold(char, diacritics);

                for (let j = 0; j < f.length; j++) {
                    map.push(i);
                }

                folded += f;
            });

            start[chars.length] = offset;

            // Matches as [from, to) in UTF-16 offsets of the node, merged when they overlap.
            const ranges = [];

            terms.forEach((term) => {
                let at = folded.indexOf(term);

                while (at !== -1) {
                    ranges.push([start[map[at]], start[map[at + term.length - 1] + 1]]);
                    at = folded.indexOf(term, at + term.length);
                }
            });

            if (!ranges.length) {
                return;
            }

            ranges.sort((a, b) => a[0] - b[0]);
            const merged = [ranges[0]];

            ranges.slice(1).forEach(([from, to]) => {
                const last = merged[merged.length - 1];

                if (from <= last[1]) {
                    last[1] = Math.max(last[1], to);
                } else {
                    merged.push([from, to]);
                }
            });

            // From the end, so earlier offsets stay valid.
            merged.reverse().forEach(([from, to]) => {
                const match = node.splitText(from);
                match.splitText(to - from);
                const mark = document.createElement('mark');
                mark.className = 'tp-mark';
                match.replaceWith(mark);
                mark.append(match);
            });
        });
    }

    function init(root) {
        if (root.tpReady) {
            return;
        }

        root.tpReady = true;

        let options;

        try {
            options = JSON.parse(root.dataset.tp || '{}');
        } catch {
            options = {};
        }

        const tbody = root.querySelector('tbody');

        if (!tbody) {
            return;
        }

        const diacritics = options.diacritics !== false;
        const labels = options.labels || {};
        const rows = Array.from(tbody.rows);
        const input = root.querySelector('.tp-search-input');
        const selects = Array.from(root.querySelectorAll('.tp-filter'));
        const buttons = Array.from(root.querySelectorAll('.tp-sort'));
        const empty = root.querySelector('.tp-empty');
        const nav = root.querySelector('.tp-pages');
        const toolbar = root.querySelector('.tp-toolbar');
        let sort = options.sort || null;
        let page = 1;

        rows.forEach((row, i) => {
            row.tpIndex = i;
            row.tpText = fold(Array.from(row.cells).filter((td) => !td.classList.contains('tp-count')).map((td) => td.textContent).join(' '), diacritics);
        });

        // Filter choices: every value in the column, once, in order.
        selects.forEach((select) => {
            const values = new Map();

            rows.forEach((row) => filterValues(cellOf(row, select.dataset.col)).forEach((value) => {
                const key = fold(value, diacritics);

                if (!values.has(key)) {
                    values.set(key, value);
                }
            }));

            const rating = select.dataset.type === 'rating';
            const entries = Array.from(values.entries()).sort((a, b) => (rating
                ? parseFloat(b[1]) - parseFloat(a[1])
                : a[1].localeCompare(b[1], undefined, { numeric: true, sensitivity: 'base' })));

            entries.forEach(([key, label]) => {
                const option = document.createElement('option');
                option.value = key;
                option.textContent = rating ? `${label} ★` : label;
                select.append(option);
            });

            select.addEventListener('change', () => {
                page = 1;
                update();
            });
        });

        const compare = (a, b) => {
            const button = buttons.find((btn) => btn.dataset.col === String(sort.col));
            const numeric = button?.dataset.type === 'number';
            const x = cellOf(a, sort.col)?.dataset.sort ?? '';
            const y = cellOf(b, sort.col)?.dataset.sort ?? '';
            let result;

            // Empty cells last, whichever the direction.
            if (x === '' || y === '') {
                result = x === y ? 0 : (x === '' ? 1 : -1);

                return result || a.tpIndex - b.tpIndex;
            }

            result = numeric
                ? parseFloat(x) - parseFloat(y)
                : fold(x, diacritics).localeCompare(fold(y, diacritics), undefined, { numeric: true, sensitivity: 'base' });

            return (sort.dir === 'desc' ? -result : result) || a.tpIndex - b.tpIndex;
        };

        function applySort() {
            const ordered = sort ? [...rows].sort(compare) : [...rows].sort((a, b) => a.tpIndex - b.tpIndex);
            ordered.forEach((row) => tbody.append(row));

            buttons.forEach((button) => {
                const active = sort && button.dataset.col === String(sort.col);
                button.closest('th').setAttribute('aria-sort', active ? (sort.dir === 'desc' ? 'descending' : 'ascending') : 'none');
                button.classList.toggle('tp-sort-asc', Boolean(active && sort.dir !== 'desc'));
                button.classList.toggle('tp-sort-desc', Boolean(active && sort.dir === 'desc'));
            });

            return ordered;
        }

        function pagination(pages) {
            const list = nav.querySelector('.uk-pagination');
            const item = (content, attrs = {}, cls = '') => {
                const li = document.createElement('li');

                if (cls) {
                    li.className = cls;
                }

                const el = document.createElement(attrs.page ? 'a' : 'span');

                if (attrs.page) {
                    el.href = '#';
                    el.dataset.page = attrs.page;
                }

                if (attrs.label) {
                    el.setAttribute('aria-label', attrs.label);
                }

                if (attrs.current) {
                    el.setAttribute('aria-current', 'page');
                }

                el.innerHTML = content;
                li.append(el);

                return li;
            };

            list.textContent = '';
            list.append(item('<span uk-pagination-previous></span>', page > 1 ? { page: page - 1, label: labels.previous } : { label: labels.previous }, page > 1 ? '' : 'uk-disabled'));

            let last = 0;

            for (let n = 1; n <= pages; n++) {
                if (n === 1 || n === pages || Math.abs(n - page) <= 1) {
                    if (last && n - last > 1) {
                        list.append(item('…', {}, 'uk-disabled'));
                    }

                    list.append(n === page
                        ? item(String(n), { current: true }, 'uk-active')
                        : item(String(n), { page: n, label: (labels.page || '%s').replace('%s', n) }));
                    last = n;
                }
            }

            list.append(item('<span uk-pagination-next></span>', page < pages ? { page: page + 1, label: labels.next } : { label: labels.next }, page < pages ? '' : 'uk-disabled'));
        }

        function update() {
            const ordered = applySort();
            const terms = input ? fold(input.value.trim(), diacritics).split(/\s+/).filter(Boolean) : [];
            const active = selects.filter((select) => select.value).map((select) => [select.dataset.col, select.value]);

            const shown = ordered.filter((row) => terms.every((term) => row.tpText.includes(term))
                && active.every(([col, value]) => filterValues(cellOf(row, col)).some((v) => fold(v, diacritics) === value)));

            const perPage = options.perPage || 0;
            const pages = perPage ? Math.max(1, Math.ceil(shown.length / perPage)) : 1;
            page = Math.min(Math.max(1, page), pages);

            const visible = new Set(perPage ? shown.slice((page - 1) * perPage, page * perPage) : shown);

            rows.forEach((row) => {
                row.hidden = !visible.has(row);
            });

            if (options.highlight) {
                unmark(tbody);

                if (terms.length) {
                    visible.forEach((row) => Array.from(row.cells)
                        .filter((td) => !td.classList.contains('tp-count'))
                        .forEach((td) => markCell(td, terms, diacritics)));
                }
            }

            if (empty) {
                empty.hidden = shown.length > 0;
            }

            if (nav) {
                nav.hidden = shown.length <= perPage;

                if (!nav.hidden) {
                    const first = (page - 1) * perPage + 1;
                    const lastRow = Math.min(page * perPage, shown.length);
                    nav.querySelector('.tp-status').textContent = (labels.status || '%1–%2 / %3')
                        .replace('%1', first).replace('%2', lastRow).replace('%3', shown.length);
                    pagination(pages);
                }
            }
        }

        if (toolbar) {
            toolbar.hidden = false;
        }

        if (input) {
            let timer;
            input.addEventListener('input', () => {
                clearTimeout(timer);
                timer = setTimeout(() => {
                    page = 1;
                    update();
                }, 150);
            });
        }

        buttons.forEach((button) => button.addEventListener('click', () => {
            const col = Number(button.dataset.col);
            sort = sort && sort.col === col ? { col, dir: sort.dir === 'asc' ? 'desc' : 'asc' } : { col, dir: 'asc' };
            page = 1;
            update();
        }));

        nav?.addEventListener('click', (event) => {
            const link = event.target.closest('a[data-page]');

            if (!link) {
                return;
            }

            event.preventDefault();
            page = Number(link.dataset.page);
            update();
            root.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
        });

        update();
    }

    const start = () => document.querySelectorAll('.elemen-table-pro[data-tp]').forEach(init);

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start);
    } else {
        start();
    }

    // Tables added later, e.g. in the builder preview; at most once per frame.
    let queued = false;
    new MutationObserver(() => {
        if (!queued) {
            queued = true;
            requestAnimationFrame(() => {
                queued = false;
                start();
            });
        }
    }).observe(document.documentElement, { childList: true, subtree: true });
})();
