<?php

/**
 * Table Pro: the Columns tab and the row cells are made here, one set per column, rather
 * than written out 24 times in element.json.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

require_once __DIR__ . '/ElemenTablePro.php';

return [
    // Default priority: multilingual plugins add their per-language fields after this.
    'builder.type' => static fn (array $type): array => ElemenTablePro::addFields($type),
];
