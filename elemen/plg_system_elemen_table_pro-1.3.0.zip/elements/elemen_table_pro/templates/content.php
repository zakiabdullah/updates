<?php

/**
 * Plain HTML stored in the article text, used by search and when the builder is off.
 *
 * @var array<string, mixed> $props
 * @var array<int, object> $children
 * @var \YOOtheme\Builder $builder
 */

\defined('_JEXEC') or die;

require_once \dirname(__DIR__) . '/ElemenTablePro.php';

$columns = ElemenTablePro::columns($props);

?>
<table>
    <?php if ($props['show_header']) : ?>
    <thead>
        <tr>
            <?php foreach ($columns as $column) : ?>
            <th><?= $column['label'] ?></th>
            <?php endforeach ?>
        </tr>
    </thead>
    <?php endif ?>
    <tbody>
        <?php foreach ($children as $child) : ?>
        <?= $builder->render($child, ['element' => $props, 'columns' => $columns]) ?>
        <?php endforeach ?>
    </tbody>
</table>
