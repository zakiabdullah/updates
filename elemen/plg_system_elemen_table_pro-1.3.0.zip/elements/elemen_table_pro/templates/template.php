<?php

/**
 * Table Pro: a table with up to 24 columns. Each column has a type (text, number, date,
 * image, icon, rating, yes / no, button or tags); each row is an item.
 *
 * On small screens the table scrolls sideways, or shows every row as a card with the
 * column names (the cells carry them in data-label).
 *
 * Search, sorting, filters and pages run in the browser (table-pro.js, loaded only when
 * one of them is on). Cells carry what the script needs: data-col, data-sort and
 * data-filter. Without the script every row shows and the controls stay hidden.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var \YOOtheme\Builder $builder
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<int, object> $children
 */

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;
use YOOtheme\Metadata;

use function YOOtheme\app;

\defined('_JEXEC') or die;

require_once \dirname(__DIR__) . '/ElemenTablePro.php';

$columns = ElemenTablePro::columns($props);

// Rows with at least one cell in a column in use.
$rows = array_values(array_filter($children, static function (object $child) use ($columns): bool {
    $p = (array) ($child->props ?? []);

    foreach ($columns as $column) {
        if (trim((string) ($p['cell_' . $column['index']] ?? '')) !== '') {
            return true;
        }
    }

    return false;
}));

if (!$rows) {
    return;
}

Factory::getApplication()->getLanguage()->load('plg_system_elemen_table_pro', JPATH_ADMINISTRATOR);

$assets   = \dirname(__DIR__) . '/assets';
$assetUrl = static fn (string $file): string => Uri::root(true) . '/'
    . str_replace('\\', '/', substr($assets, strlen(JPATH_ROOT) + 1)) . "/{$file}?v=" . @filemtime("{$assets}/{$file}");
$metadata = app(Metadata::class);

$metadata->set('style:elemen-table-pro', ['href' => $assetUrl('table-pro.css')]);

$has        = static fn ($value): bool => trim((string) $value) !== '';
$responsive = in_array($props['responsive'], ['stack', 'none'], true) ? $props['responsive'] : 'scroll';
$stackAt    = in_array($props['stack_breakpoint'], ['s', 'm', 'l'], true) ? $props['stack_breakpoint'] : 'm';
$sticky     = $props['show_header'] && $props['sticky_header'];
$images     = $props['lightbox'] && in_array('image', array_column($columns, 'type'), true);
$counting   = (bool) $props['counting'];
$countClass = in_array($props['counting_visible'], ['s', 'm', 'l', 'xl'], true) ? ' uk-visible@' . $props['counting_visible'] : '';
$headStyle  = in_array($props['header_style'], ['muted', 'primary', 'secondary'], true) ? $props['header_style'] : '';
$headBg     = $headStyle ? " uk-background-{$headStyle}" : '';

// Interactive table
$search   = (bool) ($props['search'] ?? false);
$filters  = array_values(array_filter($columns, static fn (array $column): bool => $column['filter']));
$sortable = $props['show_header'] && array_filter($columns, static fn (array $column): bool => $column['sort']);
$perPage  = max(0, (int) ($props['per_page'] ?? 0));
$paged    = $perPage > 0 && count($rows) > $perPage;
$script   = $search || $filters || $sortable || $paged;

$labels = [
    'search' => $has($props['label_search'] ?? '') ? $props['label_search'] : Text::_('PLG_SYSTEM_ELEMEN_TABLE_PRO_SEARCH'),
    'all'    => $has($props['label_all'] ?? '') ? $props['label_all'] : Text::_('PLG_SYSTEM_ELEMEN_TABLE_PRO_ALL'),
    'empty'  => $has($props['label_empty'] ?? '') ? $props['label_empty'] : Text::_('PLG_SYSTEM_ELEMEN_TABLE_PRO_NO_RESULTS'),
];

if ($script) {
    $metadata->set('script:elemen-table-pro', ['src' => $assetUrl('table-pro.js'), 'defer' => true]);
}

$sortColumn = (int) ($props['sort_column'] ?? 0);
$options    = [
    'search'     => $search,
    'highlight'  => $search && ($props['search_highlight'] ?? true),
    'diacritics' => (bool) ($props['diacritics'] ?? true),
    'perPage'    => $paged ? $perPage : 0,
    'sort'       => $sortable && $sortColumn && array_filter($columns, static fn (array $c): bool => $c['index'] === $sortColumn && $c['sort'])
        ? ['col' => $sortColumn, 'dir' => ($props['sort_direction'] ?? '') === 'desc' ? 'desc' : 'asc']
        : null,
    'labels' => [
        'status'   => Text::_('PLG_SYSTEM_ELEMEN_TABLE_PRO_STATUS'),
        'previous' => Text::_('PLG_SYSTEM_ELEMEN_TABLE_PRO_PREVIOUS'),
        'next'     => Text::_('PLG_SYSTEM_ELEMEN_TABLE_PRO_NEXT'),
        'page'     => Text::_('PLG_SYSTEM_ELEMEN_TABLE_PRO_PAGE'),
    ],
];

$table = $this->el('table', [
    'class' => [
        'el-table tp-table uk-table',
        'uk-table-divider {@table_divider}',
        'uk-table-striped {@table_striped}',
        'uk-table-hover {@table_hover}',
        'uk-table-middle {@table_middle}',
        'uk-table-{table_size}',
    ],
]);

$box = $this->el('div', [
    'class' => [
        'tp-box',
        'tp-scroll' => $responsive === 'scroll' || $sticky,
        'tp-sticky' => $sticky,
    ],
    'style' => $sticky ? '--tp-height: ' . max(150, (int) ($props['table_height'] ?: 600)) . 'px' : false,
]);

$el = $this->el('div', [
    'class' => [
        'elemen-table-pro tp',
        "tp-stack tp-stack-{$stackAt}" => $responsive === 'stack',
    ],
    'data-tp'     => $script ? json_encode($options) : false,
    'uk-lightbox' => $images ? 'toggle: a.tp-lightbox' : false,
]);

$align = in_array($props['toolbar_align'] ?? '', ['center', 'right'], true) ? $props['toolbar_align'] : 'left';

?>
<?= $el($props, $attrs) ?>

    <?php if ($search || $filters) : ?>
    <div class="tp-toolbar tp-align-<?= $align ?>" hidden>
        <?php if ($search) : ?>
        <div class="tp-search uk-inline">
            <span class="uk-form-icon" uk-icon="icon: search"></span>
            <input class="uk-input tp-search-input" type="search" placeholder="<?= htmlspecialchars(strip_tags((string) $labels['search'])) ?>" aria-label="<?= htmlspecialchars(strip_tags((string) $labels['search'])) ?>">
        </div>
        <?php endif ?>
        <?php foreach ($filters as $column) : ?>
        <?php $name = ElemenTablePro::plain($column['label']) ?: Text::sprintf('PLG_SYSTEM_ELEMEN_TABLE_PRO_COLUMN', $column['index']) ?>
        <select class="uk-select tp-filter" data-col="<?= $column['index'] ?>" data-type="<?= $column['type'] ?>" aria-label="<?= htmlspecialchars(Text::sprintf('PLG_SYSTEM_ELEMEN_TABLE_PRO_FILTER', $name)) ?>">
            <option value=""><?= htmlspecialchars(strip_tags((string) $labels['all'])) ?>: <?= htmlspecialchars($name) ?></option>
        </select>
        <?php endforeach ?>
    </div>
    <?php endif ?>

    <?= $box() ?>
        <?= $table($props) ?>
            <?php if ($has($props['caption'])) : ?>
            <caption class="uk-hidden-visually"><?= $props['caption'] ?></caption>
            <?php endif ?>
            <?php if ($props['show_header']) : ?>
            <thead<?= in_array($headStyle, ['primary', 'secondary'], true) ? ' class="uk-light"' : '' ?>>
                <tr>
                    <?php if ($counting) : ?>
                    <th class="tp-count uk-table-shrink<?= $countClass ?><?= $headBg ?>" scope="col"><?= $props['counting_label'] ?></th>
                    <?php endif ?>
                    <?php foreach ($columns as $column) : ?>
                    <?php $class = trim(implode(' ', [...ElemenTablePro::columnClasses($column), ElemenTablePro::widthClass($column), trim($headBg)])) ?>
                    <?php
                    $heading = $column['sort']
                        ? '<button type="button" class="tp-sort" data-col="' . $column['index'] . '" data-type="' . (in_array($column['type'], ['number', 'rating', 'check'], true) ? 'number' : 'text') . '">'
                            . ($column['label'] ?: Text::sprintf('PLG_SYSTEM_ELEMEN_TABLE_PRO_COLUMN', $column['index'])) . '<span class="tp-sort-icon" aria-hidden="true"></span></button>'
                        : $column['label'];
                    ?>
                    <th scope="col"<?= $class !== '' ? ' class="' . $class . '"' : '' ?><?= $column['sort'] ? ' aria-sort="none"' : '' ?>><?= $heading ?></th>
                    <?php endforeach ?>
                </tr>
            </thead>
            <?php endif ?>
            <tbody>
                <?php foreach ($rows as $i => $row) : ?>
                <?= $builder->render($row, ['element' => $props, 'columns' => $columns, 'number' => $i + 1, 'countClass' => $countClass]) ?>
                <?php endforeach ?>
            </tbody>
        <?= $table->end() ?>
    <?= $box->end() ?>

    <?php if ($search || $filters) : ?>
    <p class="tp-empty uk-text-muted uk-text-center uk-margin-small-top" hidden><?= $labels['empty'] ?></p>
    <?php endif ?>

    <?php if ($paged) : ?>
    <nav class="tp-pages uk-margin-small-top" aria-label="<?= htmlspecialchars(Text::_('PLG_SYSTEM_ELEMEN_TABLE_PRO_PAGES')) ?>" hidden>
        <p class="tp-status uk-text-meta uk-margin-remove" aria-live="polite"></p>
        <ul class="uk-pagination uk-margin-remove"></ul>
    </nav>
    <?php endif ?>

<?= $el->end() ?>
