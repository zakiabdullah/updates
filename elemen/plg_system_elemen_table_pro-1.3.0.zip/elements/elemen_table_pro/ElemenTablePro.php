<?php

/**
 * Table Pro: the column settings, the row fields, and how each kind of cell is shown.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

\defined('_JEXEC') or die;

final class ElemenTablePro
{
    /** Columns a table can have. */
    public const MAX = 24;

    public const TYPES = [
        'Text'      => '',
        'Number'    => 'number',
        'Date'      => 'date',
        'Image'     => 'image',
        'Icon'      => 'icon',
        'Rating'    => 'rating',
        'Yes / No'  => 'check',
        'Button'    => 'button',
        'Tags'      => 'tags',
    ];

    /** Date formats: label => PHP date format, "lang:KEY" for the site language's own, or "relative". */
    public const DATE_FORMATS = [
        '24 November 2026'           => 'j F Y',
        '24 Nov 2026'                => 'j M Y',
        'Tuesday, 24 November 2026'  => 'l, j F Y',
        'November 2026'              => 'F Y',
        '24 November'                => 'j F',
        '2026'                       => 'Y',
        '24/11/2026'                 => 'd/m/Y',
        '24.11.2026'                 => 'd.m.Y',
        '11/24/2026'                 => 'm/d/Y',
        '2026-11-24'                 => 'Y-m-d',
        '24/11/2026 14:30'           => 'd/m/Y H:i',
        '24 Nov 2026, 2:30 pm'       => 'j M Y, g:i a',
        '14:30'                      => 'H:i',
        '2:30 pm'                    => 'g:i a',
        'Site language, long'        => 'lang:DATE_FORMAT_LC3',
        'Site language, short'       => 'lang:DATE_FORMAT_LC4',
        'How long ago (3 days ago)'  => 'relative',
    ];

    /** Number separators: decimal mark and thousands separator. */
    public const SEPARATORS = [
        'comma'  => ['.', ','],
        'dot'    => [',', '.'],
        'space'  => [',', "\u{202F}"],
        'none'   => ['.', ''],
    ];

    private const BREAKPOINTS = [
        'Always'                        => '',
        'From Small (Phone Landscape)'  => 's',
        'From Medium (Tablet Landscape)' => 'm',
        'From Large (Desktop)'          => 'l',
        'From X-Large (Large Screens)'  => 'xl',
    ];

    private const YES = ['1', 'yes', 'y', 'true', 'on', 'ya', '✓', '✔', '✅'];

    private const NO = ['0', 'no', 'n', 'false', 'off', 'tidak', '✗', '✘', '❌', 'x', '-', '–', '—'];

    /**
     * Builder fields: the Columns tab of the table, and the cells of a row.
     *
     * @param  array<string, mixed>  $type
     *
     * @return array<string, mixed>
     */
    public static function addFields(array $type): array
    {
        if (($type['name'] ?? '') === 'elemen_table_pro') {
            return self::columnFields($type);
        }

        if (($type['name'] ?? '') === 'elemen_table_pro_item') {
            return self::cellFields($type);
        }

        return $type;
    }

    /**
     * @param  array<string, mixed>  $type
     *
     * @return array<string, mixed>
     */
    private static function columnFields(array $type): array
    {
        $groups = [];

        for ($i = 1; $i <= self::MAX; $i++) {
            $p      = "col{$i}_";
            $isType = static fn (string ...$types): string => '$match(' . $p . 'type || \'text\', \'^(' . implode('|', $types) . ')$\')';

            $type['fields'] += [
                "{$p}label" => [
                    'label'     => 'Heading',
                    'source'    => true,
                    'translate' => true,
                    'attrs'     => ['placeholder' => "Column {$i}"],
                ],
                "{$p}type" => [
                    'label'   => 'Type',
                    'type'    => 'select',
                    'options' => self::TYPES,
                ],
                "{$p}align" => [
                    'label'   => 'Alignment',
                    'type'    => 'select',
                    'options' => ['Left' => '', 'Center' => 'center', 'Right' => 'right'],
                ],
                "{$p}width" => [
                    'label'   => 'Width',
                    'type'    => 'select',
                    'options' => ['Auto' => '', 'Shrink' => 'shrink', 'Expand' => 'expand', 'Small' => 'small', 'Medium' => 'medium', 'Large' => 'large'],
                ],
                "{$p}visible" => [
                    'label'       => 'Visible',
                    'description' => 'Hide the column on smaller screens.',
                    'type'        => 'select',
                    'options'     => self::BREAKPOINTS,
                ],
                "{$p}limit" => [
                    'label'       => 'Character Limit',
                    'description' => 'Shorten longer text and end it with …. Empty for no limit.',
                    'type'        => 'number',
                    'attrs'       => ['min' => 0],
                    'show'        => $isType('text', 'tags'),
                ],
                "{$p}format" => [
                    'label'   => 'Date Format',
                    'type'    => 'select',
                    'options' => self::DATE_FORMATS,
                    'show'    => $isType('date'),
                ],
                "{$p}decimals" => [
                    'label' => 'Decimals',
                    'type'  => 'number',
                    'attrs' => ['min' => 0, 'max' => 6, 'placeholder' => 'as entered'],
                    'show'  => $isType('number'),
                ],
                "{$p}separator" => [
                    'label'   => 'Separators',
                    'type'    => 'select',
                    'options' => ['1,234.56' => 'comma', '1.234,56' => 'dot', '1 234,56' => 'space', '1234.56' => 'none'],
                    'show'    => $isType('number'),
                ],
                "{$p}prefix" => [
                    'label'     => 'Before',
                    'source'    => true,
                    'translate' => true,
                    'attrs'     => ['placeholder' => 'e.g. RM'],
                    'show'      => $isType('number'),
                ],
                "{$p}suffix" => [
                    'label'     => 'After',
                    'source'    => true,
                    'translate' => true,
                    'attrs'     => ['placeholder' => 'e.g. %'],
                    'show'      => $isType('number'),
                ],
                "{$p}sortable" => [
                    'label' => 'Sorting',
                    'type'  => 'checkbox',
                    'text'  => 'Visitors can sort by this column',
                    'show'  => 'sorting && !' . $isType('image', 'button'),
                ],
                "{$p}filter" => [
                    'label' => 'Filter',
                    'type'  => 'checkbox',
                    'text'  => 'Add a dropdown with this column\'s values',
                    'show'  => 'filtering && !' . $isType('image', 'icon', 'button'),
                ],
                "{$p}split" => [
                    'type' => 'checkbox',
                    'text' => 'Values separated by commas are separate choices',
                    'show' => "filtering && {$p}filter && !" . $isType('image', 'icon', 'button', 'rating', 'check'),
                ],
            ];

            $groups[] = [
                'label'   => "Column {$i}",
                'type'    => 'group',
                'divider' => true,
                'show'    => $i === 1 ? null : "(columns || 3) >= {$i}",
                'fields'  => array_map(static fn (string $f): string => $p . $f, ['label', 'type', 'align', 'width', 'visible', 'limit', 'format', 'decimals', 'separator', 'prefix', 'suffix', 'sortable', 'filter', 'split']),
            ];
        }

        $groups = array_map(static fn (array $group): array => array_filter($group, static fn ($v): bool => $v !== null), $groups);

        foreach ($type['fieldset']['default']['fields'] as &$tab) {
            if (\is_array($tab) && ($tab['title'] ?? '') === 'Columns') {
                $tab['fields'] = $groups;
            }
        }

        return $type;
    }

    /**
     * Cells of a row. A cell shows once the one before it has text, so a row panel lists
     * the filled cells and the next empty one; every cell shows for dynamic content.
     *
     * @param  array<string, mixed>  $type
     *
     * @return array<string, mixed>
     */
    private static function cellFields(array $type): array
    {
        $fields  = [];
        $dynamic = '(this.node && this.node.source)';

        for ($i = 1; $i <= self::MAX; $i++) {
            $type['fields'] += [
                "cell_{$i}" => [
                    'label'     => "Column {$i}",
                    'source'    => true,
                    'translate' => true,
                ] + ($i === 1 ? [] : ['show' => 'cell_' . ($i - 1) . " || cell_{$i} || {$dynamic}"]),
                "cell_{$i}_link" => [
                    'label'     => "Column {$i} Link",
                    'type'      => 'link',
                    'source'    => true,
                    'translate' => true,
                    'show'      => "cell_{$i} || cell_{$i}_link || {$dynamic}",
                ],
            ];

            $fields[] = "cell_{$i}";
            $fields[] = "cell_{$i}_link";
        }

        foreach ($type['fieldset']['default']['fields'] as &$tab) {
            if (\is_array($tab) && ($tab['title'] ?? '') === 'Content') {
                $tab['fields'] = $fields;
            }
        }

        return $type;
    }

    /**
     * The columns in use, with their settings.
     *
     * @param  array<string, mixed>  $props  Table Pro props.
     *
     * @return list<array{index: int, label: string, type: string, align: string, width: string, visible: string, limit: int, format: string, decimals: ?int, separator: string, prefix: string, suffix: string}>
     */
    public static function columns(array $props): array
    {
        $count   = max(1, min(self::MAX, (int) ($props['columns'] ?? 3) ?: 3));
        $columns = [];

        for ($i = 1; $i <= $count; $i++) {
            $p        = static fn (string $key) => $props["col{$i}_{$key}"] ?? '';
            // "text" was the value of Text in 1.2.
            $type     = \in_array($p('type'), self::TYPES, true) && $p('type') !== '' ? $p('type') : 'text';
            $decimals = trim((string) $p('decimals'));

            $columns[] = [
                'index'     => $i,
                'label'     => (string) $p('label'),
                'type'      => $type,
                'align'     => \in_array($p('align'), ['center', 'right'], true) ? $p('align') : '',
                'width'     => \in_array($p('width'), ['shrink', 'expand', 'small', 'medium', 'large'], true) ? $p('width') : '',
                'visible'   => \in_array($p('visible'), ['s', 'm', 'l', 'xl'], true) ? $p('visible') : '',
                'limit'     => max(0, (int) $p('limit')),
                'format'    => \in_array($p('format'), self::DATE_FORMATS, true) ? $p('format') : 'j F Y',
                'decimals'  => $decimals === '' ? null : max(0, min(6, (int) $decimals)),
                'separator' => isset(self::SEPARATORS[$p('separator')]) ? $p('separator') : 'comma',
                'prefix'    => (string) $p('prefix'),
                'suffix'    => (string) $p('suffix'),
                // Interactive table (search, sort, filter): only where the table allows it.
                'sort'      => !empty($props['sorting']) && $p('sortable') && !\in_array($type, ['image', 'button'], true),
                'filter'    => !empty($props['filtering']) && $p('filter') && !\in_array($type, ['image', 'icon', 'button'], true),
                'split'     => (bool) $p('split') && !\in_array($type, ['image', 'icon', 'button', 'rating', 'check'], true),
            ];
        }

        return $columns;
    }

    /**
     * Value to sort a cell by: a number for numbers, ratings and yes / no; the date for
     * dates; the text otherwise.
     *
     * @param  array<string, mixed>  $column
     */
    public static function sortValue(array $column, string $value, string $html): string
    {
        $plain = self::plain($value);

        switch ($column['type']) {
            case 'number':
            case 'rating':
                $number = self::parseNumber($plain);

                return $number === null ? '' : (string) (float) $number;

            case 'check':
                $key = mb_strtolower($plain);

                return \in_array($key, self::YES, true) ? '1' : (\in_array($key, self::NO, true) ? '0' : '');

            case 'date':
                try {
                    return \Joomla\CMS\Factory::getDate($plain)->format('Y-m-d H:i:s');
                } catch (\Throwable) {
                    return '';
                }

            default:
                return mb_strtolower(self::plain($html !== '' ? $html : $value));
        }
    }

    /**
     * Values a filter dropdown offers for a cell: the shown text, split at commas when the
     * column asks for it; the score for ratings.
     *
     * @param  array<string, mixed>  $column
     *
     * @return list<string>
     */
    public static function filterValues(array $column, string $value, string $html): array
    {
        if ($column['type'] === 'rating') {
            $score = self::sortValue($column, $value, $html);

            return $score === '' ? [] : [$score];
        }

        $text = self::plain($column['type'] === 'tags' || $column['split'] ? $value : $html);

        if ($text === '') {
            return [];
        }

        $values = $column['type'] === 'tags' || $column['split'] ? explode(',', $text) : [$text];

        return array_values(array_unique(array_filter(array_map('trim', $values), 'strlen')));
    }

    /**
     * Classes a column's heading and cells share: alignment and visibility.
     *
     * @param  array<string, mixed>  $column
     *
     * @return list<string>
     */
    public static function columnClasses(array $column): array
    {
        return array_values(array_filter([
            $column['align'] ? 'uk-text-' . $column['align'] : '',
            $column['visible'] ? 'uk-visible@' . $column['visible'] : '',
        ]));
    }

    /**
     * Width class of a column heading.
     *
     * @param  array<string, mixed>  $column
     */
    public static function widthClass(array $column): string
    {
        return match ($column['width']) {
            'shrink', 'expand' => 'uk-table-' . $column['width'],
            'small', 'medium', 'large' => 'uk-width-' . $column['width'],
            default => '',
        };
    }

    /**
     * The HTML of one cell's content.
     *
     * @param  array<string, mixed>  $column
     * @param  array<string, mixed>  $element  Table Pro props.
     */
    public static function cell(\YOOtheme\View $view, array $column, string $value, string $link, array $element): string
    {
        $value = trim($value);

        if ($value === '') {
            return '';
        }

        $target = !empty($element['link_target']) ? ' target="_blank" rel="noopener"' : '';
        $wrap   = static fn (string $html): string => $link !== ''
            ? '<a class="el-link" href="' . htmlspecialchars($link) . '"' . $target . '>' . $html . '</a>'
            : $html;

        switch ($column['type']) {
            case 'number':
                return $wrap(self::number($value, $column));

            case 'date':
                return $wrap(self::date($value, $column['format']));

            case 'image':
                return self::image($view, $value, $link, $target, $element);

            case 'icon':
                return $wrap(self::icon($value, (int) ($element['icon_size'] ?: 20)));

            case 'rating':
                return $wrap(self::rating($value, max(1, min(10, (int) ($element['rating_max'] ?: 5))), (string) ($element['rating_color'] ?? 'warning')));

            case 'check':
                return $wrap(self::check($value, (int) ($element['icon_size'] ?: 20)));

            case 'button':
                if ($link === '') {
                    return $value;
                }

                $style = \in_array($element['button_style'] ?? '', ['default', 'primary', 'secondary', 'text', 'link'], true) ? $element['button_style'] : 'default';
                $size  = \in_array($element['button_size'] ?? '', ['small', 'large'], true) ? ' uk-button-' . $element['button_size'] : '';
                $class = $style === 'link' ? 'el-link uk-link' : "el-link uk-button uk-button-{$style}{$size}";

                return '<a class="' . $class . '" href="' . htmlspecialchars($link) . '"' . $target . '>' . $value . '</a>';

            case 'tags':
                $tags = array_filter(array_map(static fn (string $t): string => trim($t), explode(',', strip_tags($value))), 'strlen');

                return $wrap(implode(' ', array_map(
                    static fn (string $tag): string => '<span class="uk-label tp-tag">' . htmlspecialchars(self::limit($tag, $column['limit'])) . '</span>',
                    $tags
                )));

            default:
                return $wrap($column['limit'] ? htmlspecialchars(self::limit(strip_tags($value), $column['limit'])) : $value);
        }
    }

    /**
     * Text to search, sort or label a cell by: without HTML.
     */
    public static function plain(string $value): string
    {
        return trim(html_entity_decode(strip_tags($value), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    }

    public static function limit(string $text, int $limit): string
    {
        $text = trim(html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8'));

        return $limit > 0 && mb_strlen($text) > $limit ? rtrim(mb_substr($text, 0, $limit)) . '…' : $text;
    }

    /**
     * @param  array<string, mixed>  $column
     */
    /**
     * A number written with either decimal mark, as "1234.5", or null for other text:
     * "1,234.56" and "1.234,56" have both marks, the last is the decimal one; "1,200" and
     * "1.200.000" are thousands; "4,5" is a decimal comma.
     */
    public static function parseNumber(string $text): ?string
    {
        $text = str_replace(["\u{202F}", "\u{A0}", ' ', "'"], '', self::plain($text));

        if (!preg_match('/^[-+]?[\d.,]*\d[\d.,]*$/', $text)) {
            return null;
        }

        $comma = strrpos($text, ',');
        $dot   = strrpos($text, '.');

        if ($comma !== false && $dot !== false) {
            $decimal = $comma > $dot ? ',' : '.';
            $text    = str_replace($decimal === ',' ? '.' : ',', '', $text);
            $text    = str_replace(',', '.', $text);
        } elseif ($comma !== false || $dot !== false) {
            $mark  = $comma !== false ? ',' : '.';
            $parts = explode($mark, $text);
            // Several marks, or one followed by exactly three digits after a short whole part:
            // thousands. "1.5" and "4,5": decimals.
            $thousands = \count($parts) > 2 || (\strlen(end($parts)) === 3 && \strlen(ltrim($parts[0], '-+')) <= 3 && $mark === ',');
            $text      = $thousands ? str_replace($mark, '', $text) : str_replace(',', '.', $text);
        }

        return is_numeric($text) ? $text : null;
    }

    public static function number(string $value, array $column): string
    {
        $plain = self::parseNumber($value);

        // Text that is not a number: as entered.
        if ($plain === null) {
            return $value;
        }

        $decimals         = $column['decimals'] ?? (str_contains($plain, '.') ? \strlen(substr($plain, strpos($plain, '.') + 1)) : 0);
        [$mark, $thousand] = self::SEPARATORS[$column['separator']];
        $number           = number_format((float) $plain, $decimals, $mark, $thousand);

        return htmlspecialchars($column['prefix'] . ($column['prefix'] !== '' && !preg_match('/\s$/u', $column['prefix']) ? "\u{A0}" : '') . $number . $column['suffix']);
    }

    public static function date(string $value, string $format): string
    {
        $plain = self::plain($value);

        try {
            $hasTime = (bool) preg_match('/\d{1,2}:\d{2}/', $plain);
            // A date without a time is the same day everywhere: no time zone conversion.
            $tz = $hasTime ? true : null;

            if ($format === 'relative') {
                $html = HTMLHelper::_('date.relative', $plain);
            } else {
                $html = HTMLHelper::_('date', $plain, str_starts_with($format, 'lang:') ? Text::_(substr($format, 5)) : $format, $tz);
            }
        } catch (\Throwable) {
            return $value;
        }

        $iso = $hasTime ? HTMLHelper::_('date', $plain, 'c', true) : HTMLHelper::_('date', $plain, 'Y-m-d', null);

        return '<time datetime="' . htmlspecialchars((string) $iso) . '">' . htmlspecialchars((string) $html) . '</time>';
    }

    /**
     * @param  array<string, mixed>  $element
     */
    private static function image(\YOOtheme\View $view, string $value, string $link, string $target, array $element): string
    {
        $src   = self::plain($value);
        $width = max(16, (int) ($element['image_width'] ?: 80));
        $img   = $view->el('image', [
            'class'     => ['el-image tp-image'],
            'src'       => $src,
            'alt'       => '',
            'width'     => $width,
            'loading'   => 'lazy',
            'thumbnail' => true,
        ])->render([]);

        if ($link !== '') {
            return '<a class="el-link" href="' . htmlspecialchars($link) . '"' . $target . '>' . $img . '</a>';
        }

        if (!empty($element['lightbox'])) {
            $href = preg_match('#^(https?:)?//|^/#', $src) ? $src : Uri::root(true) . '/' . ltrim($src, '/');

            return '<a class="tp-lightbox" href="' . htmlspecialchars($href) . '" data-type="image">' . $img . '</a>';
        }

        return $img;
    }

    public static function icon(string $value, int $size): string
    {
        $name  = self::plain($value);
        $ratio = round(max(10, $size) / 20, 2);

        if (str_starts_with($name, 'class:')) {
            return '<span class="tp-icon ' . htmlspecialchars(trim(substr($name, 6))) . '" style="font-size:' . max(10, $size) . 'px" aria-hidden="true"></span>';
        }

        $name = preg_replace('/^uikit:/', '', $name);

        if (!preg_match('/^[a-z0-9-]+$/', (string) $name)) {
            return htmlspecialchars($value);
        }

        return '<span class="tp-icon" uk-icon="icon: ' . $name . '; ratio: ' . $ratio . '" aria-hidden="true"></span>';
    }

    public static function rating(string $value, int $max, string $color = 'warning'): string
    {
        $plain = str_replace(',', '.', self::plain($value));

        if (!is_numeric($plain)) {
            return htmlspecialchars($value);
        }

        $score   = max(0, min($max, (float) $plain));
        $percent = round($score / $max * 100, 2);
        $star    = '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M10 1.6l2.6 5.3 5.8.8-4.2 4.1 1 5.8L10 14.9l-5.2 2.7 1-5.8L1.6 7.7l5.8-.8z"/></svg>';
        $stars   = str_repeat($star, $max);
        $label   = Text::sprintf('PLG_SYSTEM_ELEMEN_TABLE_PRO_RATING', rtrim(rtrim(number_format($score, 1, '.', ''), '0'), '.'), $max);

        $class = match ($color) {
            'primary'  => 'uk-text-primary',
            'emphasis' => 'uk-text-emphasis',
            default    => 'tp-gold',
        };

        return '<span class="tp-rating ' . $class . '" role="img" aria-label="' . htmlspecialchars($label) . '">'
            . '<span class="tp-rating-empty">' . $stars . '</span>'
            . '<span class="tp-rating-full" style="width:' . $percent . '%">' . $stars . '</span>'
            . '</span>';
    }

    public static function check(string $value, int $size): string
    {
        $key   = mb_strtolower(self::plain($value));
        $ratio = round(max(10, $size) / 20, 2);

        if (\in_array($key, self::YES, true)) {
            return '<span class="tp-check tp-yes" uk-icon="icon: check; ratio: ' . $ratio . '"></span><span class="uk-hidden-visually">' . Text::_('PLG_SYSTEM_ELEMEN_TABLE_PRO_YES') . '</span>';
        }

        if (\in_array($key, self::NO, true)) {
            return '<span class="tp-check tp-no" uk-icon="icon: close; ratio: ' . $ratio . '"></span><span class="uk-hidden-visually">' . Text::_('PLG_SYSTEM_ELEMEN_TABLE_PRO_NO') . '</span>';
        }

        // Anything else, such as "Limited", as written.
        return $value;
    }
}
