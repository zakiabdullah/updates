<?php

/**
 * Plain HTML stored in the article text, used by search and when the builder is off.
 *
 * @var array<string, mixed> $props
 * @var list<array<string, mixed>>|null $columns
 */

\defined('_JEXEC') or die;

$columns ??= [];
$cells   = array_map(static fn (array $column): string => trim((string) ($props['cell_' . $column['index']] ?? '')), $columns);

if (!array_filter($cells, 'strlen')) {
    return;
}

?>
<tr>
    <?php foreach ($cells as $cell) : ?>
    <td><?= $cell ?></td>
    <?php endforeach ?>
</tr>
