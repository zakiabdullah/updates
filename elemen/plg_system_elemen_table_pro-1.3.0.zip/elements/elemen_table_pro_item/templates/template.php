<?php

/**
 * Table Pro row: one cell per column. The table passes its settings, its columns and the
 * row number.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<string, mixed> $element
 * @var list<array<string, mixed>> $columns
 * @var int $number
 * @var string $countClass
 */

\defined('_JEXEC') or die;

require_once \dirname(__DIR__, 2) . '/elemen_table_pro/ElemenTablePro.php';

$columns ??= ElemenTablePro::columns([]);
$element ??= [];

$el = $this->el('tr', ['class' => ['el-item']]);

?>
<?= $el($props, $attrs) ?>
    <?php if (!empty($element['counting'])) : ?>
    <td class="tp-count<?= $countClass ?? '' ?>" data-label="<?= htmlspecialchars(ElemenTablePro::plain((string) ($element['counting_label'] ?? '#'))) ?>"><?= (int) ($number ?? 1) ?></td>
    <?php endif ?>
    <?php foreach ($columns as $column) : ?>
    <?php
    $i     = $column['index'];
    $value = (string) ($props["cell_{$i}"] ?? '');
    $html  = ElemenTablePro::cell($this, $column, $value, trim((string) ($props["cell_{$i}_link"] ?? '')), $element);
    $class = implode(' ', ['el-cell', "tp-type-{$column['type']}", ...ElemenTablePro::columnClasses($column)]);

    // For the script: the column, the value to sort by and the filter choices.
    $data = ' data-col="' . $i . '"';

    if ($column['sort']) {
        $data .= ' data-sort="' . htmlspecialchars(ElemenTablePro::sortValue($column, $value, $html)) . '"';
    }

    if ($column['filter']) {
        $data .= ' data-filter="' . htmlspecialchars((string) json_encode(ElemenTablePro::filterValues($column, $value, $html), JSON_UNESCAPED_UNICODE)) . '"';
    }
    ?>
    <td class="<?= $class ?>" data-label="<?= htmlspecialchars(ElemenTablePro::plain($column['label'])) ?>"<?= $data ?>><?= $html ?></td>
    <?php endforeach ?>
<?= $el->end() ?>
