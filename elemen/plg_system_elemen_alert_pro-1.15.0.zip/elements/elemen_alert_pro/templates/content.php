<?php

/**
 * Plain HTML stored in the article text, used by search and when the builder is off.
 *
 * @var array<string, mixed> $props
 */

\defined('_JEXEC') or die;

?>
<?php if ($props['title'] || $props['content']) : ?>
<div>
    <?php if ($props['title']) : ?>
    <p><strong><?= $props['title'] ?></strong></p>
    <?php endif ?>
    <?= $props['content'] ?>
</div>
<?php endif ?>
