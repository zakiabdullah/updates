<?php

/**
 * Registers DOCman as a YOOtheme dynamic content source.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

// YOOtheme validates event listeners as callables when registering them. Load the class
// before the event is registered; app.php is loaded immediately afterwards by the bootstrap.
require_once __DIR__ . '/src/DocmanSource.php';
require_once __DIR__ . '/src/DocmanQueryType.php';
require_once __DIR__ . '/src/DocmanDocumentType.php';

return [
    'source.init'                         => [Elemen\DocmanPro\Source\DocmanSource::class, 'init'],
    \YOOtheme\Builder\BuilderConfig::class => [Elemen\DocmanPro\Source\DocmanSource::class, 'builderConfig'],
];
