<?php

/**
 * Loads the DOCman dynamic content source types.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

require_once __DIR__ . '/src/DocmanSource.php';
require_once __DIR__ . '/src/DocmanQueryType.php';
require_once __DIR__ . '/src/DocmanDocumentType.php';

return [];
