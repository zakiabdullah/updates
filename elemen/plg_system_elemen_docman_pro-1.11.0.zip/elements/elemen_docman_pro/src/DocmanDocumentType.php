<?php

/**
 * Dynamic fields available for a DOCman document.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

namespace Elemen\DocmanPro\Source;

use Joomla\CMS\Language\Text;

\defined('_JEXEC') or die;

final class DocmanDocumentType
{
    /**
     * Field name => [GraphQL type, language key suffix, YOOtheme filters].
     */
    private const FIELDS = [
        'id'                  => ['Int', 'ID', []],
        'title'               => ['String', 'TITLE', ['limit', 'preserve']],
        'description'         => ['String', 'DESCRIPTION', ['limit', 'preserve']],
        'link'                => ['String', 'LINK', []],
        'download'            => ['String', 'DOWNLOAD', []],
        'image'               => ['String', 'IMAGE', []],
        'icon'                => ['String', 'ICON', []],
        'category_title'      => ['String', 'CATEGORY', []],
        'category_id'         => ['Int', 'CATEGORY_ID', []],
        'publish_date'        => ['String', 'PUBLISHED', ['date']],
        'created_on'          => ['String', 'CREATED', ['date']],
        'modified_on'         => ['String', 'MODIFIED', ['date']],
        'author'              => ['String', 'AUTHOR', []],
        'hits'                => ['Int', 'HITS', []],
        'file_extension'      => ['String', 'FILE_EXTENSION', []],
        'file_type'           => ['String', 'FILE_TYPE', []],
        'mime_type'           => ['String', 'MIME_TYPE', []],
        'file_size'           => ['Int', 'FILE_SIZE', []],
        'file_size_formatted' => ['String', 'FILE_SIZE_FORMATTED', []],
    ];

    public static function config(): array
    {
        $fields = [];

        foreach (self::FIELDS as $name => [$type, $label, $filters]) {
            $metadata = ['label' => Text::_('PLG_SYSTEM_ELEMEN_DOCMAN_PRO_DOCUMENT_' . $label)];

            if ($filters) {
                $metadata['filters'] = $filters;
            }

            $fields[$name] = ['type' => $type, 'metadata' => $metadata];
        }

        return [
            'fields'   => $fields,
            'metadata' => [
                'type'  => true,
                'label' => Text::_('PLG_SYSTEM_ELEMEN_DOCMAN_PRO_SOURCE_DOCUMENT'),
            ],
        ];
    }

    /**
     * Human readable file size in binary units, e.g. "4.8 MB". Empty for 0 bytes.
     */
    public static function formatSize(int $bytes): string
    {
        if ($bytes < 1) {
            return '';
        }

        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $power = min(count($units) - 1, (int) floor(log($bytes, 1024)));

        if ($power === 0) {
            return $bytes . ' B';
        }

        $value = number_format($bytes / (1024 ** $power), 1, '.', '');

        return (str_ends_with($value, '.0') ? substr($value, 0, -2) : $value) . ' ' . $units[$power];
    }
}
