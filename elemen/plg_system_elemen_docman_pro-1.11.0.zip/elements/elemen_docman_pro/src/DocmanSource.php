<?php

/**
 * YOOtheme source registration for DOCman.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

namespace Elemen\DocmanPro\Source;

use YOOtheme\Builder\Source;

\defined('_JEXEC') or die;

final class DocmanSource
{
    public static function init(Source $source): void
    {
        $source->objectType('ElemenDocmanDocument', DocmanDocumentType::config());
        $source->queryType(DocmanQueryType::config());
    }

    /**
     * DOCman categories for the category select of the "DOCman Documents" query.
     *
     * @param \YOOtheme\Builder\BuilderConfig $config
     */
    public static function builderConfig($config): void
    {
        $config->merge(['elemen_docman.categories' => DocmanQueryType::categoryOptions()]);
    }
}
