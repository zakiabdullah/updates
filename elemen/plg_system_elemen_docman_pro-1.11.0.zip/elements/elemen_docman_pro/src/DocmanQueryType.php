<?php

/**
 * Custom DOCman document queries exposed in YOOtheme's Dynamic Content picker.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

namespace Elemen\DocmanPro\Source;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

\defined('_JEXEC') or die;

final class DocmanQueryType
{
    /**
     * Order option => [DOCman sort column, direction]. '' keeps DOCman's own order.
     */
    public const ORDERS = [
        'newest'   => ['created_on', 'desc'],
        'oldest'   => ['created_on', 'asc'],
        'title'    => ['title', 'asc'],
        'title_za' => ['title', 'desc'],
        'popular'  => ['hits', 'desc'],
        'modified' => ['touched_on', 'desc'],
        'ordering' => ['ordering', 'asc'],
    ];

    public static function config(): array
    {
        $t = static fn (string $key): string => Text::_('PLG_SYSTEM_ELEMEN_DOCMAN_PRO_' . $key);

        $orders = [$t('ORDER_DEFAULT') => ''];

        foreach (array_keys(self::ORDERS) as $order) {
            $orders[$t('ORDER_' . strtoupper($order))] = $order;
        }

        return [
            'fields' => [
                'customElemenDocmanDocument' => [
                    'type' => 'ElemenDocmanDocument',
                    'args' => [
                        'id' => ['type' => 'Int'],
                    ],
                    'metadata' => [
                        'label'  => $t('SOURCE_DOCUMENT'),
                        'group'  => 'Custom',
                        'fields' => [
                            'id' => [
                                'label'       => $t('FIELD_ID'),
                                'description' => $t('FIELD_ID_DESC'),
                                'type'        => 'text',
                            ],
                        ],
                    ],
                    'extensions' => ['call' => self::class . '::document'],
                ],
                'customElemenDocmanDocuments' => [
                    'type' => ['listOf' => 'ElemenDocmanDocument'],
                    'args' => [
                        'category'          => ['type' => ['listOf' => 'String']],
                        'include_children'  => ['type' => 'Boolean'],
                        'order'             => ['type' => 'String', 'defaultValue' => ''],
                        'limit'             => ['type' => 'Int', 'defaultValue' => 10],
                        'offset'            => ['type' => 'Int', 'defaultValue' => 0],
                    ],
                    'metadata' => [
                        'label'  => $t('SOURCE_DOCUMENTS'),
                        'group'  => 'Custom',
                        'fields' => [
                            'category' => [
                                'label'   => $t('FIELD_CATEGORY'),
                                'type'    => 'select',
                                'options' => [['evaluate' => "yootheme.builder['elemen_docman.categories']"]],
                                'attrs'   => ['multiple' => true, 'class' => 'uk-height-small'],
                            ],
                            'include_children' => [
                                'description' => $t('FIELD_CATEGORY_DESC'),
                                'type'        => 'checkbox',
                                'text'        => $t('FIELD_INCLUDE_CHILDREN'),
                            ],
                            'order' => [
                                'label'   => $t('FIELD_ORDER'),
                                'type'    => 'select',
                                'options' => $orders,
                            ],
                            'limit' => [
                                'label'       => $t('FIELD_LIMIT'),
                                'description' => $t('FIELD_LIMIT_DESC'),
                                'type'        => 'number',
                                'default'     => 10,
                                'attrs'       => ['min' => 1, 'max' => 100],
                            ],
                            'offset' => [
                                'label'       => $t('FIELD_OFFSET'),
                                'description' => $t('FIELD_OFFSET_DESC'),
                                'type'        => 'number',
                                'default'     => 0,
                                'modifier'    => 1,
                                'attrs'       => ['min' => 1],
                            ],
                        ],
                    ],
                    'extensions' => ['call' => self::class . '::documents'],
                ],
            ],
        ];
    }

    public static function document($item, array $args): ?object
    {
        $id = (int) ($args['id'] ?? 0);

        if ($id < 1) {
            return null;
        }

        return self::browse(['id' => $id, 'limit' => 1])[0] ?? null;
    }

    public static function documents($item, array $args): array
    {
        // Older layouts saved one category ID as a number; the select saves a list.
        $categories = array_values(array_filter(
            array_map('intval', (array) ($args['category'] ?? [])),
            static fn (int $id): bool => $id > 0
        ));

        $state = [
            'limit'  => min(100, max(1, (int) ($args['limit'] ?? 10))),
            'offset' => max(0, (int) ($args['offset'] ?? 0)),
        ];

        if ($categories) {
            $state['category']          = $categories;
            $state['category_children'] = !empty($args['include_children']);
        }

        if ($order = self::ORDERS[(string) ($args['order'] ?? '')] ?? null) {
            [$state['sort'], $state['direction']] = $order;
        }

        return self::browse($state);
    }

    /**
     * DOCman categories as select options for the builder, indented by level.
     *
     * @return array<array{value: string, text: string}>
     */
    public static function categoryOptions(): array
    {
        if (!class_exists('Koowa')) {
            return [];
        }

        try {
            $options    = [];
            $categories = \Koowa::getObject('com://admin/docman.model.categories')
                ->sort('tree_ordering')
                ->fetch();

            foreach ($categories as $category) {
                $options[] = [
                    'value' => (string) $category->id,
                    'text'  => str_repeat('- ', max(0, (int) $category->level - 1)) . $category->title,
                ];
            }

            return $options;
        } catch (\Throwable $error) {
            self::log($error);

            return [];
        }
    }

    /**
     * Read only published DOCman documents visible to the current Joomla user, the same
     * way DOCman's own documents module does. Without DOCman, or on an API error, there
     * are no results (the error is logged).
     *
     * @return array<object>
     */
    private static function browse(array $state): array
    {
        if (!class_exists('Koowa')) {
            return [];
        }

        try {
            $user  = \Koowa::getObject('user');
            $model = \Koowa::getObject('com://site/docman.model.documents');

            // "page" finds the DOCman menu item for each document (its itemid), needed
            // for links. Where DOCman has menu items, it also limits the documents to
            // those reachable through them, as DOCman's module does.
            $model->setState($state + ['page' => 'all'])
                ->access($user->getRoles())
                ->enabled(1)
                ->status('published')
                ->current_user($user->getId());

            $documents = [];

            foreach ($model->fetch() as $document) {
                $documents[] = self::toObject($document);
            }

            return $documents;
        } catch (\Throwable $error) {
            self::log($error);

            return [];
        }
    }

    private static function toObject($document): object
    {
        $size   = (int) $document->size;
        $itemid = (int) $document->itemid;

        return (object) [
            'id'                  => (int) $document->id,
            'title'               => (string) $document->title,
            'description'         => (string) $document->description,
            'link'                => self::route($document, $itemid, 'document'),
            'download'            => self::route($document, $itemid, 'download'),
            'image'               => self::image((string) $document->image),
            'icon'                => (string) $document->icon,
            'category_title'      => (string) $document->category_title,
            'category_id'         => (int) $document->docman_category_id,
            'publish_date'        => (string) $document->publish_date,
            'created_on'          => (string) $document->created_on,
            // touched_on is NULL in MySQL for a document that was never modified.
            'modified_on'         => (string) ($document->touched_on ?: $document->created_on),
            'author'              => (string) $document->created_by_name,
            'hits'                => (int) $document->hits,
            'file_extension'      => (string) $document->extension,
            'file_type'           => (string) $document->filetype,
            'mime_type'           => (string) $document->mimetype,
            'file_size'           => $size,
            'file_size_formatted' => DocmanDocumentType::formatSize($size),
        ];
    }

    /**
     * Document page or download URL through the document's DOCman menu item. DOCman
     * cannot open documents without one, so there is no link then.
     */
    private static function route($document, int $itemid, string $view): string
    {
        if ($itemid < 1) {
            return '';
        }

        $query = [
            'option' => 'com_docman',
            'view'   => $view,
            'alias'  => (string) $document->alias,
        ];

        if ($view === 'document') {
            $query['layout'] = 'default';
        }

        if ((string) $document->category_slug !== '') {
            $query['category_slug'] = (string) $document->category_slug;
        }

        $query['Itemid'] = $itemid;

        return Route::_('index.php?' . http_build_query($query), false);
    }

    /**
     * Image path relative to the site root, so YOOtheme can resize it.
     */
    private static function image(string $image): string
    {
        static $folder;

        if ($image === '') {
            return '';
        }

        $folder ??= trim((string) \Koowa::getObject('com:files.model.containers')
            ->slug('docman-images')->fetch()->path, '/');

        return $folder !== '' ? $folder . '/' . ltrim($image, '/') : '';
    }

    private static function log(\Throwable $error): void
    {
        try {
            \Joomla\CMS\Log\Log::add(
                'DOCman Pro: ' . $error->getMessage() . ' in ' . basename($error->getFile()) . ':' . $error->getLine(),
                \Joomla\CMS\Log\Log::WARNING,
                'elemen'
            );
        } catch (\Throwable $ignored) {
        }
    }
}
