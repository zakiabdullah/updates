<?php

/**
 * Alert Pro: a notice with a type, style, icon and buttons, a close button that can be
 * remembered, show from/until dates and an "Ends in" countdown.
 *
 * Dates are checked here, when the page is made. A remembered close is checked by a small
 * inline script right after the alert, so a closed alert does not flash before it hides.
 * Without JavaScript the alert reads correctly; it only cannot be closed.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 */

use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;
use YOOtheme\Config;
use YOOtheme\Metadata;

use function YOOtheme\app;

\defined('_JEXEC') or die;

$has = static fn ($value): bool => trim(strip_tags((string) $value, '<img><svg><iframe><video>')) !== '';

if (!$has($props['title']) && !$has($props['content']) && !$has($props['cta_text'])) {
    return;
}

$app     = Factory::getApplication();
$builder = (bool) app(Config::class)->get('app.isCustomizer');

try {
    $zone = new DateTimeZone((string) ($app->get('offset') ?: 'UTC'));
} catch (Exception $e) {
    $zone = new DateTimeZone('UTC');
}

$time = static function ($value) use ($zone): int {
    if (trim((string) $value) === '') {
        return 0;
    }

    try {
        return (new DateTime((string) $value, $zone))->getTimestamp();
    } catch (Exception $e) {
        return 0;
    }
};

$now   = time();
$from  = $time($props['show_from']);
$until = $time($props['show_until']);
$out   = ($from && $now < $from) || ($until && $now >= $until);

// Outside its dates the alert is not in the page; the builder preview shows it, marked.
if ($out && !$builder) {
    return;
}

$language = $app->getLanguage();
$language->load('plg_system_elemen_alert_pro', JPATH_ADMINISTRATOR);
$text = static fn (string $key): string => $language->_('PLG_SYSTEM_ELEMEN_ALERT_PRO_' . $key);

$pick = static fn ($value, array $allowed, string $default): string => in_array((string) $value, $allowed, true) ? (string) $value : $default;
$color = static fn ($value): string => preg_match('/^[#(),.%\w\s-]+$/', trim((string) $value)) ? trim((string) $value) : '';

$type      = $pick($props['alert_type'], ['info', 'success', 'warning', 'danger', 'neutral', 'custom'], 'info');
$style     = $pick($props['alert_style'], ['soft', 'solid', 'outline', 'border-left', 'border-top', 'gradient', 'glass'], 'soft');
$size      = $pick($props['size'], ['small', 'default', 'large'], 'default');
$radius    = $pick($props['radius'], ['none', 'small', 'default', 'large', 'pill'], 'default');
$shadow    = $pick($props['shadow'], ['', 'small', 'medium', 'large'], '');
$attention = $pick($props['attention'], ['', 'pulse', 'shake'], '');
$iconMode  = $pick($props['icon_mode'], ['type', 'icon', 'image', 'none'], 'type');
$iconPos   = $pick($props['icon_position'], ['left', 'top'], 'left');
$ctaPos    = $pick($props['cta_position'], ['right', 'bottom', 'inline'], 'right');
$ctaStyle  = $pick($props['cta_style'], ['default', 'outline', 'primary', 'secondary', 'text'], 'default');
$link2Style = $pick($props['link2_style'], ['text', 'outline'], 'text');
$remember  = $props['dismiss'] ? $pick($props['dismiss_remember'], ['', 'session', 'days', 'forever'], '') : '';
$animation = $pick($props['dismiss_animation'], ['fade', 'slide', 'none'], 'fade');
$element   = $pick($props['title_element'], ['div', 'h2', 'h3', 'h4', 'h5', 'h6', 'strong'], 'div');
$titleStyle = $pick($props['title_style'], ['text-bold', 'text-large', 'h4', 'h5', 'h6', ''], 'text-bold');

// Custom colours become CSS variables; the type colours are in the stylesheet.
$vars = [];

if ($type === 'custom') {
    foreach (['accent' => 'color_accent', 'bg' => 'color_background', 'text' => 'color_text'] as $var => $prop) {
        if ($value = $color($props[$prop])) {
            $vars[] = "--ap-{$var}: {$value}";
        }
    }
}

$iconSize = (int) $props['icon_size'];

if ($iconSize >= 12 && $iconSize <= 96) {
    $vars[] = "--ap-icon: {$iconSize}px";
}

// Icon
$icon = '';

if ($iconMode === 'type' || ($iconMode === 'icon' && trim((string) $props['icon']) !== '')) {
    $name = $iconMode === 'icon' ? (string) $props['icon'] : ['info' => 'info', 'success' => 'check', 'warning' => 'warning', 'danger' => 'ban', 'neutral' => 'bell', 'custom' => 'info'][$type];
    $icon = '<span class="el-icon ap-icon" uk-icon="icon: ' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . '" aria-hidden="true"></span>';
} elseif ($iconMode === 'image' && trim((string) $props['icon_image']) !== '') {
    $src  = (string) $props['icon_image'];
    $icon = '<span class="el-icon ap-icon ap-icon-image" aria-hidden="true">' . $this->el('image', [
        'src'       => $src,
        'alt'       => '',
        'width'     => $iconSize ?: 64,
        'height'    => $iconSize ?: 64,
        'uk-svg'    => $this->isImage($src) === 'svg',
        'thumbnail' => true,
    ])->render([]) . '</span>';
}

// Buttons
$buttonSize = $size === 'large' ? '' : ' uk-button-small';
$buttons    = '';

if ($has($props['cta_text'])) {
    $class = match ($ctaStyle) {
        'primary', 'secondary' => "uk-button uk-button-{$ctaStyle}{$buttonSize}",
        'outline'              => "uk-button ap-btn ap-btn-outline{$buttonSize}",
        'text'                 => 'ap-link',
        default                => "uk-button ap-btn ap-btn-accent{$buttonSize}",
    };

    $buttons .= $this->el('a', [
        'class'  => ["el-link {$class}"],
        'href'   => ['{cta_link}'],
        'target' => ['_blank {@cta_target}'],
        'rel'    => ['noopener {@cta_target}'],
    ])->render($props, $props['cta_text']);
}

if ($has($props['link2_text'])) {
    $buttons .= $this->el('a', [
        'class' => ['el-link ' . ($link2Style === 'outline' ? "uk-button ap-btn ap-btn-outline{$buttonSize}" : 'ap-link')],
        'href'  => ['{link2_link}'],
    ])->render($props, $props['link2_text']);
}

$buttons = $buttons !== '' ? '<div class="ap-actions">' . $buttons . '</div>' : '';

// Countdown to Show Until, ticked by the script; when it ends the alert hides.
$countdown = '';

if ($props['countdown'] && $until && !$out) {
    $left  = $until - $now;
    $parts = [];

    foreach (['D' => 86400, 'H' => 3600, 'M' => 60, 'S' => 1] as $unit => $seconds) {
        $value = intdiv($left, $seconds);
        $left -= $value * $seconds;

        if ($value || $parts || $unit === 'S') {
            $parts[] = ($parts ? str_pad((string) $value, 2, '0', STR_PAD_LEFT) : $value) . $text($unit);
        }
    }

    $countdown = '<div class="el-countdown ap-countdown">' . $text('ENDS_IN') . ' <span class="ap-countdown-time" role="timer">' . implode(' ', $parts) . '</span></div>';
}

$title   = $has($props['title']) ? "<{$element} class=\"el-title ap-title" . ($titleStyle ? " uk-{$titleStyle}" : '') . "\">{$props['title']}</{$element}>" : '';
$content = $has($props['content']) ? '<div class="el-content ap-content uk-panel">' . $props['content'] . '</div>' : '';

$key = 'elemen-alert-' . substr(md5(implode('|', [$props['title'], $props['content'], $props['cta_text'], $props['cta_link'], $props['link2_text'], $props['link2_link']])), 0, 12);

$options = array_filter([
    'key'       => $props['dismiss'] ? $key : '',
    'remember'  => $remember,
    'days'      => $remember === 'days' ? max(1, min(365, (int) $props['dismiss_days'])) : 0,
    'animation' => $props['dismiss'] ? $animation : '',
    'until'     => $countdown ? $until * 1000 : 0,
    'units'     => $countdown ? ['d' => $text('D'), 'h' => $text('H'), 'm' => $text('M'), 's' => $text('S')] : [],
]);

$needsScript = $props['dismiss'] || $countdown || $attention;

$assets   = \dirname(__DIR__) . '/assets';
$assetUrl = static fn (string $file): string => Uri::root(true) . '/'
    . str_replace('\\', '/', substr($assets, strlen(JPATH_ROOT) + 1)) . "/{$file}?v=" . @filemtime("{$assets}/{$file}");
$metadata = app(Metadata::class);

$metadata->set('style:elemen-alert-pro', ['href' => $assetUrl('alert-pro.css')]);

if ($needsScript) {
    $metadata->set('script:elemen-alert-pro', ['src' => $assetUrl('alert-pro.js'), 'defer' => true]);
}

$el = $this->el('div', [

    'class' => [
        'elemen-alert-pro ap',
        "ap-type-{$type}",
        "ap-style-{$style}",
        "ap-size-{$size}",
        "ap-radius-{$radius}",
        $shadow ? "ap-shadow-{$shadow}" : '',
        $icon ? "ap-icon-{$iconPos}" : '',
        "ap-actions-{$ctaPos}",
        'ap-compact' => (bool) $props['compact'],
        'ap-dismissible' => (bool) $props['dismiss'],
        $attention ? "ap-attention-{$attention}" : '',
        'ap-out-of-schedule' => $out,
    ],

    'role'    => in_array($type, ['warning', 'danger'], true) ? 'alert' : 'status',
    'style'   => $vars ? implode('; ', $vars) : false,
    'data-ap' => $options ? json_encode($options) : false,

]);

?>
<?= $el($props, $attrs) ?>
    <?= $icon ?>
    <div class="ap-body">
        <div class="ap-text">
            <?= $title ?>
            <?= $content ?>
            <?= $countdown ?>
        </div>
        <?= $buttons ?>
    </div>
    <?php if ($props['dismiss']) : ?>
    <button type="button" class="el-close ap-close" uk-close aria-label="<?= htmlspecialchars($text('CLOSE'), ENT_QUOTES, 'UTF-8') ?>"></button>
    <?php endif ?>
<?= $el->end() ?>
<?php if ($remember && !$builder) : ?>
<script>(function(a){try{var o=JSON.parse(a.getAttribute('data-ap')),s=o.remember==='session'?sessionStorage:localStorage,v=s.getItem(o.key);if(v&&(v==='1'||+v>Date.now()))a.hidden=true}catch(e){}})(document.currentScript.previousElementSibling)</script>
<?php endif ?>
