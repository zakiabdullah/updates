/* Elemen: Alert Pro: close (and remember), the "Ends in" countdown and the attention
   animation. No dependencies. */
(() => {
    const builder = window.self !== window.top;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    function store(o) {
        try {
            return o.remember === 'session' ? window.sessionStorage : window.localStorage;
        } catch (e) {
            return null;
        }
    }

    function hide(alert, animation) {
        if (reduce || !animation || animation === 'none') {
            alert.hidden = true;
            return;
        }

        if (animation === 'slide') {
            alert.style.maxHeight = `${alert.offsetHeight}px`;
            // Reflow so the height change animates.
            void alert.offsetHeight;
            alert.style.maxHeight = '0px';
            alert.style.marginTop = '0px';
            alert.style.marginBottom = '0px';
            alert.style.paddingTop = '0px';
            alert.style.paddingBottom = '0px';
        }

        alert.classList.add(`ap-closing-${animation}`);
        setTimeout(() => {
            alert.hidden = true;
        }, 450);
    }

    function setup(alert) {
        alert.setAttribute('data-ap-ready', '');

        let o = {};

        try {
            o = JSON.parse(alert.getAttribute('data-ap') || '{}');
        } catch (e) {
            // no options: nothing to do
        }

        // Close
        const close = alert.querySelector(':scope > .ap-close');

        if (close) {
            close.addEventListener('click', () => {
                if (o.remember && o.key && !builder) {
                    const s = store(o);
                    const value = o.remember === 'days' ? String(Date.now() + o.days * 86400000) : '1';

                    try {
                        s && s.setItem(o.key, value);
                    } catch (e) {
                        // private mode: closed for this page view only
                    }
                }

                hide(alert, o.animation);
            });
        }

        // Ends in
        const time = alert.querySelector('.ap-countdown-time');

        if (time && o.until) {
            const u = o.units || {};
            const sizes = [['d', 86400], ['h', 3600], ['m', 60], ['s', 1]];

            const tick = () => {
                let left = Math.max(0, Math.floor((o.until - Date.now()) / 1000));

                if (!left) {
                    if (!builder) {
                        hide(alert, 'fade');
                    }
                    return;
                }

                const parts = [];

                sizes.forEach(([unit, size]) => {
                    const value = Math.floor(left / size);
                    left -= value * size;

                    if (value || parts.length || unit === 's') {
                        parts.push((parts.length ? String(value).padStart(2, '0') : value) + (u[unit] || unit));
                    }
                });

                time.textContent = parts.join(' ');
                setTimeout(tick, 1000 - (Date.now() % 1000) + 20);
            };

            tick();
        }

        // Attention, once, when the alert comes into view
        if (!reduce && /\bap-attention-/.test(alert.className) && 'IntersectionObserver' in window) {
            const io = new IntersectionObserver((entries) => {
                if (entries.some((entry) => entry.isIntersecting)) {
                    io.disconnect();
                    alert.classList.add('ap-play');
                }
            }, { threshold: 0.6 });

            io.observe(alert);
        }
    }

    const init = (root) => root.querySelectorAll('.elemen-alert-pro:not([data-ap-ready])').forEach(setup);

    const boot = () => {
        init(document);

        // The YOOtheme builder preview (an iframe) replaces elements while editing.
        if (builder) {
            new MutationObserver(() => init(document)).observe(document.body, { childList: true, subtree: true });
        }
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
