<?php

/**
 * Table Pro row: one cell per column. The table passes its settings, its columns and the
 * row number.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<string, mixed> $element
 * @var list<array<string, mixed>> $columns
 * @var int $number
 * @var string $countClass
 */

\defined('_JEXEC') or die;

require_once \dirname(__DIR__, 2) . '/elemen_table_pro/ElemenTablePro.php';

$columns ??= ElemenTablePro::columns([]);
$element ??= [];

$el = $this->el('tr', ['class' => ['el-item']]);

?>
<?= $el($props, $attrs) ?>
    <?php if (!empty($element['counting'])) : ?>
    <td class="tp-count<?= $countClass ?? '' ?>" data-label="<?= htmlspecialchars(ElemenTablePro::plain((string) ($element['counting_label'] ?? '#'))) ?>"><?= (int) ($number ?? 1) ?></td>
    <?php endif ?>
    <?php foreach ($columns as $column) : ?>
    <?php
    $i     = $column['index'];
    $html  = ElemenTablePro::cell($this, $column, (string) ($props["cell_{$i}"] ?? ''), trim((string) ($props["cell_{$i}_link"] ?? '')), $element);
    $class = implode(' ', ['el-cell', "tp-type-{$column['type']}", ...ElemenTablePro::columnClasses($column)]);
    ?>
    <td class="<?= $class ?>" data-label="<?= htmlspecialchars(ElemenTablePro::plain($column['label'])) ?>"><?= $html ?></td>
    <?php endforeach ?>
<?= $el->end() ?>
