<?php

/**
 * Table Pro: a table with up to 24 columns. Each column has a type (text, number, date,
 * image, icon, rating, yes / no, button or tags); each row is an item.
 *
 * On small screens the table scrolls sideways, or shows every row as a card with the
 * column names (the cells carry them in data-label).
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var \YOOtheme\Builder $builder
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<int, object> $children
 */

use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;
use YOOtheme\Metadata;

use function YOOtheme\app;

\defined('_JEXEC') or die;

require_once \dirname(__DIR__) . '/ElemenTablePro.php';

$columns = ElemenTablePro::columns($props);

// Rows with at least one cell in a column in use.
$rows = array_values(array_filter($children, static function (object $child) use ($columns): bool {
    $p = (array) ($child->props ?? []);

    foreach ($columns as $column) {
        if (trim((string) ($p['cell_' . $column['index']] ?? '')) !== '') {
            return true;
        }
    }

    return false;
}));

if (!$rows) {
    return;
}

Factory::getApplication()->getLanguage()->load('plg_system_elemen_table_pro', JPATH_ADMINISTRATOR);

$assets   = \dirname(__DIR__) . '/assets';
$assetUrl = static fn (string $file): string => Uri::root(true) . '/'
    . str_replace('\\', '/', substr($assets, strlen(JPATH_ROOT) + 1)) . "/{$file}?v=" . @filemtime("{$assets}/{$file}");

app(Metadata::class)->set('style:elemen-table-pro', ['href' => $assetUrl('table-pro.css')]);

$responsive = in_array($props['responsive'], ['stack', 'none'], true) ? $props['responsive'] : 'scroll';
$stackAt    = in_array($props['stack_breakpoint'], ['s', 'm', 'l'], true) ? $props['stack_breakpoint'] : 'm';
$sticky     = $props['show_header'] && $props['sticky_header'];
$images     = $props['lightbox'] && in_array('image', array_column($columns, 'type'), true);
$counting   = (bool) $props['counting'];
$countClass = in_array($props['counting_visible'], ['s', 'm', 'l', 'xl'], true) ? ' uk-visible@' . $props['counting_visible'] : '';
$headStyle  = in_array($props['header_style'], ['muted', 'primary', 'secondary'], true) ? $props['header_style'] : '';
$headBg     = $headStyle ? " uk-background-{$headStyle}" : '';

$table = $this->el('table', [
    'class' => [
        'el-table tp-table uk-table',
        'uk-table-divider {@table_divider}',
        'uk-table-striped {@table_striped}',
        'uk-table-hover {@table_hover}',
        'uk-table-middle {@table_middle}',
        'uk-table-{table_size}',
    ],
]);

$el = $this->el('div', [
    'class' => [
        'elemen-table-pro tp',
        'tp-scroll' => $responsive === 'scroll' || $sticky,
        "tp-stack tp-stack-{$stackAt}" => $responsive === 'stack',
        'tp-sticky' => $sticky,
    ],
    'style'       => $sticky ? '--tp-height: ' . max(150, (int) ($props['table_height'] ?: 600)) . 'px' : false,
    'uk-lightbox' => $images ? 'toggle: a.tp-lightbox' : false,
]);

?>
<?= $el($props, $attrs) ?>
    <?= $table($props) ?>
        <?php if (trim((string) $props['caption']) !== '') : ?>
        <caption class="uk-hidden-visually"><?= $props['caption'] ?></caption>
        <?php endif ?>
        <?php if ($props['show_header']) : ?>
        <thead<?= in_array($headStyle, ['primary', 'secondary'], true) ? ' class="uk-light"' : '' ?>>
            <tr>
                <?php if ($counting) : ?>
                <th class="tp-count uk-table-shrink<?= $countClass ?><?= $headBg ?>" scope="col"><?= $props['counting_label'] ?></th>
                <?php endif ?>
                <?php foreach ($columns as $column) : ?>
                <?php $class = trim(implode(' ', [...ElemenTablePro::columnClasses($column), ElemenTablePro::widthClass($column), trim($headBg)])) ?>
                <th scope="col"<?= $class !== '' ? ' class="' . $class . '"' : '' ?>><?= $column['label'] ?></th>
                <?php endforeach ?>
            </tr>
        </thead>
        <?php endif ?>
        <tbody>
            <?php foreach ($rows as $i => $row) : ?>
            <?= $builder->render($row, ['element' => $props, 'columns' => $columns, 'number' => $i + 1, 'countClass' => $countClass]) ?>
            <?php endforeach ?>
        </tbody>
    <?= $table->end() ?>
<?= $el->end() ?>
