<?php

/**
 * Grid Pro: grid, masonry or bento cards with a tag filter, search and Load more.
 *
 * Every item is in the page. Items after "Items Shown First" are hidden by CSS until the
 * script shows them (a noscript style shows them all). The filter, search and Load more
 * controls appear once the script runs; masonry spans are worked out by the script, and
 * without it the cards sit in a plain grid.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var \YOOtheme\Builder $builder
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<int, object> $children
 */

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;
use YOOtheme\Metadata;

use function YOOtheme\app;

\defined('_JEXEC') or die;

$has  = static fn ($value): bool => trim((string) $value) !== '';
$slug = static fn (string $text): string => trim((string) preg_replace('/[^\p{L}\p{N}]+/u', '-', mb_strtolower($text)), '-');

// Tags of every item, for the filter buttons (in order of first use) and the cards.
$items   = [];
$filters = [];

foreach ($children as $child) {
    $p = (array) ($child->props ?? []);

    if (!$has($p['title'] ?? '') && !$has($p['content'] ?? '') && empty($p['image'])) {
        continue;
    }

    $tags = [];

    foreach (explode(',', strip_tags((string) ($p['tags'] ?? ''))) as $label) {
        $label = trim(html_entity_decode($label, ENT_QUOTES, 'UTF-8'));

        if ($label !== '' && ($key = $slug($label)) !== '') {
            $tags[$key]    = $label;
            $filters[$key] ??= $label;
        }
    }

    $items[] = [$child, $tags];
}

if (!$items) {
    return;
}

$assets   = \dirname(__DIR__) . '/assets';
$assetUrl = static fn (string $file): string => Uri::root(true) . '/'
    . str_replace('\\', '/', substr($assets, strlen(JPATH_ROOT) + 1)) . "/{$file}?v=" . @filemtime("{$assets}/{$file}");
$metadata = app(Metadata::class);

$metadata->set('style:elemen-grid-pro', ['href' => $assetUrl('grid-pro.css')]);
$metadata->set('script:elemen-grid-pro', ['src' => $assetUrl('grid-pro.js'), 'defer' => true]);

$layout  = in_array($props['layout'], ['masonry', 'bento'], true) ? $props['layout'] : 'grid';
$perPage = max(0, (int) $props['per_page']);
$filter  = $props['filter'] && $filters;
$search  = (bool) $props['search'];

// Labels: the element's own, or in the page language.
Factory::getApplication()->getLanguage()->load('plg_system_elemen_grid_pro', JPATH_ADMINISTRATOR);
$labels = [
    'all'    => $has($props['label_all']) ? $props['label_all'] : Text::_('PLG_SYSTEM_ELEMEN_GRID_PRO_ALL'),
    'search' => $has($props['label_search']) ? $props['label_search'] : Text::_('PLG_SYSTEM_ELEMEN_GRID_PRO_SEARCH'),
    'more'   => $has($props['label_more']) ? $props['label_more'] : Text::_('PLG_SYSTEM_ELEMEN_GRID_PRO_LOAD_MORE'),
    'empty'  => $has($props['label_empty']) ? $props['label_empty'] : Text::_('PLG_SYSTEM_ELEMEN_GRID_PRO_NO_RESULTS'),
    'status' => Text::_('PLG_SYSTEM_ELEMEN_GRID_PRO_STATUS'),
];

// Columns per screen size, each falling back to the one below. Wide items span two
// columns only where there are two.
$vars = [];
$last = 1;

foreach (['grid_default', 'grid_small', 'grid_medium', 'grid_large'] as $i => $key) {
    $last      = max(1, min(6, (int) ($props[$key] ?: $last)));
    $vars[]    = "--gp-c{$i}: {$last}";
    $vars[]    = "--gp-w{$i}: " . min(2, $last);
}

if ($layout === 'bento') {
    $vars[] = '--gp-row: ' . max(60, (int) ($props['row_height'] ?: 220)) . 'px';
}

$cards = [];

foreach ($items as $i => [$child, $tags]) {
    $cards[] = $builder->render($child, [
        'element' => $props,
        'index'   => $i,
        'tags'    => $tags,
        'later'   => $perPage && $i >= $perPage,
    ]);
}

$options = [
    'layout'  => $layout,
    'perPage' => $perPage,
    'labels'  => ['status' => $labels['status']],
];

$overlay = $layout === 'bento' || $props['text_position'] === 'overlay';

$el = $this->el('div', [

    'class' => [
        'elemen-grid-pro gp',
        "gp-layout-{$layout}",
        'gp-gap-{gap}',
        'gp-carousel {@carousel}',
        'gp-overlay' => $overlay,
        'gp-overlay-hover' => $overlay && $props['overlay_show'] === 'hover',
        'gp-zoom {@hover_zoom}',
        'gp-lift {@hover_lift}',
        'gp-tilt {@hover_tilt}',
        'gp-has-more' => $perPage && count($items) > $perPage,
    ],

    'style'   => implode('; ', $vars),
    'data-gp' => json_encode($options),

]);

$buttons = $props['filter_style'] === 'button';
$align   = in_array($props['filter_align'], ['center', 'right'], true) ? $props['filter_align'] : 'left';

// Once per page: without JavaScript every item shows and the controls stay hidden.
$noscript = empty($GLOBALS['elemen_grid_pro_noscript']);
$GLOBALS['elemen_grid_pro_noscript'] = true;

?>
<?= $el($props, $attrs) ?>

    <?php if ($filter || $search) : ?>
    <div class="gp-toolbar gp-align-<?= $align ?>">
        <?php if ($filter) : ?>
        <div class="gp-filter gp-filter-<?= in_array($props['filter_style'], ['underline', 'button'], true) ? $props['filter_style'] : 'pill' ?>" role="group">
            <button type="button" class="gp-filter-btn is-active<?= $buttons ? ' uk-button uk-button-small uk-button-primary' : '' ?>" data-filter="" aria-pressed="true"><?= $labels['all'] ?></button>
            <?php foreach ($filters as $key => $label) : ?>
            <button type="button" class="gp-filter-btn<?= $buttons ? ' uk-button uk-button-small uk-button-default' : '' ?>" data-filter="<?= htmlspecialchars($key) ?>" aria-pressed="false"><?= htmlspecialchars($label) ?></button>
            <?php endforeach ?>
        </div>
        <?php endif ?>
        <?php if ($search) : ?>
        <div class="gp-search">
            <span class="uk-form-icon" uk-icon="icon: search"></span>
            <input class="uk-input gp-search-input" type="search" placeholder="<?= htmlspecialchars(strip_tags((string) $labels['search'])) ?>" aria-label="<?= htmlspecialchars(strip_tags((string) $labels['search'])) ?>">
        </div>
        <?php endif ?>
    </div>
    <?php endif ?>

    <div class="gp-grid">
        <?= implode("\n", $cards) ?>
    </div>

    <?php if ($filter || $search) : ?>
    <p class="gp-empty uk-text-muted uk-text-center" hidden><?= $labels['empty'] ?></p>
    <?php endif ?>

    <?php if ($perPage && count($items) > $perPage) : ?>
    <div class="gp-more uk-text-center">
        <button type="button" class="uk-button uk-button-default gp-more-btn"><?= $labels['more'] ?></button>
    </div>
    <?php endif ?>

    <div class="gp-status uk-hidden-visually" aria-live="polite"></div>

    <?php if ($noscript) : ?>
    <noscript><style>.elemen-grid-pro .gp-later{display:block}</style></noscript>
    <?php endif ?>

<?= $el->end() ?>
