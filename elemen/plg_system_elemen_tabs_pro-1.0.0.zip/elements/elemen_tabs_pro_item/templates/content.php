<?php

/**
 * Plain HTML stored in the article text, used by search and when the builder is off.
 *
 * @var array<string, mixed> $props
 */

\defined('_JEXEC') or die;

?>
<?php if ($props['title']) : ?>
<h3><?= $props['title'] ?></h3>
<?php endif ?>
<?php if ($props['content']) : ?>
<?= $props['content'] ?>
<?php endif ?>
<?php if ($props['link'] && $props['link_text']) : ?>
<p><a href="<?= htmlspecialchars((string) $props['link']) ?>"><?= $props['link_text'] ?></a></p>
<?php endif ?>
