<?php

/**
 * Grid Pro item: one card. The parent passes its tags (key => label) and whether it waits
 * for Load more.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<string, mixed> $element
 * @var array<string, string>|null $tags
 * @var bool|null $later
 */

\defined('_JEXEC') or die;

$has = static fn ($value): bool => trim((string) $value) !== '';

if (!$has($props['title']) && !$has($props['content']) && !$props['image']) {
    return;
}

$tags   = (array) ($tags ?? []);
$layout = $element['layout'];
$ratio  = $layout === 'grid' && preg_match('/^\d+-\d+$/', (string) $element['image_ratio']) ? $element['image_ratio'] : '';
$card   = $element['card_style'];

// Image
$media = '';

if ($props['image']) {
    $media = '<div class="gp-media' . ($ratio ? " gp-ratio-{$ratio}" : '') . '">' . $this->el('image', [
        'class'     => ['el-image gp-image'],
        'src'       => $props['image'],
        'alt'       => $props['image_alt'],
        'loading'   => 'lazy',
        'thumbnail' => true,
    ])->render([]) . '</div>';
}

// Text
$titleTag  = in_array($element['title_element'], ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'div'], true) ? $element['title_element'] : 'h3';
$metaClass = $element['meta_style'] === 'label' ? 'uk-label' : 'uk-' . ($element['meta_style'] ?: 'text-meta');
$body      = '';

if ($has($props['meta'])) {
    $body .= '<div class="el-meta gp-meta uk-margin-small-bottom"><span class="' . $metaClass . '">' . $props['meta'] . '</span></div>';
}

if ($has($props['title'])) {
    $body .= '<' . $titleTag . ' class="el-title gp-title uk-margin-remove' . ($element['title_style'] ? ' uk-' . $element['title_style'] : '') . '">' . $props['title'] . '</' . $titleTag . '>';
}

if ($has($props['content'])) {
    $body .= '<div class="el-content gp-content uk-panel uk-margin-small-top' . ($element['content_style'] ? ' uk-' . $element['content_style'] : '') . '">' . $props['content'] . '</div>';
}

if ($element['show_tags'] && $tags) {
    $body .= '<div class="gp-tags uk-margin-small-top">' . implode('', array_map(
        static fn (string $label): string => '<span class="gp-tag">' . htmlspecialchars($label) . '</span>',
        $tags
    )) . '</div>';
}

// Link: a button with its text, or the whole card.
$whole = $props['link'] && !$has($props['link_text']);

if ($props['link'] && !$whole) {
    $style = $element['link_style'] ?: 'text';
    $body .= '<div class="uk-margin-small-top">' . $this->el('a', [
        'class'  => [$style === 'link' ? 'el-link uk-link' : "el-link uk-button uk-button-{$style}"],
        'href'   => ['{link}'],
        'target' => $element['link_target'] ? '_blank' : false,
    ])->render($props, $props['link_text']) . '</div>';
}

$cardEl = $this->el($whole ? 'a' : 'div', [
    'class' => [
        'gp-card',
        'gp-no-image' => !$media,
        'uk-card uk-card-' . $card => in_array($card, ['default', 'primary', 'secondary'], true),
        'gp-card-muted' => $card === 'muted',
        'uk-link-toggle' => $whole,
    ],
    'href'   => $whole ? ['{link}'] : false,
    'target' => $whole && $element['link_target'] ? '_blank' : false,
]);

$size = $layout === 'bento' && in_array($props['bento_size'], ['wide', 'tall', 'large'], true) ? $props['bento_size'] : '';

$el = $this->el('div', [
    'class'     => ['el-item gp-item', "gp-size-{$size}" => (bool) $size, 'gp-later' => (bool) ($later ?? false)],
    'data-tags' => implode(' ', array_keys($tags)),
]);

?>
<?= $el($props, $attrs) ?>
    <?= $cardEl($props) ?>
        <?= $media ?>
        <?php if ($body !== '') : ?>
        <div class="gp-body"><?= $body ?></div>
        <?php endif ?>
    <?= $cardEl->end() ?>
<?= $el->end() ?>
