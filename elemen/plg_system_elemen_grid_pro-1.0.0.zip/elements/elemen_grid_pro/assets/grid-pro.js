/* Elemen: Grid Pro — tag filter, search, Load more, masonry and tilt. No dependencies. */
(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const phone = window.matchMedia('(max-width: 639.98px)');
    const hover = window.matchMedia('(hover: hover)');

    function setup(gp) {
        gp.setAttribute('data-gp-ready', '');

        let o = {};

        try {
            o = JSON.parse(gp.getAttribute('data-gp') || '{}');
        } catch (e) {
            // keep the defaults
        }

        const grid = gp.querySelector(':scope > .gp-grid');

        if (!grid) {
            return;
        }

        const items = [...grid.children].filter((item) => item.classList.contains('gp-item'));
        const buttons = [...gp.querySelectorAll(':scope > .gp-toolbar .gp-filter-btn')];
        const input = gp.querySelector(':scope > .gp-toolbar .gp-search-input');
        const more = gp.querySelector(':scope > .gp-more');
        const empty = gp.querySelector(':scope > .gp-empty');
        const status = gp.querySelector(':scope > .gp-status');
        const words = new Map(items.map((item) => [item, `${item.textContent} ${item.getAttribute('data-tags') || ''}`.toLowerCase().replace(/\s+/g, ' ')]));
        const perPage = Math.max(0, Number(o.perPage) || 0);
        let filter = '';
        let query = '';
        let pages = 1;

        const carousel = () => gp.classList.contains('gp-carousel') && phone.matches;
        const masonry = () => o.layout === 'masonry' && !carousel();

        // Masonry: each item spans as many 4px rows as its card is tall, plus the gap.
        function layout() {
            if (!masonry()) {
                gp.classList.remove('gp-masonry-on');
                items.forEach((item) => (item.style.gridRowEnd = ''));
                return;
            }

            gp.classList.add('gp-masonry-on');
            const gap = parseFloat(getComputedStyle(grid).columnGap) || 0;

            items.forEach((item) => {
                if (!item.hidden && item.firstElementChild) {
                    item.style.gridRowEnd = `span ${Math.ceil((item.firstElementChild.getBoundingClientRect().height + gap) / 4)}`;
                }
            });
        }

        // Shows the items that match the filter and search, up to the pages loaded. Items
        // that stay slide to their new place; new ones fade in.
        function apply(animate, announce) {
            const motion = animate && !reduce && !carousel() && Element.prototype.animate;
            const before = new Map();

            if (motion) {
                items.forEach((item) => !item.hidden && before.set(item, item.getBoundingClientRect()));
            }

            const matching = items.filter((item) => (!filter || ` ${item.getAttribute('data-tags')} `.includes(` ${filter} `)) && (!query || words.get(item).includes(query)));
            const limit = perPage ? perPage * pages : Infinity;
            const shown = new Set(matching.slice(0, limit));

            items.forEach((item) => {
                item.hidden = !shown.has(item);
                item.classList.remove('gp-later');
            });

            layout();

            if (empty) {
                empty.hidden = matching.length > 0;
            }

            if (more) {
                more.hidden = matching.length <= limit;
            }

            if (announce && status && o.labels && o.labels.status) {
                status.textContent = o.labels.status.replace('%1', String(shown.size)).replace('%2', String(matching.length));
            }

            if (motion) {
                shown.forEach((item) => {
                    const from = before.get(item);
                    const to = item.getBoundingClientRect();

                    if (from) {
                        const dx = from.left - to.left;
                        const dy = from.top - to.top;

                        if (dx || dy) {
                            item.animate([{ transform: `translate(${dx}px, ${dy}px)` }, { transform: 'none' }], { duration: 450, easing: 'cubic-bezier(.2, .7, .3, 1)' });
                        }
                    } else {
                        item.animate([{ opacity: 0, transform: 'scale(.94)' }, { opacity: 1, transform: 'none' }], { duration: 400, easing: 'ease-out' });
                    }
                });
            }
        }

        buttons.forEach((button) => {
            button.addEventListener('click', () => {
                filter = button.getAttribute('data-filter') || '';
                buttons.forEach((other) => {
                    const active = other === button;
                    other.classList.toggle('is-active', active);
                    other.setAttribute('aria-pressed', String(active));

                    if (other.classList.contains('uk-button')) {
                        other.classList.toggle('uk-button-primary', active);
                        other.classList.toggle('uk-button-default', !active);
                    }
                });
                pages = 1;
                apply(true, true);
            });
        });

        if (input) {
            let timer = 0;
            input.addEventListener('input', () => {
                clearTimeout(timer);
                timer = setTimeout(() => {
                    query = input.value.trim().toLowerCase().replace(/\s+/g, ' ');
                    pages = 1;
                    apply(true, true);
                }, 150);
            });
        }

        more?.querySelector('button')?.addEventListener('click', () => {
            const first = items.filter((item) => !item.hidden).length;
            pages++;
            apply(true, true);

            // Keyboard users carry on from the first new item.
            const next = items.filter((item) => !item.hidden)[first];
            next?.querySelector('a, button')?.focus({ preventScroll: true });
        });

        // Tilt towards the pointer, for mice and trackpads only.
        if (gp.classList.contains('gp-tilt') && !reduce && hover.matches) {
            const lift = gp.classList.contains('gp-lift') ? ' translateY(-6px)' : '';

            items.forEach((item) => {
                const card = item.firstElementChild;

                card?.addEventListener('pointermove', (event) => {
                    const rect = card.getBoundingClientRect();
                    const x = (event.clientX - rect.left) / rect.width - 0.5;
                    const y = (event.clientY - rect.top) / rect.height - 0.5;
                    card.classList.add('is-tilting');
                    card.style.transform = `perspective(900px) rotateX(${(-y * 8).toFixed(2)}deg) rotateY(${(x * 8).toFixed(2)}deg)${lift}`;
                });
                card?.addEventListener('pointerleave', () => {
                    card.classList.remove('is-tilting');
                    card.style.transform = '';
                });
            });
        }

        let frame = 0;
        const schedule = () => {
            cancelAnimationFrame(frame);
            frame = requestAnimationFrame(layout);
        };

        // Images loading and width changes alter card heights.
        if ('ResizeObserver' in window) {
            const observer = new ResizeObserver(schedule);
            observer.observe(grid);
            items.forEach((item) => item.firstElementChild && observer.observe(item.firstElementChild));
        } else {
            window.addEventListener('resize', schedule);
        }

        phone.addEventListener?.('change', schedule);

        gp.classList.add('gp-ready');
        apply(false, false);
    }

    const init = (root) => root.querySelectorAll('.elemen-grid-pro:not([data-gp-ready])').forEach(setup);

    const boot = () => {
        init(document);

        // The YOOtheme builder preview replaces elements while editing.
        new MutationObserver(() => init(document)).observe(document.body, { childList: true, subtree: true });
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
