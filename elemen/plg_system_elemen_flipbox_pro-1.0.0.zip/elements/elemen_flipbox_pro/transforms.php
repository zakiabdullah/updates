<?php

/**
 * Builder transforms for Flip Box Pro.
 *
 * Flip Box Pro 0.3 held one box in the element itself. From 0.4 boxes are items;
 * when an older layout loads, its box becomes the first item, in a single column,
 * so the page looks the same and the editor shows the item.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

return [
    'preload' => static function (object $node): void {
        if (($node->type ?? '') !== 'elemen_flipbox_pro' || !empty($node->children)) {
            return;
        }

        $props = (array) ($node->props ?? []);
        $keys  = ['image', 'image_alt', 'icon', 'title', 'content', 'front_bg_image', 'back_title', 'back_content', 'back_bg_image', 'link', 'link_text'];
        $item  = array_filter(
            array_intersect_key($props, array_flip($keys)),
            static fn ($value): bool => $value !== '' && $value !== null && !is_array($value) && !is_object($value)
        );

        if (!$item) {
            return;
        }

        $node->props = array_diff_key($props, array_flip($keys));
        $node->props['grid_default'] = '1';
        $node->props['grid_small']   = '';
        $node->props['grid_medium']  = '';
        $node->props['grid_large']   = '';

        // Dynamic content mapped to the old fields moves along with them.
        $source = null;

        if (isset($node->source->props)) {
            $mapped = array_intersect_key((array) $node->source->props, array_flip($keys));

            if ($mapped) {
                // The item gets the same query, so the mapped fields keep resolving.
                $source = (object) (['props' => (object) $mapped] + array_diff_key((array) $node->source, ['props' => 1]));
                $node->source->props = (object) array_diff_key((array) $node->source->props, $mapped);
            }
        }

        $child = (object) ['type' => 'elemen_flipbox_pro_item', 'props' => $item];

        if ($source) {
            $child->source = $source;
        }

        $node->children = [$child];
    },
];
