<?php

/**
 * Flip Box Pro: a grid of boxes with a front and a back side.
 * Each item is rendered by elemen_flipbox_pro_item with this element's settings.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var \YOOtheme\Builder $builder
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<int, object> $children
 */

use Joomla\CMS\Uri\Uri;
use YOOtheme\Metadata;

use function YOOtheme\app;

\defined('_JEXEC') or die;

// Display options: fields of every item can be hidden without deleting them. Layouts saved
// before the options existed don't have them, so they count as shown.
$hidden = [];

foreach (['title' => ['title'], 'content' => ['content'], 'image' => ['image'], 'icon' => ['icon', 'icon_lucide'], 'back_title' => ['back_title'], 'back_content' => ['back_content'], 'back_list' => ['back_list'], 'link' => ['link', 'link_text']] as $option => $fields) {
    if (!($props["show_{$option}"] ?? true)) {
        array_push($hidden, ...$fields);
    }
}

foreach ($hidden ? $children : [] as $child) {
    foreach ($hidden as $field) {
        if (is_array($child->props ?? null)) {
            $child->props[$field] = '';
        } elseif (is_object($child->props ?? null)) {
            $child->props->{$field} = '';
        }
    }
}

$items = [];

foreach ($children as $i => $child) {
    $html = (string) $builder->render($child, ['element' => $props, 'index' => $i]);

    if (trim($html) !== '') {
        $items[] = $html;
    }
}

if (!$items) {
    return;
}

// Assets. The URL is worked out from this file's location, so it follows the plugin folder.
$assets   = \dirname(__DIR__) . '/assets';
$assetUrl = static fn (string $file): string => Uri::root(true) . '/'
    . str_replace('\\', '/', substr($assets, strlen(JPATH_ROOT) + 1)) . "/{$file}?v=" . @filemtime("{$assets}/{$file}");
$metadata = app(Metadata::class);

$metadata->set('style:elemen-flipbox-pro', ['href' => $assetUrl('flipbox-pro.css')]);
$metadata->set('script:elemen-flipbox-pro', ['src' => $assetUrl('flipbox-pro.js'), 'defer' => true]);

// Columns: "expand" shares the row equally, whatever the number of items.
$width = static fn ($value, string $breakpoint = ''): string => $value === '' || $value === null
    ? ''
    : ($value === 'expand' ? 'uk-child-width-expand' : "uk-child-width-1-{$value}") . $breakpoint;

$el = $this->el('div', [
    'class' => ['elemen-flipbox-pro-grid'],
]);

$grid = $this->el('div', [

    'class' => [
        $width($props['grid_default'] ?: '1'),
        $width($props['grid_small'], '@s'),
        $width($props['grid_medium'], '@m'),
        $width($props['grid_large'], '@l'),
        'uk-grid-column-{grid_column_gap}',
        'uk-grid-row-{grid_row_gap}',
        'uk-grid-match {@grid_match}',
    ],

    'uk-grid' => true,

]);

?>
<?= $el($props, $attrs) ?>
    <?= $grid($props) ?>
        <?php foreach ($items as $html) : ?>
        <div><?= $html ?></div>
        <?php endforeach ?>
    <?= $grid->end() ?>
<?= $el->end() ?>
