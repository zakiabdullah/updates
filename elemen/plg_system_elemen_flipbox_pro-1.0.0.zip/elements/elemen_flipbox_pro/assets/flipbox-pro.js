/* Elemen: Flip Box Pro — click/tap, the keyboard toggle button and the inert hidden side.
   Hover works with CSS alone. */
(() => {
    const touch = window.matchMedia('(hover: none)');
    const BOX = '.elemen-flipbox-pro';

    // The side turned away gets inert, so its links can't be reached with the keyboard.
    const sync = (box) => {
        const flipped = box.classList.contains('is-flipped');

        box.querySelector(':scope > .fb-inner > .fb-front')?.toggleAttribute('inert', flipped);
        box.querySelector(':scope > .fb-inner > .fb-back')?.toggleAttribute('inert', !flipped);
        box.querySelector(':scope > .fb-toggle')?.setAttribute('aria-pressed', String(flipped));
    };

    const toggle = (box, force) => {
        box.classList.toggle('is-flipped', force);
        sync(box);
    };

    // The toggle button shows (for keyboard and screen readers) once the script runs.
    const init = (box) => {
        if ('fbReady' in box.dataset) {
            return;
        }

        box.dataset.fbReady = '';
        box.querySelector(':scope > .fb-toggle')?.removeAttribute('hidden');
        sync(box);
    };

    const initAll = (root) => root.querySelectorAll(BOX).forEach(init);

    initAll(document);

    // Boxes added later, e.g. by the page builder preview.
    new MutationObserver((records) => records.forEach((record) => record.addedNodes.forEach((node) => {
        if (node.nodeType === 1) {
            node.matches(BOX) ? init(node) : initAll(node);
        }
    }))).observe(document.documentElement, { childList: true, subtree: true });

    document.addEventListener('click', (event) => {
        const button = event.target.closest('.fb-toggle');
        const box = event.target.closest(BOX);

        if (!box) {
            return;
        }

        init(box);

        if (button) {
            toggle(box);
            return;
        }

        if (event.target.closest('a, button, input, select, textarea, label')) {
            return;
        }

        // A click anywhere on the box turns it too. Hover boxes only need this on touch
        // screens, where there is no hover.
        if (box.classList.contains('fb-trigger-click') || touch.matches) {
            toggle(box);
        }
    });

    // Hover boxes: the side under the mouse is the one whose links can be clicked.
    document.addEventListener('pointerover', (event) => {
        const box = event.pointerType === 'mouse' && event.target.closest?.(`${BOX}.fb-trigger-hover`);

        if (box && !box.classList.contains('is-flipped')) {
            init(box);
            box.dataset.fbHover = '';
            toggle(box, true);
        }
    });

    document.addEventListener('pointerout', (event) => {
        const box = event.pointerType === 'mouse' && event.target.closest?.(`${BOX}.fb-trigger-hover`);

        if (box && 'fbHover' in box.dataset && !box.contains(event.relatedTarget)) {
            delete box.dataset.fbHover;
            toggle(box, false);
        }
    });

    document.addEventListener('keydown', (event) => {
        const open = event.key === 'Escape' && event.target.closest?.(`${BOX}.is-flipped`);

        if (open) {
            toggle(open, false);
            // Focus may have been on the back, which is inert now: move it to the button.
            open.querySelector(':scope > .fb-toggle')?.focus();
        }
    });
})();
