<?php

/**
 * Settings renamed in Flip Box Pro 1.0. Layouts saved with the old names load with the new
 * ones, dynamic content mappings included (see bootstrap.php).
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

return [
    'props' => [
        'front_text' => 'front_text_color',
        'back_text'  => 'back_text_color',
    ],
];
