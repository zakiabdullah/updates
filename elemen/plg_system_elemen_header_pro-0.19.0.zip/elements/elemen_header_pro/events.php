<?php

/**
 * Header Pro: the navbar as glass or a solid bar (full width or a floating capsule) while
 * it is sticky or always, pill or underline menu items, glass dropdowns and a divider
 * before the header modules. Set in the customizer under Header, after the sticky option.
 *
 * Nothing in YOOtheme's header markup changes. The settings become classes on <body> and
 * CSS custom properties; header-pro.css styles the navbar, its surface while UIkit marks
 * it sticky (.uk-navbar-sticky) or always. header-pro.js takes the colours from the
 * theme's own classes, so they follow the style chosen in the customizer, and switches
 * the menu text to light on dark tints.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

use Joomla\CMS\Document\HtmlDocument;
use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;
use YOOtheme\Config;
use YOOtheme\Event;
use YOOtheme\Metadata;

use function YOOtheme\app;

\defined('_JEXEC') or die;

if (!class_exists('ElemenHeaderPro', false)) {
    final class ElemenHeaderPro
    {
        public const STYLES = ['glass', 'solid'];

        public const MENUS = ['pill', 'underline'];

        public const TINTS = ['default', 'muted', 'primary', 'secondary'];

        public const RADIUS = ['pill' => '999px', 'large' => '24px', 'medium' => '14px', 'small' => '8px', 'none' => '0px'];

        /**
         * The customizer fields, keyed by their config path below ~theme.
         *
         * @return array<string, array<string, mixed>>
         */
        public static function fields(): array
        {
            $on      = 'elemen_header.style';
            $glass   = "elemen_header.style == 'glass'";
            $capsule = "elemen_header.style && elemen_header.shape == 'capsule'";

            return [
                'elemen_header.style' => [
                    'label'       => 'Header Pro Style',
                    'description' => 'A glass or solid navbar (Elemen Header Pro), while it is sticky or always. Glass blurs the page behind it.',
                    'type'        => 'select',
                    'options'     => ['None' => '', 'Glass' => 'glass', 'Solid' => 'solid'],
                ],
                'elemen_header.apply' => [
                    'label'       => 'Show',
                    'description' => 'While sticky needs a sticky navbar, set above.',
                    'type'        => 'select',
                    'options'     => ['While sticky' => 'sticky', 'Always' => 'always'],
                    'show'        => $on,
                ],
                'elemen_header.shape' => [
                    'label'   => 'Shape',
                    'type'    => 'select',
                    'options' => ['Full Width' => 'full', 'Capsule' => 'capsule'],
                    'show'    => $on,
                ],
                'elemen_header.tint' => [
                    'label'       => 'Tint',
                    'description' => 'Colour of the glass or bar, from the theme style. Menu text turns light on dark colours.',
                    'type'        => 'select',
                    'options'     => ['Background' => 'default', 'Muted' => 'muted', 'Primary' => 'primary', 'Secondary' => 'secondary'],
                    'show'        => $on,
                ],
                'elemen_header.opacity' => [
                    'label'  => 'Glass Opacity',
                    'type'   => 'range',
                    'attrs'  => ['min' => 0, 'max' => 100, 'step' => 5],
                    'show'   => $glass,
                ],
                'elemen_header.blur' => [
                    'label'       => 'Glass Blur',
                    'description' => 'Opacity in percent and blur in pixels.',
                    'type'        => 'range',
                    'attrs'       => ['min' => 0, 'max' => 40, 'step' => 1],
                    'show'        => $glass,
                ],
                'elemen_header.gap' => [
                    'label'       => 'Capsule Gap',
                    'description' => 'Space around the capsule, in pixels.',
                    'type'        => 'range',
                    'attrs'       => ['min' => 0, 'max' => 40, 'step' => 1],
                    'show'        => $capsule,
                ],
                'elemen_header.radius' => [
                    'label'   => 'Capsule Corners',
                    'type'    => 'select',
                    'options' => ['Pill' => 'pill', 'Large' => 'large', 'Medium' => 'medium', 'Small' => 'small', 'None' => 'none'],
                    'show'    => $capsule,
                ],
                'elemen_header.height' => [
                    'label'       => 'Sticky Height',
                    'description' => 'Navbar height while sticky, in pixels; the logo shrinks to fit. 0 keeps the height.',
                    'type'        => 'range',
                    'attrs'       => ['min' => 0, 'max' => 120, 'step' => 2],
                    'show'        => $on,
                ],
                'elemen_header.shadow' => [
                    'label' => 'Effects',
                    'type'  => 'checkbox',
                    'text'  => 'Add a shadow',
                    'show'  => $on,
                ],
                'elemen_header.border' => [
                    'type' => 'checkbox',
                    'text' => 'Add a border',
                    'show' => $on,
                ],
                'elemen_header.menu' => [
                    'label'       => 'Menu Style',
                    'description' => "Top-level menu items in the navbar. The active item takes the theme's primary colour.",
                    'type'        => 'select',
                    'options'     => ['Default' => '', 'Pill' => 'pill', 'Underline' => 'underline'],
                ],
                'elemen_header.dropdown' => [
                    'label'   => 'Dropdowns',
                    'type'    => 'select',
                    'options' => ['Default' => '', 'Glass' => 'glass'],
                ],
                'elemen_header.divider' => [
                    'type' => 'checkbox',
                    'text' => 'Add a divider between the menu and the modules after it',
                ],
                'elemen_header.mobile' => [
                    'description' => 'The mobile header gets the same look. If its own navbar is static (under Mobile), it becomes sticky like the navbar above.',
                    'type'        => 'checkbox',
                    'text'        => 'Apply to the mobile header',
                    'show'        => 'mobile.breakpoint',
                ],
            ];
        }

        /**
         * Body classes and CSS custom properties for the current settings, or null when off.
         * mobile_sticky: the sticky value for a static mobile navbar, or null to leave it.
         *
         * @param  array<string, mixed>  $theme  the ~theme config
         *
         * @return array{classes: list<string>, css: string, mobile_sticky: int|null}|null
         */
        public static function settings(array $theme): ?array
        {
            $s        = (array) ($theme['elemen_header'] ?? []);
            $style    = in_array($s['style'] ?? '', self::STYLES, true) ? $s['style'] : '';
            $menu     = in_array($s['menu'] ?? '', self::MENUS, true) ? $s['menu'] : '';
            $dropdown = ($s['dropdown'] ?? '') === 'glass';
            $divider  = !empty($s['divider']);
            $always   = $style !== '' && ($s['apply'] ?? '') === 'always';
            $extras   = $menu !== '' || $dropdown || $divider;

            $deskSticky   = (int) ($theme['navbar']['sticky'] ?? 0);
            $mobileSticky = (int) ($theme['mobile']['navbar']['sticky'] ?? 0);
            $hasMobile    = !empty($s['mobile']) && !empty($theme['mobile']['breakpoint']);

            // The surface shows always, or while the navbar is sticky.
            $desktop = $extras || ($style !== '' && ($always || $deskSticky));
            $mobile  = $hasMobile && ($extras || ($style !== '' && ($always || $mobileSticky || $deskSticky)));

            if (!$desktop && !$mobile) {
                return null;
            }

            $tint   = in_array($s['tint'] ?? '', self::TINTS, true) ? $s['tint'] : 'default';
            $height = max(0, min(200, (int) ($s['height'] ?? 0)));

            $classes = array_values(array_filter([
                'elemen-hp',
                $desktop ? 'elemen-hp--desktop' : '',
                $mobile ? 'elemen-hp--mobile' : '',
                $style !== '' ? "elemen-hp--$style" : '',
                $style !== '' ? "elemen-hp--tint-$tint" : '',
                $always ? 'elemen-hp--always' : '',
                $style !== '' && ($s['shape'] ?? '') === 'capsule' ? 'elemen-hp--capsule' : '',
                $style !== '' && $height ? 'elemen-hp--shrink' : '',
                $style !== '' && !empty($s['shadow']) ? 'elemen-hp--shadow' : '',
                $style !== '' && !empty($s['border']) ? 'elemen-hp--border' : '',
                $menu !== '' ? "elemen-hp--menu-$menu" : '',
                $dropdown ? 'elemen-hp--dropdown-glass' : '',
                $divider ? 'elemen-hp--divider' : '',
            ]));

            $vars = [
                '--ehp-opacity' => round(max(0, min(100, (int) ($s['opacity'] ?? 70))) / 100, 2),
                '--ehp-blur'    => max(0, min(60, (int) ($s['blur'] ?? 16))) . 'px',
                '--ehp-gap'     => max(0, min(60, (int) ($s['gap'] ?? 12))) . 'px',
                '--ehp-radius'  => self::RADIUS[$s['radius'] ?? 'pill'] ?? self::RADIUS['pill'],
                '--ehp-height'  => $height . 'px',
            ];

            $css = ':root{' . implode(';', array_map(static fn ($k, $v) => "$k:$v", array_keys($vars), $vars)) . '}';

            // A static mobile navbar follows the sticky desktop one, so the surface shows there
            // too while sticky.
            $follow = $mobile && $style !== '' && !$always && !$mobileSticky && $deskSticky ? $deskSticky : null;

            return ['classes' => $classes, 'css' => $css, 'mobile_sticky' => $follow];
        }

        public static function assetUrl(string $file): string
        {
            $assets = __DIR__ . '/assets';

            return Uri::root(true) . '/' . str_replace('\\', '/', substr($assets, strlen(JPATH_ROOT) + 1)) . "/{$file}?v=" . @filemtime("{$assets}/{$file}");
        }

        /** On the site, once Joomla has dispatched and YOOtheme has set its body classes. */
        public static function apply(): void
        {
            $app = Factory::getApplication();

            if (!$app->isClient('site') || !$app->getDocument() instanceof HtmlDocument) {
                return;
            }

            $config = app(Config::class);

            if (!$config->get('theme.active')) {
                return;
            }

            $settings = self::settings((array) $config->get('~theme'));

            if ($settings === null) {
                return;
            }

            $config->set('~theme.body_class', array_merge((array) $config->get('~theme.body_class', []), $settings['classes']));

            // Before the template renders the mobile header, which reads this.
            if ($settings['mobile_sticky'] !== null) {
                $config->set('~theme.mobile.navbar.sticky', $settings['mobile_sticky']);
            }

            $metadata = app(Metadata::class);
            $metadata->set('style:elemen-header-pro', ['href' => self::assetUrl('header-pro.css')]);
            // Inline CSS straight to Joomla: YOOtheme's Metadata passes only files and scripts
            // on to the Web Asset Manager, so an inline style there never reaches the page.
            $app->getDocument()->getWebAssetManager()->addInlineStyle($settings['css'], ['name' => 'elemen-header-pro-vars']);
            $metadata->set('script:elemen-header-pro', ['src' => self::assetUrl('header-pro.js'), 'defer' => true]);
        }
    }
}

// YOOtheme sets ~theme.body_class on onAfterDispatch (default priority, and it replaces
// the list); this runs afterwards and adds to it. Joomla runs higher priorities first.
Factory::getApplication()->getDispatcher()->addListener('onAfterDispatch', static function (): void {
    ElemenHeaderPro::apply();
}, -100);

// The customizer: the Header panel gets the fields right after its sticky option. Runs
// after YOOtheme has loaded the panels (priority 0) and before it sends them (-20).
Event::on('customizer.init', static function (): void {
    $config = app(Config::class);
    $fields = (array) $config->get('customizer.panels.header.fields');

    if (!$fields || isset($fields['elemen_header.style'])) {
        return;
    }

    $out = [];

    foreach ($fields as $name => $field) {
        $out[$name] = $field;

        if ($name === 'navbar.sticky') {
            $out += ElemenHeaderPro::fields();
        }
    }

    // Without the sticky option (another YOOtheme version), at the end of the panel.
    $config->set('customizer.panels.header.fields', $out + ElemenHeaderPro::fields());
}, -10);

return [];
