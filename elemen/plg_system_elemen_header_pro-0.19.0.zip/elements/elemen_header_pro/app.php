<?php

/**
 * Header Pro: defaults of its customizer settings, stored with the theme's own settings
 * under "elemen_header". Off by default, so installing changes nothing until chosen.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

return [
    'theme' => [
        'defaults' => [
            'elemen_header' => [
                'style'    => '',
                'apply'    => 'sticky',
                'menu'     => '',
                'dropdown' => '',
                'divider'  => false,
                'shape'    => 'full',
                'tint'     => 'default',
                'opacity'  => 70,
                'blur'     => 16,
                'gap'      => 12,
                'radius'   => 'pill',
                'height'   => 0,
                'shadow'   => true,
                'border'   => true,
                'mobile'   => true,
            ],
        ],
    ],
];
