<?php

// Copied from YOOtheme Pro 5.0.56 Headline element.

\defined('_JEXEC') or die;

// A Lucide icon from Icon Pro's "Lucide Icon" field, when Icon Pro is installed.
$lucide = static function ($name, int $size): string {
    $file = JPATH_PLUGINS . '/system/elemen_icon_pro/elements/elemen_icon_pro/icons/Icons.php';

    if (trim((string) $name) === '' || !is_file($file)) {
        return '';
    }

    require_once $file;

    return \Elemen\IconPro\Icons::svg((string) $name, ['size' => $size]);
};

$svg = $props['image'] ? '' : $lucide($props['icon_lucide'] ?? '', (int) ($props['image_width'] ?: 40));

if ($props['image']) {
    $src = $props['image'];
    $focal = $props['image_focal_point'];
    $media = include "{$__dir}/template-image.php";
} elseif ($svg) {
    $media = $this->el('span', ['class' => ['uk-text-{image_svg_color}']]);
} elseif ($props['icon']) {
    $media = include "{$__dir}/template-icon.php";
} else {
    return;
}

// Media
$media->attr([

    'class' => [
        'el-image',
        'uk-margin-{image_margin}-right {@image_align: left}',
        'uk-margin-{image_margin}-left {@image_align: right}',
    ],

]);

if ($props['image']) {

    $media->attr('class', [
        'uk-border-{image_border}',
    ]);

}

echo $media($props, $svg);
