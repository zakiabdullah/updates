<?php

/**
 * Heading Pro: YOOtheme Headline plus a highlighted part (second color, gradient,
 * outline or marker), a drawn SVG shape or rotating words, a kicker and background text.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var string $__dir
 */

use Joomla\CMS\Uri\Uri;
use YOOtheme\Metadata;

use function YOOtheme\app;

\defined('_JEXEC') or die;

$text = static fn ($value): string => trim((string) $value);

$before    = $text($props['content'] ?? '');
$highlight = $text($props['highlight'] ?? '');
$after     = $text($props['content_after'] ?? '');
$animation = $props['highlight_animation'] ?? '';

// Rotating words: the highlighted text first, then one word or phrase per line.
$words = [];

if ($animation === 'rotate') {
    $lines = preg_split('/\R/', (string) ($props['rotate_words'] ?? '')) ?: [];
    $words = array_values(array_filter(array_map($text, array_merge([$highlight], $lines)), 'strlen'));

    if (count($words) < 2) {
        $animation = '';
    }
}

if ($before === '' && $highlight === '' && $after === '' && !$words) {
    return;
}

// Assets: CSS always, JS only for the animations. Loaded once per page.
// The URL is worked out from this file's location, so it follows the plugin folder.
$assets   = \dirname(__DIR__) . '/assets';
$assetUrl = static fn (string $file): string => Uri::root(true) . '/'
    . str_replace('\\', '/', substr($assets, strlen(JPATH_ROOT) + 1)) . "/{$file}?v=" . @filemtime("{$assets}/{$file}");
$metadata = app(Metadata::class);

$metadata->set('style:elemen-heading-pro', ['href' => $assetUrl('heading-pro.css')]);

if ($animation !== '' || $props['text_reveal']) {
    $metadata->set('script:elemen-heading-pro', ['src' => $assetUrl('heading-pro.js'), 'defer' => true]);
}

// CSS custom properties for the highlight; colors come from the color pickers.
$vars = [];

$addVar = static function (string $name, $value) use (&$vars): void {
    $value = trim((string) $value);

    // Color pickers give hex, rgb(a), hsl(a) or a CSS variable; refuse anything that
    // could break out of the style attribute.
    if ($value !== '' && !preg_match('/[;{}<>"]/', $value)) {
        $vars[] = "--hp-{$name}: {$value}";
    }
};

if (($props['highlight_color'] ?? '') === 'custom') {
    $addVar('color', $props['highlight_color_custom'] ?? '');
}

$addVar('from', $props['highlight_gradient_start'] ?? '');
$addVar('to', $props['highlight_gradient_end'] ?? '');
$addVar('marker', $props['highlight_marker_color'] ?? '');

if ($animation === 'draw') {
    $addVar('shape-color', $props['shape_color'] ?? '');
    $addVar('shape-width', ((int) ($props['shape_width'] ?: 6)) . 'px');
    $addVar('duration', ((int) ($props['shape_duration'] ?: 1200)) . 'ms');
}

$highlightColor = $props['highlight_color'] ?? '';
$effect         = $animation === 'rotate' ? ($props['rotate_effect'] ?: 'typewriter') : '';
$shape          = $props['shape'] ?: 'underline';

$highlightEl = $this->el('span', [

    'class' => [
        'el-highlight hp-highlight',
        'uk-text-{0}' => !in_array($highlightColor, ['', 'custom'], true) ? $highlightColor : '',
        'hp-color-custom' => $highlightColor === 'custom',
        'uk-font-{highlight_font_family}',
        'hp-effect-{highlight_effect}',
        'hp-italic {@highlight_italic}',
        'hp-draw hp-shape-{0}' => $animation === 'draw' ? $shape : '',
        'hp-rotate hp-rotate-{0}' => $effect,
        'hp-cursor' => $effect === 'typewriter' && $props['rotate_cursor'],
    ],

    'style' => $vars ? implode('; ', $vars) : false,

    'data-hp-anim'   => $animation ?: false,
    'data-hp-repeat' => $animation === 'draw' && $props['shape_repeat'] ? 'true' : false,
    'data-hp-effect' => $effect ?: false,
    'data-hp-delay'  => $effect ? (int) ($props['rotate_delay'] ?: 2500) : false,
    'data-hp-speed'  => $effect === 'typewriter' ? (int) ($props['rotate_speed'] ?: 80) : false,
    'data-hp-loop'   => $effect ? ($props['rotate_loop'] ? 'true' : 'false') : false,

]);

// SVG paths in a 500×150 box stretched over the highlighted text. pathLength="1"
// lets the CSS draw every shape with the same dash values.
$shapes = [
    'underline' => ['M5 138 Q250 122 495 136'],
    'curly'     => ['M5 136 Q22 120 40 136 T75 136 T110 136 T145 136 T180 136 T215 136 T250 136 T285 136 T320 136 T355 136 T390 136 T425 136 T460 136 T495 136'],
    'double'    => ['M5 128 Q250 116 495 128', 'M30 146 Q250 136 470 146'],
    'zigzag'    => ['M5 138 L35 124 L65 138 L95 124 L125 138 L155 124 L185 138 L215 124 L245 138 L275 124 L305 138 L335 124 L365 138 L395 124 L425 138 L455 124 L495 138'],
    'circle'    => ['M262 10 C420 8 496 42 494 80 C492 122 380 146 248 144 C110 142 6 120 6 78 C6 36 96 12 214 9 C268 8 330 12 372 22'],
    'strike'    => ['M5 80 Q250 68 495 78'],
    'cross'     => ['M8 12 L492 140', 'M8 140 L492 12'],
];

$svg = '';

if ($animation === 'draw') {
    $paths = '';

    foreach ($shapes[$shape] ?? $shapes['underline'] as $d) {
        $paths .= '<path d="' . $d . '" pathLength="1" vector-effect="non-scaling-stroke"/>';
    }

    $svg = '<svg class="hp-shape" viewBox="0 0 500 150" preserveAspectRatio="none" aria-hidden="true" focusable="false">' . $paths . '</svg>';
}

// Words in {braces} in the text before or after become extra highlights. A phrase can
// override its theme colour and effect as {word|primary|marker}; otherwise it inherits the
// main highlight style and drawn shape. Rotating words stay on the main highlight only.
$view   = $this;
$braces = static function (string $text) use ($view, $props, $highlightColor, $animation, $shape, $vars, $svg): string {
    $allowedColors  = ['', 'muted', 'emphasis', 'primary', 'secondary', 'success', 'warning', 'danger'];
    $allowedEffects = ['', 'gradient', 'gradient-animated', 'outline', 'marker'];

    return (string) preg_replace_callback(
        '/\{([^{}|]+)(?:\|([^{}|]*)(?:\|([^{}|]*))?)?\}/u',
        static function (array $match) use ($view, $props, $highlightColor, $animation, $shape, $vars, $svg, $allowedColors, $allowedEffects): string {
            $hasStyle = str_contains($match[0], '|');

            if ($hasStyle) {
                $color  = trim((string) ($match[2] ?? ''));
                $effect = trim((string) ($match[3] ?? ''));
                $hasStyle = in_array($color, $allowedColors, true) && in_array($effect, $allowedEffects, true);
            }

            if ($hasStyle) {
                $classes = ['el-highlight hp-highlight hp-extra-highlight', 'uk-font-{highlight_font_family}', 'hp-italic {@highlight_italic}'];

                if ($color !== '') {
                    $classes[] = 'uk-text-' . $color;
                }

                if ($effect !== '') {
                    $classes[] = 'hp-effect-' . $effect;
                }

                $style = $vars ? implode('; ', $vars) : false;
                $draw  = false;
            } else {
                $classes = [
                    'el-highlight hp-highlight',
                    'uk-text-{0}' => !in_array($highlightColor, ['', 'custom'], true) ? $highlightColor : '',
                    'hp-color-custom' => $highlightColor === 'custom',
                    'uk-font-{highlight_font_family}',
                    'hp-effect-{highlight_effect}',
                    'hp-italic {@highlight_italic}',
                    'hp-draw hp-shape-{0}' => $animation === 'draw' ? $shape : '',
                ];
                $style = $vars ? implode('; ', $vars) : false;
                $draw  = $animation === 'draw';
            }

            $extra = $view->el('span', [
                'class'          => $classes,
                'style'          => $style,
                'data-hp-anim'   => $draw ? 'draw' : false,
                'data-hp-repeat' => $draw && $props['shape_repeat'] ? 'true' : false,
            ]);

            return $extra($props) . '<span class="hp-text">' . $match[1] . '</span>' . ($draw ? $svg : '') . $extra->end();
        },
        $text
    );
};

$before = $braces($before);
$after  = $braces($after);

// Highlight markup.
$highlightHtml = '';

if ($words) {
    $spans = '';

    foreach ($words as $i => $word) {
        $spans .= '<span class="hp-word' . ($i === 0 ? ' is-active' : '') . '">' . $word . '</span>';
    }

    // Screen readers and search engines get the first word; the animation is decoration.
    $highlightHtml = $highlightEl($props)
        . '<span class="uk-hidden-visually">' . strip_tags($words[0]) . '</span>'
        . '<span class="hp-words" aria-hidden="true">' . $spans . '</span>'
        . $highlightEl->end();
} elseif ($highlight !== '') {
    $highlightHtml = $highlightEl($props) . '<span class="hp-text">' . $highlight . '</span>' . $svg . $highlightEl->end();
}

$parts = array_filter([$before, $highlightHtml, $after], 'strlen');

if ($highlightHtml !== '' && $props['highlight_newline'] && $before !== '') {
    $props['content'] = $before . '<br>' . implode(' ', array_slice($parts, 1));
} else {
    $props['content'] = implode(' ', $parts);
}

// Wrapper: holds the kicker, the heading and the background text.
$el = $this->el('div', [

    'class' => [
        'elemen-heading-pro',
        'hp-has-watermark' => $text($props['watermark'] ?? '') !== '',
    ],

]);

// Heading, as in YOOtheme's Headline element.
$title = $this->el($props['title_element'] ?: 'h2', [

    'class' => [
        'el-title hp-title',
        'uk-{title_style}',
        'uk-text-stroke {@title_text_stroke}',
        'uk-heading-{title_decoration}',
        'uk-font-{title_font_family}',
        'uk-text-{title_color} {@!title_color: background}',
        'uk-margin-remove',
        'hp-reveal hp-reveal-{text_reveal_effect} {@text_reveal}',
        'hp-preset-{text_reveal_preset} {@text_reveal}',
    ],

    // Text reveal: the script splits the text and shows the parts one after the other.
    'data-hp-reveal'        => $props['text_reveal'] ?: false,
    'data-hp-reveal-repeat' => $props['text_reveal'] && $props['text_reveal_repeat'] ? 'true' : false,
    'style'                 => $props['text_reveal'] && ($props['text_reveal_preset'] ?? 'custom') === 'custom'
        ? sprintf('--hp-reveal-stagger: %dms; --hp-reveal-duration: %dms', (int) ($props['text_reveal_stagger'] ?: 60), (int) ($props['text_reveal_duration'] ?: 700))
        : false,

]);

// Image or icon
$props['image'] = $this->render("{$__dir}/template-media", compact('props'));

if ($props['image']) {
    $props['content'] = $this->el('span', ['class' => ['uk-text-middle']], $props['content'])->render($props);
}

$container = $props['title_color'] == 'background' || $props['title_decoration'] == 'line' ? $this->el('span', [

    'class' => [
        'uk-text-background {@title_color: background}',
    ],

]) : null;

$link = $props['link'] ? $this->el('a', [

    'class' => [
        'el-link',
        'uk-link-{0}' => $props['link_style'] ? 'heading' : 'reset',
    ],

    'href'     => ['{link}'],
    'target'   => ['_blank {@link_target}'],
    'download' => $props['link_download'],
    'rel'      => [
        'nofollow {@link_rel_nofollow}',
        'noreferrer {@link_rel_noreferrer}',
    ],
    'uk-scroll' => str_contains((string) $props['link'], '#'),

]) : null;

// Kicker
$kicker       = $text($props['kicker'] ?? '');
$kickerAbove  = ($props['kicker_position'] ?? 'above') !== 'below';
$kickerMargin = $props['kicker_margin'] ?: 'small';
$kickerSide   = $kickerAbove ? 'bottom' : 'top';

$kickerEl = $kicker !== '' ? $this->el('div', [

    'class' => [
        'el-meta hp-kicker',
        'uk-{kicker_style}',
        'uk-text-{kicker_color}',
        'uk-text-uppercase {@kicker_uppercase}',
        $kickerMargin === 'remove' ? 'uk-margin-remove' : 'uk-margin-remove-' . ($kickerAbove ? 'top' : 'bottom'),
        $kickerMargin === 'remove' ? '' : ($kickerMargin === 'default' ? "uk-margin-{$kickerSide}" : "uk-margin-{$kickerMargin}-{$kickerSide}"),
    ],

]) : null;

// Background text
$watermark   = $text($props['watermark'] ?? '');
$watermarkEl = null;

if ($watermark !== '') {
    $style   = [];
    $opacity = (float) ($props['watermark_opacity'] ?: 0.08);
    $style[] = '--hp-wm-opacity: ' . max(0.01, min(1, $opacity));
    $style[] = '--hp-wm-opacity-percent: ' . (max(1, min(100, $opacity * 100))) . '%';
    $color   = trim((string) ($props['watermark_color'] ?? ''));

    if ($color !== '' && !preg_match('/[;{}<>"]/', $color)) {
        $style[] = 'color: ' . $color;
    }

    $watermarkEl = $this->el('div', [

        'class' => [
            'hp-watermark',
            'uk-{watermark_style}',
            'uk-text-{watermark_align}',
            'hp-watermark-outline {@watermark_outline}',
            'hp-watermark-{watermark_depth} {@watermark_depth}',
            'hp-watermark-depth-{watermark_depth_strength} {@watermark_depth}',
            'hp-watermark-effect-{watermark_effect} {@watermark_effect}',
        ],

        'style'       => implode('; ', $style),
        'aria-hidden' => 'true',

    ]);
}

?>
<?= $el($props, $attrs) ?>

    <?php if ($watermarkEl) : ?>
    <?= $watermarkEl($props) ?><?= $watermark ?><?= $watermarkEl->end() ?>
    <?php endif ?>

    <?php if ($kickerEl && $kickerAbove) : ?>
    <?= $kickerEl($props) ?><?= $kicker ?><?= $kickerEl->end() ?>
    <?php endif ?>

    <?= $title($props) ?>

        <?php if ($container) : ?>
        <?= $container($props) ?>
        <?php endif ?>

            <?php if ($link) : ?>
            <?= $link($props) ?>
            <?php endif ?>

            <?php if ($props['image'] && $props['image_align'] == 'right') : ?>
                <?= $props['content'] ?><?= $props['image'] ?>
            <?php elseif ($props['image']) : ?>
                <?= $props['image'] ?><?= $props['content'] ?>
            <?php else : ?>
                <?= $props['content'] ?>
            <?php endif ?>

            <?php if ($link) : ?>
            <?= $link->end() ?>
            <?php endif ?>

        <?php if ($container) : ?>
        <?= $container->end() ?>
        <?php endif ?>

    <?= $title->end() ?>

    <?php if ($kickerEl && !$kickerAbove) : ?>
    <?= $kickerEl($props) ?><?= $kicker ?><?= $kickerEl->end() ?>
    <?php endif ?>

<?= $el->end() ?>
