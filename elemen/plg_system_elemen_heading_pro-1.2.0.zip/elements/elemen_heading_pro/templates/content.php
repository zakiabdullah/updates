<?php

/**
 * Plain HTML stored in the article text, used by search and when the builder is off.
 *
 * @var array<string, mixed> $props
 */

\defined('_JEXEC') or die;

$tag   = $props['title_element'] ?: 'h2';
// {braces} mark extra highlights; search and plain text get the words without them.
$parts = array_filter(array_map(static fn ($text) => trim(preg_replace('/\{([^{}|]+)(?:\|[^{}]+)?\}/u', '$1', (string) $text)), [
    (string) ($props['content'] ?? ''),
    (string) ($props['highlight'] ?? ''),
    (string) ($props['content_after'] ?? ''),
]), 'strlen');

?>
<?php if ($props['kicker'] ?? '') : ?>
<p><?= $props['kicker'] ?></p>
<?php endif ?>
<?php if ($parts) : ?>
<<?= $tag ?>><?php if ($props['link']) : ?><a href="<?= htmlspecialchars((string) $props['link'], ENT_QUOTES) ?>"><?= implode(' ', $parts) ?></a><?php else : ?><?= implode(' ', $parts) ?><?php endif ?></<?= $tag ?>>
<?php endif ?>
