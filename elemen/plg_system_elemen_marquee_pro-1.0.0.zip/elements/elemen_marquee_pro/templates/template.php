<?php

/**
 * Marquee Pro: items scrolling without end in one or two rows.
 *
 * The page holds every item once; the script copies the row as often as needed to fill
 * the width and moves it with the Web Animations API. Without JavaScript, or for visitors
 * who prefer less motion, the row stays still and scrolls sideways by hand.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var \YOOtheme\Builder $builder
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<int, object> $children
 */

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;
use YOOtheme\Metadata;

use function YOOtheme\app;

\defined('_JEXEC') or die;

$items = [];

foreach ($children as $i => $child) {
    $html = (string) $builder->render($child, ['element' => $props, 'index' => $i]);

    if (trim($html) !== '') {
        $items[] = $html;
    }
}

if (!$items) {
    return;
}

$assets   = \dirname(__DIR__) . '/assets';
$assetUrl = static fn (string $file): string => Uri::root(true) . '/'
    . str_replace('\\', '/', substr($assets, strlen(JPATH_ROOT) + 1)) . "/{$file}?v=" . @filemtime("{$assets}/{$file}");
$metadata = app(Metadata::class);

$metadata->set('style:elemen-marquee-pro', ['href' => $assetUrl('marquee-pro.css')]);
$metadata->set('script:elemen-marquee-pro', ['src' => $assetUrl('marquee-pro.js'), 'defer' => true]);

$color = static fn ($value): string => preg_match('/^[#(),.%\w\s-]+$/', trim((string) $value)) ? trim((string) $value) : '';

// A Lucide icon from Icon Pro's "Lucide Icon" field, when Icon Pro is installed.
$lucide = static function ($name, int $size): string {
    $file = JPATH_PLUGINS . '/system/elemen_icon_pro/elements/elemen_icon_pro/icons/Icons.php';

    if (trim((string) $name) === '' || !is_file($file)) {
        return '';
    }

    require_once $file;

    return \Elemen\IconPro\Icons::svg((string) $name, ['size' => $size]);
};

// Separator between items, also after the last one so the loop stays even.
$separator = match ($props['separator']) {
    'dot'   => '<span class="mq-sep" aria-hidden="true">•</span>',
    'star'  => '<span class="mq-sep" aria-hidden="true">✦</span>',
    'slash' => '<span class="mq-sep" aria-hidden="true">/</span>',
    'icon'  => ($svg = $lucide($props['separator_icon_lucide'] ?? '', 20)) ? '<span class="mq-sep" aria-hidden="true">' . $svg . '</span>' : ($props['separator_icon'] ? '<span class="mq-sep" aria-hidden="true" uk-icon="icon: ' . htmlspecialchars((string) $props['separator_icon']) . '"></span>' : ''),
    default => '',
};

// Rows: two rows go opposite ways, with half of the items each when split.
$first = $props['direction'] === 'right' ? 'right' : 'left';
$rows  = [[$first, $items]];

if ((string) $props['rows'] === '2') {
    $second = $first === 'left' ? 'right' : 'left';

    if ($props['split'] && count($items) > 1) {
        $half = (int) ceil(count($items) / 2);
        $rows = [[$first, array_slice($items, 0, $half)], [$second, array_slice($items, $half)]];
    } else {
        $rows[] = [$second, $items];
    }
}

$tilt = max(-8, min(8, (float) $props['tilt']));
$vars = [
    '--mq-image-h: ' . max(8, (int) ($props['image_height'] ?: 40)) . 'px',
    '--mq-fade: ' . max(1, min(40, (int) ($props['fade_width'] ?: 10))) . '%',
];

if ($tilt) {
    $vars[] = "--mq-tilt: {$tilt}deg";
    $vars[] = '--mq-tilt-abs: ' . abs($tilt);
}

if ($props['band'] === 'custom' && $color($props['band_color'])) {
    $vars[] = 'background-color: ' . $color($props['band_color']);
}

$options = [
    'speed' => max(5, (int) ($props['speed'] ?: 50)),
    'hover' => (string) $props['hover'],
];

Factory::getApplication()->getLanguage()->load('plg_system_elemen_marquee_pro', JPATH_ADMINISTRATOR);
// One fixed name; aria-pressed tells screen readers whether the animation is paused.
$pauseLabel = Text::_('PLG_SYSTEM_ELEMEN_MARQUEE_PRO_PAUSE');

$el = $this->el('div', [

    'class' => [
        'elemen-marquee-pro mq',
        'mq-gap-{gap}',
        'mq-fade {@fade}',
        'mq-grayscale {@grayscale}',
        'mq-item-{item_style} {@item_style}',
        'mq-uppercase {@uppercase}',
        'mq-tilted' => (bool) $tilt,
        'mq-band' => (bool) $props['band'],
        'uk-background-{band}' => in_array($props['band'], ['primary', 'secondary', 'muted'], true),
        'uk-light' => in_array($props['band'], ['primary', 'secondary'], true),
    ],

    'style'   => implode('; ', $vars),
    'data-mq' => json_encode($options),

]);

?>
<?= $el($props, $attrs) ?>

    <?php foreach ($rows as [$direction, $rowItems]) : ?>
    <div class="mq-row" data-dir="<?= $direction ?>">
        <div class="mq-track">
            <div class="mq-group">
                <?php foreach ($rowItems as $html) : ?>
                <?= $html ?><?= $separator ?>

                <?php endforeach ?>
            </div>
        </div>
    </div>
    <?php endforeach ?>

    <?php if ($props['pause_button']) : ?>
    <button type="button" class="mq-toggle" aria-pressed="false" aria-label="<?= htmlspecialchars($pauseLabel, ENT_QUOTES) ?>" hidden></button>
    <?php endif ?>

<?= $el->end() ?>
