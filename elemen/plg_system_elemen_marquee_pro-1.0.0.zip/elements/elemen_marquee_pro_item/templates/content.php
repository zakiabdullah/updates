<?php

/**
 * Plain HTML stored in the article text, used by search and when the builder is off.
 *
 * @var array<string, mixed> $props
 */

\defined('_JEXEC') or die;

?>
<?php if ($props['link'] && $props['text']) : ?>
<a href="<?= $props['link'] ?>"><?= $props['text'] ?></a>
<?php elseif ($props['text']) : ?>
<?= $props['text'] ?>
<?php endif ?>
