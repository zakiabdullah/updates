<?php

/**
 * Builder transforms for Animated Background Pro.
 *
 * prerender (section): a section with an effect or grain gets a layer node as its first child, so
 * it renders inside the section like any other child. The node exists only while
 * rendering; the saved layout is never changed. Auto colors are resolved here, where the
 * section's style is known.
 *
 * render: runs after YOOtheme's element transform, so the section keeps its own classes
 * and gains the class the layer styles hang on. It also moves the layer before any nodes
 * other plugins added at the start (Shape Dividers), so those stay above the animation.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

$effects = ['aurora', 'gradient', 'waves', 'pattern', 'shapes'];

$effectOf = static function (object $node) use ($effects): string {
    $effect = (string) (((array) ($node->props ?? []))['elemen_bg_effect'] ?? '');

    return ($node->type ?? '') === 'section' && in_array($effect, $effects, true) ? $effect : '';
};

// A layer is shown for an effect, or for grain alone.
$shows = static fn (object $node): bool => ($node->type ?? '') === 'section'
    && ($effectOf($node) !== '' || !empty(((array) ($node->props ?? []))['elemen_bg_grain']));

return [
    'prerender' => static function (object $node) use ($effectOf, $shows): void {
        if (!$shows($node)) {
            return;
        }

        $effect = $effectOf($node);

        $props = (array) $node->props;
        $style = (string) ($props['style'] ?? '');

        $values = [
            'effect'    => $effect,
            'colors'    => (string) ($props['elemen_bg_colors'] ?? ''),
            'intensity' => (string) ($props['elemen_bg_intensity'] ?? ''),
            'speed'     => (string) ($props['elemen_bg_speed'] ?? ''),
            // Auto colors depend on the section's own style.
            'style'     => $style,
            'pattern'   => (string) ($props['elemen_bg_pattern'] ?? ''),
            'size'      => $props['elemen_bg_pattern_size'] ?? '',
            'edges'     => !empty($props['elemen_bg_pattern_edges']),
            'shapes'    => (string) ($props['elemen_bg_shapes'] ?? ''),
            'count'     => (string) ($props['elemen_bg_shapes_count'] ?? ''),
            'grain'     => !empty($props['elemen_bg_grain']),
            // Floating shapes are placed from this: the same section always looks the
            // same, and sections with other settings or content look different.
            'seed'      => crc32(json_encode([$props, $node->children ?? []]) ?: ''),
        ];

        foreach ([1, 2, 3] as $n) {
            $values["color_$n"] = (string) ($props["elemen_bg_color_$n"] ?? '');
        }

        $layer = (object) ['type' => 'elemen_background_pro_layer', 'props' => $values];

        $node->children = array_merge([$layer], (array) ($node->children ?? []));
    },

    'render' => static function (object $node) use ($shows): void {
        if (!$shows($node)) {
            return;
        }

        $node->attrs['class'][] = 'elemen-bg-section';

        // The layer goes first, before nodes other plugins put at the start in their own
        // prerender (e.g. Shape Dividers), so those paint above the animation.
        $children = (array) ($node->children ?? []);
        $isLayer  = static fn ($child): bool => is_object($child) && ($child->type ?? '') === 'elemen_background_pro_layer';

        $node->children = array_merge(array_values(array_filter($children, $isLayer)), array_values(array_filter($children, static fn ($child): bool => !$isLayer($child))));
    },
];
