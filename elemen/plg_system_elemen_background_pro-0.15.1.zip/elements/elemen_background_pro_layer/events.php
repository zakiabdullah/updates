<?php

/**
 * Adds Animated Background settings to YOOtheme's Section element in the builder: a button
 * in the Settings tab opens an Animated Background panel.
 *
 * The type is extended when the editor loads its configuration, so saved layouts and the
 * core element files stay untouched. Field names start with "elemen_bg_" so they never
 * clash with YOOtheme's own options.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

return [
    'builder.type' => static function (array $type): array {
        $element = (string) ($type['name'] ?? '');
        $panel   = "elemen-bg-$element";

        if ($element !== 'section' || isset($type['panels'][$panel])) {
            return $type;
        }

        $on = 'elemen_bg_effect';

        $fields = [
            'elemen_bg_effect' => [
                'label'       => 'Effect',
                'description' => 'An animated layer behind the content of the section, over its background color or image.',
                'type'        => 'select',
                'options'     => [
                    'None'          => '',
                    'Aurora'         => 'aurora',
                    'Gradient Flow'  => 'gradient',
                    'Waves'          => 'waves',
                    'Moving Pattern' => 'pattern',
                    'Floating Shapes' => 'shapes',
                ],
            ],
            'elemen_bg_shapes' => [
                'label'       => 'Shapes',
                'description' => 'Shapes rising slowly from the bottom to the top, with their own sizes, speeds and turns.',
                'type'        => 'select',
                'options'     => [
                    'Mixed'           => '',
                    'Circles'         => 'circle',
                    'Rounded Squares' => 'square',
                    'Rings'           => 'ring',
                    'Triangles'       => 'triangle',
                ],
                'show' => "elemen_bg_effect == 'shapes'",
            ],
            'elemen_bg_shapes_count' => [
                'label'   => 'Number of Shapes',
                'type'    => 'select',
                'options' => ['Few (8)' => 'few', 'Some (14)' => '', 'Many (22)' => 'many'],
                'show'    => "elemen_bg_effect == 'shapes'",
            ],
            'elemen_bg_pattern' => [
                'label'       => 'Pattern',
                'description' => 'Fine lines or dots drifting slowly, drawn in the first color (Auto: the primary color, or the text color on dark sections).',
                'type'        => 'select',
                'options'     => [
                    'Grid'           => '',
                    'Dots'           => 'dots',
                    'Diagonal Lines' => 'lines',
                ],
                'show' => "elemen_bg_effect == 'pattern'",
            ],
            'elemen_bg_pattern_size' => [
                'label'       => 'Pattern Size',
                'description' => 'The distance between lines or dots, in pixels. Empty: 40 for the grid, 24 for dots, 20 for lines.',
                'type'        => 'range',
                'attrs'       => ['type' => 'number', 'min' => 8, 'max' => 120, 'step' => 2],
                'show'        => "elemen_bg_effect == 'pattern'",
            ],
            'elemen_bg_pattern_edges' => [
                'type' => 'checkbox',
                'text' => 'Show the pattern up to the edges (instead of fading it out)',
                'show' => "elemen_bg_effect == 'pattern'",
            ],
            'elemen_bg_colors' => [
                'label'       => 'Colors',
                'description' => 'Auto uses the theme\'s primary color, and light glows on Primary and Secondary sections, so it fits any brand.',
                'type'        => 'select',
                'options'     => [
                    'Auto (theme colors)' => '',
                    'Corporate'           => 'corporate',
                    'Vibrant'             => 'vibrant',
                    'Custom'              => 'custom',
                ],
                'show' => $on,
            ],
            'elemen_bg_color_1' => [
                'label' => 'Color 1',
                'type'  => 'color',
                'show'  => "$on && elemen_bg_colors == 'custom'",
            ],
            'elemen_bg_color_2' => [
                'label' => 'Color 2',
                'type'  => 'color',
                'show'  => "$on && elemen_bg_colors == 'custom'",
            ],
            'elemen_bg_color_3' => [
                'label'       => 'Color 3',
                'description' => 'Optional. Empty colors are left out.',
                'type'        => 'color',
                'show'        => "$on && elemen_bg_colors == 'custom'",
            ],
            'elemen_bg_intensity' => [
                'label'       => 'Intensity',
                'description' => 'How strongly the colors show. Subtle keeps text easy to read.',
                'type'        => 'select',
                'options'     => ['Subtle' => '', 'Medium' => 'medium', 'Strong' => 'strong'],
                'show'        => $on,
            ],
            'elemen_bg_speed' => [
                'label'       => 'Speed',
                'description' => 'Still shows the effect without movement. Visitors who prefer reduced motion always see it still, and the animation pauses while the section is off screen.',
                'type'        => 'select',
                'options'     => ['Slow' => '', 'Medium' => 'medium', 'Fast' => 'fast', 'Still' => 'still'],
                'show'        => $on,
            ],
            'elemen_bg_grain' => [
                'label'       => 'Grain',
                'description' => 'A still, fine film grain over the section background, with or without an effect. It gives flat colors and gradients a little depth.',
                'type'        => 'checkbox',
                'text'        => 'Add a grain texture',
            ],
        ];

        // Own panel, opened from the Settings tab like YOOtheme's Image/Video and Parallax
        // panels, so the section keeps its tabs and nothing crowds the tab bar.
        $type['panels'][$panel] = [
            'title'    => 'Animated Background',
            'width'    => 500,
            'fields'   => $fields,
            'fieldset' => ['default' => ['fields' => array_keys($fields)]],
        ];

        $type['fields']['_elemen_bg_button'] = [
            'label'       => 'Animated Background',
            'description' => 'Add a slow, animated layer behind the content, e.g. soft aurora lights or a flowing gradient.',
            'type'        => 'button-panel',
            'text'        => 'Edit Settings',
            'panel'       => $panel,
        ];

        // In the Settings tab after the background options (and Shape Divider, when that
        // plugin added its button first), else at its end.
        foreach ($type['fieldset']['default']['fields'] ?? [] as $i => $tab) {
            if (!is_array($tab) || ($tab['title'] ?? '') !== 'Settings' || !is_array($tab['fields'] ?? null)) {
                continue;
            }

            $list = $tab['fields'];
            $at   = array_search('_elemen_shape_button', $list, true);
            $at   = $at === false ? array_search('_background_parallax_button', $list, true) : $at;
            $at   = $at === false ? array_search('background_color', $list, true) : $at;
            $at   = $at === false ? count($list) : $at + 1;

            while (isset($list[$at]) && is_string($list[$at]) && empty($type['fields'][$list[$at]]['label'])) {
                $at++;
            }

            array_splice($list, $at, 0, ['_elemen_bg_button']);
            $type['fieldset']['default']['fields'][$i]['fields'] = $list;
            break;
        }

        return $type;
    },
];
