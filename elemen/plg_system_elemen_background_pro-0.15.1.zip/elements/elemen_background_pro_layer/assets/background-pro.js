/**
 * Elemen Animated Background Pro: pauses the animations of a layer while its section is
 * off screen, so pages with several animated sections stay light on battery.
 */
(() => {
    const layers = document.querySelectorAll('.elemen-bg:not(.elemen-bg-speed-still)');

    if (!layers.length || !('IntersectionObserver' in window)) {
        return;
    }

    const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry) => entry.target.classList.toggle('elemen-bg-paused', !entry.isIntersecting));
    }, { rootMargin: '100px 0px' });

    layers.forEach((layer) => observer.observe(layer));
})();
