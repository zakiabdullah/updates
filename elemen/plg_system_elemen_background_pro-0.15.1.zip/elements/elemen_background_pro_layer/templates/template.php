<?php

/**
 * Animated Background: one decorative layer behind the content of a section.
 *
 * Each colour is a plain box, softened and shaped by a CSS mask. Theme colours come from
 * UIkit's background classes (uk-background-primary, …), so they match the theme exactly
 * and follow style changes; custom colours are inline. Only transform and opacity are
 * animated, so the browser can move the layers without repainting them.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var array<string, mixed> $props
 */

use Joomla\CMS\Uri\Uri;
use YOOtheme\Metadata;

use function YOOtheme\app;

\defined('_JEXEC') or die;

$effect = in_array($props['effect'] ?? '', ['aurora', 'gradient', 'waves', 'pattern', 'shapes'], true) ? $props['effect'] : '';
$grain  = !empty($props['grain']);

if (!$effect && !$grain) {
    return;
}

// Only characters that colours use are allowed.
$clean = static fn ($value): string => preg_match('/^[#(),.%\w\s-]+$/', trim((string) $value)) ? trim((string) $value) : '';

$palettes = [
    'corporate' => ['#1e4fa3', '#0d9488', '#60a5fa'],
    'vibrant'   => ['#7c3aed', '#ec4899', '#f59e0b'],
];

// Paints: ['class' => uk-background-*] for theme tones, ['color' => …] for the others.
$colors = (string) ($props['colors'] ?? '');
$paints = [];

if ($colors === 'custom') {
    foreach ([1, 2, 3] as $n) {
        if ($color = $clean($props["color_$n"] ?? '')) {
            $paints[] = ['color' => $color];
        }
    }
} elseif (isset($palettes[$colors])) {
    $paints = array_map(static fn (string $color): array => ['color' => $color], $palettes[$colors]);
}

// Auto: the primary color on light sections, a calm single-color look that suits any
// brand (secondary is often a dark grey, which shows as smudges on white). On dark
// sections, light glows: white on Primary, primary and white on Secondary.
$glow = !$paints && in_array($props['style'] ?? '', ['primary', 'secondary'], true);

if (!$paints) {
    $tones = match ($props['style'] ?? '') {
        'primary'   => ['default', 'muted'],
        'secondary' => ['primary', 'muted', 'primary'],
        default     => ['primary'],
    };

    foreach ($tones as $tone) {
        $paints[] = ['class' => "uk-background-{$tone}"];
    }
}

$e     = static fn (string $value): string => htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
$paint = static function (int $i, string $class, array $style = []) use ($paints, $e): string {
    $p = $paints[$i % count($paints)];

    if (isset($p['color'])) {
        array_unshift($style, "background-color: {$p['color']}");
    }

    return '<div class="' . $e(trim("{$class} " . ($p['class'] ?? ''))) . '"'
        . ($style ? ' style="' . $e(implode('; ', $style)) . '"' : '')
        . '></div>';
};

$intensity = in_array($props['intensity'] ?? '', ['medium', 'strong'], true) ? $props['intensity'] : '';
$speed     = in_array($props['speed'] ?? '', ['medium', 'fast', 'still'], true) ? $props['speed'] : '';

// Assets: loaded once per page, only when a layer is shown; the script (pausing off
// screen) only when something moves.
$assets   = \dirname(__DIR__) . '/assets';
$assetUrl = static fn (string $file): string => Uri::root(true) . '/'
    . str_replace('\\', '/', substr($assets, strlen(JPATH_ROOT) + 1)) . "/{$file}?v=" . @filemtime("{$assets}/{$file}");

$metadata = app(Metadata::class);
$metadata->set('style:elemen-background-pro', ['href' => $assetUrl('background-pro.css')]);

if ($effect && $speed !== 'still') {
    $metadata->set('script:elemen-background-pro', ['src' => $assetUrl('background-pro.js'), 'defer' => true]);
}

// Grain: a still layer of its own, after the effect, so the effect's opacity and edge
// fading do not touch it, and it blends with the section background directly.
$grainLayer = $grain ? '<div class="elemen-bg elemen-bg-grain" aria-hidden="true"></div>' : '';

if (!$effect) {
    echo $grainLayer;

    return;
}

$pattern = in_array($props['pattern'] ?? '', ['dots', 'lines'], true) ? $props['pattern'] : 'grid';

$classes = array_filter([
    'elemen-bg',
    "elemen-bg-{$effect}",
    $intensity ? "elemen-bg-{$intensity}" : '',
    $speed ? "elemen-bg-speed-{$speed}" : '',
    $effect === 'pattern' && empty($props['edges']) ? 'elemen-bg-fade' : '',
]);

$inner = '';

if ($effect === 'aurora') {
    foreach ([1, 2, 3, 4] as $n) {
        $inner .= $paint($n - 1, "elemen-bg-blob elemen-bg-blob-{$n}");
    }
} elseif ($effect === 'waves') {
    // Three sine waves, two periods across a strip twice as wide as the section, so
    // sliding it by half (one period) loops seamlessly. Back to front: higher, larger
    // and fainter. The wave is the mask of a plain colour box, like the other effects.
    $wave = static function (float $base, float $amplitude, float $phase): string {
        $points = [];

        for ($i = 0; $i <= 96; $i++) {
            $x        = $i * 25;
            $y        = $base + $amplitude * sin(2 * M_PI * ($x / 1200 + $phase));
            $points[] = $x . ',' . round($y, 1);
        }

        $svg = "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 2400 100' preserveAspectRatio='none'>"
            . "<path d='M" . implode(' L', $points) . " L2400,100 L0,100 Z'/></svg>";

        // Unquoted: rawurlencode leaves no quotes, spaces or brackets (see Shape Dividers).
        return '--ebg-mask: url(data:image/svg+xml,' . rawurlencode($svg) . ')';
    };

    foreach ([[1, 30, 16, 0], [2, 50, 12, .35], [3, 68, 9, .7]] as [$n, $base, $amplitude, $phase]) {
        $inner .= $paint($n - 1, "elemen-bg-wave elemen-bg-wave-{$n}", [$wave($base, $amplitude, $phase)]);
    }
} elseif ($effect === 'pattern') {
    // Lines or dots in currentColor: a chosen colour, else the primary colour on light
    // sections and the (light) text colour on dark ones.
    $first = $paints[0] ?? [];
    $size  = is_numeric($props['size'] ?? null) ? max(8, min(120, (int) round((float) $props['size']))) : ['grid' => 40, 'dots' => 24, 'lines' => 20][$pattern];
    $style = ["--ebg-s: {$size}px"];
    $class = "elemen-bg-tiles elemen-bg-tiles-{$pattern}";

    if (isset($first['color'])) {
        $style[] = "color: {$first['color']}";
    } elseif (!in_array($props['style'] ?? '', ['primary', 'secondary'], true)) {
        $class .= ' uk-text-primary';
    }

    $inner = '<div class="' . $e($class) . '" style="' . $e(implode('; ', $style)) . '"></div>';
} elseif ($effect === 'shapes') {
    // Shapes rising from below the section to above it, each with its own place, size,
    // speed, turn and opacity. Negative delays put them mid-way at page load, so the
    // section is never empty. The numbers come from a small generator seeded from the
    // section (see transforms.php), so a section looks the same on every page view.
    $seed   = (int) ($props['seed'] ?? 1);
    $random = static function (float $min, float $max) use (&$seed): float {
        $seed = ($seed * 1103515245 + 12345) & 0x7fffffff;

        return $min + ($seed / 0x7fffffff) * ($max - $min);
    };

    $kinds = in_array($props['shapes'] ?? '', ['circle', 'square', 'ring', 'triangle'], true) ? [$props['shapes']] : ['circle', 'square', 'ring', 'triangle'];
    $count = ['few' => 8, 'many' => 22][$props['count'] ?? ''] ?? 14;

    for ($i = 0; $i < $count; $i++) {
        $kind     = $kinds[$i % count($kinds)];
        $duration = round($random(22, 44));
        $vars     = [
            '--x: ' . round(($i + $random(.1, .9)) / $count * 100, 1) . '%',
            '--sz: ' . round($random(14, 64)) . 'px',
            "--d: {$duration}",
            '--dl: ' . -round($random(0, $duration), 1),
            '--r: ' . (($i % 2 ? -1 : 1) * round($random(60, 300))) . 'deg',
            '--o: ' . round($random(.35, .9), 2),
        ];
        $inner .= $paint($i, "elemen-bg-shape elemen-bg-shape-{$kind}", $vars);
    }
} else {
    $bands = '';

    foreach ([1, 2, 3] as $n) {
        $bands .= $paint($n - 1, "elemen-bg-band elemen-bg-band-{$n}");
    }

    $inner = "<div class=\"elemen-bg-tilt\"><div class=\"elemen-bg-flow\">{$bands}</div></div>";
}
?>
<?php

// Light glows on dark sections (Auto) are held back: white over most of a dark section
// would wash it out and take the contrast from its light text. Patterns draw thin lines
// only, so they keep their strength.
if ($glow && $effect !== 'pattern') {
    $inner = "<div class=\"elemen-bg-dim\">{$inner}</div>";
}
?>
<div class="<?= $e(implode(' ', $classes)) ?>" aria-hidden="true"><?= $inner ?></div><?= $grainLayer ?>
