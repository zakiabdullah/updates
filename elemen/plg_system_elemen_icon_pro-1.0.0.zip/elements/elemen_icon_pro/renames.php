<?php

/**
 * Settings renamed before 1.0. Layouts saved with the old names load with the new ones
 * (see bootstrap.php). The column values stay the same: the old "Columns on Phones" is now
 * the Phone Portrait column count, the old "Columns" the Phone Landscape one.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

return [
    'props' => [
        'columns_small' => 'grid_default',
        'columns'       => 'grid_small',
        'shape_padding' => 'shape_size',
        'hover'         => 'animate_hover',
        'loop'          => 'animate_loop',
    ],
];
