/* Elemen: Icon Pro — icons that draw, fade, zoom or rise into view. No dependencies. */
(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches || !('IntersectionObserver' in window)) {
        return; // icons stay as they are
    }

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(({ target, isIntersecting }) => {
            if (isIntersecting) {
                target.classList.add('is-in');
                observer.unobserve(target);
            }
        });
    }, { threshold: 0.3, rootMargin: '0px 0px -5% 0px' });

    const init = (root) => root.querySelectorAll('.elemen-icon-pro[class*="ic-in-"]:not(.ic-js)').forEach((ic) => {
        ic.classList.add('ic-js');
        ic.querySelectorAll(':scope > .ic-item').forEach((item) => observer.observe(item));
    });

    const boot = () => {
        init(document);

        // The YOOtheme builder preview replaces elements while editing.
        new MutationObserver(() => init(document)).observe(document.body, { childList: true, subtree: true });
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
