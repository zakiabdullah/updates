/* Elemen: Icon Pro picker for the YOOtheme builder.
   Turns the "Open the icon gallery" link under an icon field into a picker: the gallery
   opens in a dialog over the builder, and clicking an icon fills the field. Without this
   script the link simply opens the gallery in a new tab. No dependencies. */
(() => {
    const GALLERY = 'elemen_icon_pro/gallery/index.html';
    // The Joomla administrator language, from this script's URL (see events.php): the gallery
    // also searches that language's words (gallery/keywords/<language>.json).
    const LANG = new URL(document.currentScript?.src || location.href, location.href).searchParams.get('lang') || '';
    let dialog = null;
    let target = null;

    // The text input that belongs to the link: the nearest field container with one.
    function inputFor(link) {
        let node = link.parentElement;

        for (let i = 0; node && i < 8; i++, node = node.parentElement) {
            const inputs = node.querySelectorAll('input:not([type]), input[type="text"], input[type="search"]');

            if (inputs.length === 1) {
                return inputs[0];
            }

            if (inputs.length > 1) {
                return null;
            }
        }

        return null;
    }

    // Sets the value the way typing would, so the builder's form notices it.
    function fill(input, value) {
        const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
        setter.call(input, value);
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
        input.focus();
    }

    function close() {
        if (dialog) {
            dialog.remove();
            dialog = null;
        }

        document.removeEventListener('keydown', onKey, true);
        target?.focus();
    }

    function onKey(event) {
        if (event.key === 'Escape') {
            event.stopPropagation();
            close();
        }
    }

    function open(link, input) {
        close();
        target = input;

        const url = new URL(link.href, location.href);
        url.searchParams.set('pick', '1');

        if (LANG) {
            url.searchParams.set('lang', LANG);
        }

        if (input.value.trim()) {
            url.searchParams.set('q', input.value.trim().replace(/^lucide:/, ''));
        }

        dialog = document.createElement('div');
        dialog.className = 'elemen-icon-picker';
        dialog.setAttribute('role', 'dialog');
        dialog.setAttribute('aria-modal', 'true');
        dialog.setAttribute('aria-label', 'Icon gallery');
        dialog.innerHTML = '<div class="elemen-icon-picker-box"><button type="button" class="elemen-icon-picker-close" aria-label="Close">&times;</button><iframe title="Icon gallery"></iframe></div>';
        dialog.querySelector('iframe').src = url.href;
        dialog.addEventListener('click', (event) => {
            if (event.target === dialog || event.target.closest('.elemen-icon-picker-close')) {
                close();
            }
        });

        document.body.appendChild(dialog);
        document.addEventListener('keydown', onKey, true);
        dialog.querySelector('iframe').addEventListener('load', () => dialog?.querySelector('iframe').contentWindow.focus());
    }

    // The gallery reports the icon picked; only from its own frame, on this site.
    window.addEventListener('message', (event) => {
        const frame = dialog?.querySelector('iframe');

        if (!frame || event.source !== frame.contentWindow || event.origin !== location.origin) {
            return;
        }

        const data = event.data || {};

        if (data.type === 'elemen-icon-pick' && typeof data.name === 'string' && /^[a-z0-9:-]+$/.test(data.name) && target) {
            fill(target, data.name);
            close();
        } else if (data.type === 'elemen-icon-close') {
            close();
        }
    });

    function enhance(root) {
        root.querySelectorAll(`a[href*="${GALLERY}"]:not([data-elemen-picker])`).forEach((link) => {
            link.setAttribute('data-elemen-picker', '');

            // Opened in a new tab too, the gallery searches in the editor's language.
            if (LANG) {
                const url = new URL(link.href, location.href);
                url.searchParams.set('lang', LANG);
                link.href = url.href;
            }
            link.addEventListener('click', (event) => {
                const input = inputFor(link);

                if (input) {
                    event.preventDefault();
                    open(link, input);
                }
            });
        });
    }

    const style = document.createElement('style');
    style.textContent = `
.elemen-icon-picker { position: fixed; inset: 0; z-index: 100000; display: flex; align-items: center; justify-content: center; padding: 30px; background: rgba(0, 0, 0, .5); }
.elemen-icon-picker-box { position: relative; width: min(1000px, 100%); height: min(720px, 100%); overflow: hidden; border-radius: 10px; background: #fff; box-shadow: 0 20px 60px rgba(0, 0, 0, .35); }
.elemen-icon-picker iframe { display: block; width: 100%; height: 100%; border: 0; }
.elemen-icon-picker-close { position: absolute; top: 12px; right: 28px; z-index: 1; width: 34px; height: 34px; border: 0; border-radius: 50%; background: rgba(128, 128, 128, .2); color: inherit; font-size: 22px; line-height: 1; cursor: pointer; }
.elemen-icon-picker-close:hover, .elemen-icon-picker-close:focus-visible { background: rgba(128, 128, 128, .35); outline: none; }`;

    const boot = () => {
        document.head.appendChild(style);
        enhance(document);
        new MutationObserver(() => enhance(document)).observe(document.body, { childList: true, subtree: true });
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
