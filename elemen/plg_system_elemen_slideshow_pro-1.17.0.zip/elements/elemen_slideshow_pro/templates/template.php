<?php

/**
 * Slideshow Pro: a hero slideshow on UIkit's Slideshow with staggered content, Ken Burns,
 * overlays and its own autoplay (slideshow-pro.js), which pauses on hover, focus, off-screen,
 * in hidden tabs and with the Pause button, and can give every slide its own duration.
 *
 * Without JS the first slide's content is fully visible; the hidden starting state of the
 * content only applies once the inline script below has marked the slideshow (.ssp-js).
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var \YOOtheme\Builder $builder
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<int, object> $children
 */

use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;
use YOOtheme\Config;
use YOOtheme\Metadata;

use function YOOtheme\app;

\defined('_JEXEC') or die;

require_once \dirname(__DIR__) . '/ElemenSlideshowPro.php';

// Display options: fields of every slide can be hidden without deleting them. Layouts saved
// before the options existed don't have them, so they count as shown.
$hidden = [];

foreach (['eyebrow' => ['eyebrow'], 'title' => ['title'], 'content' => ['content'], 'buttons' => ['button1_text', 'button2_text']] as $option => $fields) {
    if (!($props["show_{$option}"] ?? true)) {
        array_push($hidden, ...$fields);
    }
}

foreach ($hidden ? $children : [] as $child) {
    foreach ($hidden as $field) {
        if (is_array($child->props ?? null)) {
            $child->props[$field] = '';
        } elseif (is_object($child->props ?? null)) {
            $child->props->{$field} = '';
        }
    }
}

$has       = static fn ($value): bool => trim(strip_tags((string) $value, '<img><svg>')) !== '';
$inBuilder = (bool) app(Config::class)->get('app.isCustomizer');

// Slides with something to show, inside their dates. The builder preview keeps scheduled
// slides (marked) so they can still be edited.
$slides = array_values(array_filter($children, static function (object $child) use ($has, $inBuilder): bool {
    $p = (array) ($child->props ?? []);

    foreach (['image', 'image_mobile', 'eyebrow', 'title', 'content', 'button1_text', 'button2_text'] as $field) {
        if ($has($p[$field] ?? '')) {
            return $inBuilder || !ElemenSlideshowPro::outOfSchedule($p);
        }
    }

    return false;
}));

if (!$slides) {
    return;
}

$s = ElemenSlideshowPro::settings($props);

$language = Factory::getApplication()->getLanguage();
$language->load('plg_system_elemen_slideshow_pro', JPATH_ADMINISTRATOR);
$text = static fn (string $key): string => htmlspecialchars($language->_('PLG_SYSTEM_ELEMEN_SLIDESHOW_PRO_' . $key), ENT_QUOTES, 'UTF-8');

$assets   = \dirname(__DIR__) . '/assets';
$assetUrl = static fn (string $file): string => Uri::root(true) . '/'
    . str_replace('\\', '/', substr($assets, strlen(JPATH_ROOT) + 1)) . "/{$file}?v=" . @filemtime("{$assets}/{$file}");
$metadata = app(Metadata::class);

$metadata->set('style:elemen-slideshow-pro', ['href' => $assetUrl('slideshow-pro.css')]);
$metadata->set('script:elemen-slideshow-pro', ['src' => $assetUrl('slideshow-pro.js'), 'defer' => true]);

$count    = count($slides);
$autoplay = $s['autoplay'] && $count > 1;

// UIkit Slideshow options; autoplay is slideshow-pro.js's own.
$options = [
    'animation: ' . $s['transition'],
    'velocity: ' . ElemenSlideshowPro::VELOCITY[$s['transition_speed']],
    'ratio: ' . ($s['height'] === 'ratio' ? $s['ratio'] : 'false'),
];

if ($s['height'] === 'ratio' && $s['min_height'] > 0) {
    $options[] = "minHeight: {$s['min_height']}";
}

$vars = [
    "--ssp-delay: {$s['anim_delay']}ms",
    "--ssp-stagger: {$s['anim_stagger']}ms",
    "--ssp-dur: {$s['anim_duration']}ms",
    '--ssp-ov-opacity: ' . round($s['overlay_opacity'] / 100, 2),
    '--ssp-kb-dur: ' . ($s['duration'] + 4) . 's',
];

if ($s['overlay'] === 'custom') {
    $vars[] = "--ssp-ov-color: {$s['overlay_color']}";
}

if ($s['height'] === 'fixed') {
    $vars[] = "--ssp-height: {$s['height_value']}px";
}

if ($s['height'] !== 'ratio' && $s['min_height'] > 0) {
    $vars[] = "--ssp-min: {$s['min_height']}px";
}

$el = $this->el('div', [
    'class' => [
        'elemen-slideshow-pro ssp',
        "ssp-h-{$s['height']}",
        "ssp-anim-{$s['content_animation']}",
        "ssp-ov-{$s['overlay_type']}",
        'ssp-has-arrows' => $s['arrows'] && $count > 1,
        'ssp-has-dots' => $s['dots'] && $count > 1,
    ],
    'style'          => implode('; ', $vars),
    'uk-slideshow'   => implode('; ', $options),
    'role'           => 'region',
    'aria-roledescription' => 'carousel',
    'aria-label'     => $language->_('PLG_SYSTEM_ELEMEN_SLIDESHOW_PRO_LABEL'),
    'data-ssp'       => json_encode([
        'autoplay' => $autoplay,
        'duration' => $s['duration'],
        'hover'    => $s['pause_hover'],
    ]),
]);

$heightAttr = false;

if ($s['height'] === 'viewport') {
    $heightAttr = implode('; ', array_filter([
        $s['viewport_offset'] ? 'offset-top: true' : '',
        "min: {$s['min_height']}",
        $s['height_value'] < 100 ? 'offset-bottom: ' . (100 - $s['height_value']) : '',
    ]));
}

$list = $this->el('div', [
    'class'              => 'uk-slideshow-items ssp-items',
    'uk-height-viewport' => $heightAttr,
    'aria-live'          => $autoplay ? 'off' : 'polite',
]);

$visible = 0;

?>
<?= $el($props, $attrs) ?>

    <?= $list() ?>
        <?php foreach ($slides as $i => $slide) : ?>
        <?php $out = $inBuilder && ElemenSlideshowPro::outOfSchedule((array) ($slide->props ?? [])) ?>
        <?= $builder->render($slide, ['element' => $props, 'settings' => $s, 'index' => $i, 'count' => $count, 'first' => !$out && $visible++ === 0, 'scheduled' => $out]) ?>
        <?php endforeach ?>
    <?= $list->end() ?>

    <?php if ($s['arrows'] && $count > 1) : ?>
    <a class="ssp-arrow ssp-arrow-previous ssp-ui uk-<?= $s['text_color'] ?> uk-slidenav-large" href="#" uk-slidenav-previous uk-slideshow-item="previous" aria-label="<?= $text('PREVIOUS') ?>"></a>
    <a class="ssp-arrow ssp-arrow-next ssp-ui uk-<?= $s['text_color'] ?> uk-slidenav-large" href="#" uk-slidenav-next uk-slideshow-item="next" aria-label="<?= $text('NEXT') ?>"></a>
    <?php endif ?>

    <?php if (($s['dots'] && $count > 1) || $autoplay && $s['pause_button']) : ?>
    <div class="ssp-controls ssp-ui uk-<?= $s['text_color'] ?>">
        <?php if ($s['dots'] && $count > 1) : ?>
        <ul class="uk-slideshow-nav uk-dotnav ssp-dots"></ul>
        <?php endif ?>
        <?php if ($autoplay && $s['pause_button']) : ?>
        <button type="button" class="ssp-pause" aria-label="<?= $text('PAUSE') ?>" data-ssp-pause="<?= $text('PAUSE') ?>" data-ssp-play="<?= $text('PLAY') ?>">
            <svg class="ssp-icon-pause" width="14" height="14" viewBox="0 0 14 14" aria-hidden="true" focusable="false"><rect x="2.5" y="1.5" width="3" height="11" rx="1" /><rect x="8.5" y="1.5" width="3" height="11" rx="1" /></svg>
            <svg class="ssp-icon-play" width="14" height="14" viewBox="0 0 14 14" aria-hidden="true" focusable="false"><path d="M3.5 1.8v10.4a.6.6 0 0 0 .9.5l8.2-5.2a.6.6 0 0 0 0-1L4.4 1.3a.6.6 0 0 0-.9.5z" /></svg>
        </button>
        <?php endif ?>
    </div>
    <?php endif ?>

    <?php if ($s['scroll_hint'] && $s['height'] === 'viewport') : ?>
    <button type="button" class="ssp-scroll ssp-ui uk-<?= $s['text_color'] ?>" aria-label="<?= $text('SCROLL') ?>"><span class="ssp-scroll-mouse" aria-hidden="true"><span></span></span></button>
    <?php endif ?>

<?= $el->end() ?>
<script>document.currentScript.previousElementSibling.classList.add('ssp-js')</script>
