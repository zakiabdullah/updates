<?php

/**
 * Lets other Elemen elements use Lucide icons while Icon Pro is installed: a "Lucide Icon"
 * field goes right after each of their UIkit icon fields. Their templates draw the Lucide
 * icon when it is set and Icon Pro's icons are there, and the UIkit icon otherwise, so
 * nothing changes for layouts without it.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

use Joomla\CMS\Uri\Uri;

\defined('_JEXEC') or die;

return [
    'builder.type' => static function (array $type): array {
        // Element type => its UIkit icon fields. The Lucide field is "<field>_lucide".
        $targets = [
            'elemen_counter_pro_item'  => ['icon'],
            'elemen_flipbox_pro'       => ['list_icon'],
            'elemen_flipbox_pro_item'  => ['icon'],
            'elemen_timeline_pro'      => ['marker_icon'],
            'elemen_timeline_pro_item' => ['icon'],
            'elemen_tabs_pro_item'     => ['icon'],
        ];

        $fields = $targets[$type['name'] ?? ''] ?? [];

        if (!$fields) {
            return $type;
        }

        $gallery = Uri::root(true) . '/' . str_replace('\\', '/', substr(__DIR__, strlen(JPATH_ROOT) + 1)) . '/gallery/index.html';

        foreach ($fields as $field) {
            $name = "{$field}_lucide";

            if (!isset($type['fields'][$field]) || isset($type['fields'][$name])) {
                continue;
            }

            $type['fields'][$name] = array_intersect_key((array) $type['fields'][$field], array_flip(['enable', 'show'])) + [
                'label'       => 'Lucide Icon',
                'description' => 'Used instead of the icon above, e.g. <code>house</code> (Icon Pro). <a href="' . htmlspecialchars($gallery) . '" target="_blank" rel="noopener">Open the icon gallery</a>.',
                'attrs'       => ['placeholder' => 'house'],
                'source'      => true,
            ];

            // Right after the UIkit icon field, wherever it sits in the panel.
            $insert = static function (array $list) use (&$insert, $field, $name): array {
                $out    = [];
                $isList = array_is_list($list);

                foreach ($list as $key => $entry) {
                    if (is_array($entry) && isset($entry['fields']) && is_array($entry['fields'])) {
                        $entry['fields'] = $insert($entry['fields']);
                    }

                    if ($isList) {
                        $out[] = $entry;
                    } else {
                        $out[$key] = $entry;
                    }

                    if ($entry === $field) {
                        $out[] = $name;
                    }
                }

                return $out;
            };

            foreach ($type['fieldset'] ?? [] as $key => $set) {
                if (is_array($set)) {
                    $type['fieldset'][$key] = $insert([$set])[0];
                }
            }
        }

        return $type;
    },
];
