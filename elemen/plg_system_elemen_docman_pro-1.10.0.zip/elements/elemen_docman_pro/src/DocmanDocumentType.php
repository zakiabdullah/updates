<?php

/**
 * Dynamic fields available for a DOCman document.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

namespace Elemen\DocmanPro\Source;

use Joomla\CMS\Language\Text;

\defined('_JEXEC') or die;

final class DocmanDocumentType
{
    public static function config(): array
    {
        $fields = [];

        foreach ([
            'id'             => ['Int', 'ID'],
            'title'          => ['String', 'TITLE'],
            'description'    => ['String', 'DESCRIPTION'],
            'category_title' => ['String', 'CATEGORY'],
            'category_id'    => ['Int', 'CATEGORY_ID'],
            'publish_date'   => ['String', 'PUBLISHED'],
            'file_extension' => ['String', 'FILE_EXTENSION'],
            'file_size'      => ['Int', 'FILE_SIZE'],
        ] as $name => [$type, $label]) {
            $fields[$name] = [
                'type'     => $type,
                'metadata' => ['label' => Text::_('PLG_SYSTEM_ELEMEN_DOCMAN_PRO_DOCUMENT_' . $label)],
            ];
        }

        return [
            'fields'   => $fields,
            'metadata' => [
                'type'  => true,
                'label' => Text::_('PLG_SYSTEM_ELEMEN_DOCMAN_PRO_SOURCE_DOCUMENT'),
            ],
        ];
    }
}
