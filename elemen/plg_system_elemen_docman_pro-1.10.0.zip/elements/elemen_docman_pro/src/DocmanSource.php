<?php

/**
 * YOOtheme source registration for DOCman.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

namespace Elemen\DocmanPro\Source;

use YOOtheme\Builder\Source;

\defined('_JEXEC') or die;

final class DocmanSource
{
    public static function init(Source $source): void
    {
        $source->objectType('ElemenDocmanDocument', DocmanDocumentType::config());
        $source->queryType(DocmanQueryType::config());
    }
}
