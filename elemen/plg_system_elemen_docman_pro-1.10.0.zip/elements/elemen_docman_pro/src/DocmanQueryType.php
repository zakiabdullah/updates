<?php

/**
 * Custom DOCman document queries exposed in YOOtheme's Dynamic Content picker.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

namespace Elemen\DocmanPro\Source;

use Joomla\CMS\Language\Text;

\defined('_JEXEC') or die;

final class DocmanQueryType
{
    public static function config(): array
    {
        return [
            'fields' => [
                'customElemenDocmanDocument' => [
                    'type' => 'ElemenDocmanDocument',
                    'args' => [
                        'id' => ['type' => 'Int'],
                    ],
                    'metadata' => [
                        'label' => Text::_('PLG_SYSTEM_ELEMEN_DOCMAN_PRO_SOURCE_DOCUMENT'),
                        'group' => 'Custom',
                        'fields' => [
                            'id' => [
                                'label'       => Text::_('PLG_SYSTEM_ELEMEN_DOCMAN_PRO_FIELD_ID'),
                                'description' => Text::_('PLG_SYSTEM_ELEMEN_DOCMAN_PRO_FIELD_ID'),
                                'type'        => 'text',
                            ],
                        ],
                    ],
                    'extensions' => ['call' => self::class . '::document'],
                ],
                'customElemenDocmanDocuments' => [
                    'type' => ['listOf' => 'ElemenDocmanDocument'],
                    'args' => [
                        'category' => ['type' => 'Int'],
                        'limit'    => ['type' => 'Int'],
                        'offset'   => ['type' => 'Int'],
                    ],
                    'metadata' => [
                        'label' => Text::_('PLG_SYSTEM_ELEMEN_DOCMAN_PRO_SOURCE_DOCUMENTS'),
                        'group' => 'Custom',
                        'fields' => [
                            'category' => [
                                'label'       => Text::_('PLG_SYSTEM_ELEMEN_DOCMAN_PRO_FIELD_CATEGORY'),
                                'description' => Text::_('PLG_SYSTEM_ELEMEN_DOCMAN_PRO_FIELD_CATEGORY'),
                                'type'        => 'text',
                            ],
                            'limit' => [
                                'label'       => Text::_('PLG_SYSTEM_ELEMEN_DOCMAN_PRO_FIELD_LIMIT'),
                                'description' => Text::_('PLG_SYSTEM_ELEMEN_DOCMAN_PRO_FIELD_LIMIT'),
                                'type'        => 'number',
                                'default'     => 10,
                            ],
                            'offset' => [
                                'label'       => Text::_('PLG_SYSTEM_ELEMEN_DOCMAN_PRO_FIELD_OFFSET'),
                                'description' => Text::_('PLG_SYSTEM_ELEMEN_DOCMAN_PRO_FIELD_OFFSET'),
                                'type'        => 'number',
                                'default'     => 0,
                            ],
                        ],
                    ],
                    'extensions' => ['call' => self::class . '::documents'],
                ],
            ],
        ];
    }

    public static function document($item, array $args): ?object
    {
        $id = (int) ($args['id'] ?? 0);

        if ($id < 1) {
            return null;
        }

        $documents = self::browse($id, null, 1, 0);

        return $documents[0] ?? null;
    }

    public static function documents($item, array $args): array
    {
        return self::browse(
            null,
            isset($args['category']) ? (int) $args['category'] : null,
            min(100, max(1, (int) ($args['limit'] ?? 10))),
            max(0, (int) ($args['offset'] ?? 0))
        );
    }

    /**
     * Read only published DOCman documents visible to the current Joomla user.
     * Missing DOCman installations and API errors safely yield no results.
     *
     * @return array<object>
     */
    private static function browse(?int $id, ?int $category, int $limit, int $offset): array
    {
        if (!class_exists('Koowa')) {
            return [];
        }

        try {
            $controller = \Koowa::getObject('com://site/docman.controller.document');
            $user       = \Koowa::getObject('user');

            $query = $controller
                ->access($user->getRoles())
                ->current_user($user->getId())
                ->enabled(1)
                ->status('published')
                ->limit($limit)
                ->offset($offset);

            if ($id !== null) {
                $query->id($id);
            }

            if ($category !== null && $category > 0) {
                $query->category($category);
            }

            $items = $query->browse();

            if (!is_iterable($items)) {
                return [];
            }

            $documents = [];

            foreach ($items as $document) {
                $categoryObject = $document->category ?? null;
                $file           = $document->file ?? null;
                $documents[]    = (object) [
                    'id'             => (int) ($document->id ?? 0),
                    'title'          => (string) ($document->title ?? ''),
                    'description'    => (string) ($document->description ?? ''),
                    'category_title' => (string) ($categoryObject->title ?? ''),
                    'category_id'    => (int) ($document->docman_category_id ?? 0),
                    'publish_date'   => (string) ($document->publish_date ?? ''),
                    'file_extension' => (string) ($file->extension ?? ''),
                    'file_size'      => (int) ($file->size ?? 0),
                ];
            }

            return $documents;
        } catch (\Throwable $error) {
            // Keep Elemen/YOOtheme working if DOCman is absent or has a different API version.
            return [];
        }
    }
}
