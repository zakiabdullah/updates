/* Elemen: Heading Pro — drawn shapes and rotating words. No dependencies. */
(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

    // Width of the rotating-word box follows the active word so the text after it moves smoothly.
    const fit = (box, word) => {
        box.style.width = `${word.offsetWidth}px`;
    };

    async function rotate(el) {
        const box = el.querySelector('.hp-words');
        const words = box ? [...box.querySelectorAll('.hp-word')] : [];

        if (words.length < 2) {
            return;
        }

        const effect = el.dataset.hpEffect || 'typewriter';
        const delay = Number(el.dataset.hpDelay) || 2500;
        const speed = Number(el.dataset.hpSpeed) || 80;
        const loop = el.dataset.hpLoop !== 'false';
        let index = 0;

        if (effect === 'typewriter') {
            const texts = words.map((word) => word.textContent);
            const word = words[0];
            const show = (text) => {
                word.textContent = text || '​'; // keep the line height when empty
            };

            words.slice(1).forEach((other) => other.remove());

            for (;;) {
                await sleep(delay);

                if (!el.isConnected || (!loop && index === texts.length - 1)) {
                    return;
                }

                const next = (index + 1) % texts.length;

                if (reduce) {
                    show(texts[next]);
                } else {
                    for (let n = texts[index].length - 1; n >= 0; n--) {
                        show(texts[index].slice(0, n));
                        await sleep(speed / 2);
                    }

                    for (let n = 1; n <= texts[next].length; n++) {
                        show(texts[next].slice(0, n));
                        await sleep(speed);
                    }
                }

                index = next;
            }
        }

        fit(box, words[0]);
        window.addEventListener('resize', () => fit(box, words[index]));

        for (;;) {
            await sleep(delay);

            if (!el.isConnected || (!loop && index === words.length - 1)) {
                return;
            }

            const current = words[index];
            index = (index + 1) % words.length;
            const next = words[index];

            current.classList.remove('is-active');
            current.classList.add('is-leaving');
            next.classList.add('is-active');
            fit(box, next);

            setTimeout(() => current.classList.remove('is-leaving'), 600);
        }
    }

    const observer = 'IntersectionObserver' in window
        ? new IntersectionObserver((entries) => {
            entries.forEach(({ target, isIntersecting }) => {
                if (isIntersecting) {
                    start(target);
                } else if (target.dataset.hpRepeat === 'true') {
                    target.classList.remove('hp-in-view');
                }
            });
        }, { threshold: 0.6 })
        : null;

    function start(el) {
        el.classList.add('hp-in-view');

        if (el.dataset.hpAnim === 'rotate' && !el.hpStarted) {
            el.hpStarted = true;
            rotate(el);
        }

        if (el.dataset.hpAnim === 'rotate' || el.dataset.hpRepeat !== 'true') {
            observer?.unobserve(el);
        }
    }

    /* Text reveal: wrap words or letters in spans that appear one after the other. The
       highlighted part, images and icons stay whole. */

    // Joined scripts (Arabic, Jawi, Devanagari, Thai, …) lose their letter shapes when
    // letters are split, so those headings are split by word instead.
    const joined = /[֐-ࣿऀ-෿฀-໿ﭐ-﷿ﹰ-﻿]/;

    function split(title) {
        const letters = title.dataset.hpReveal === 'letters' && !joined.test(title.textContent);
        const units = [];
        const unit = (el) => {
            el.classList.add('hp-unit');
            units.push(el);
        };

        if (letters) {
            // Screen readers read the label instead of single letters.
            const copy = title.cloneNode(true);
            copy.querySelectorAll('.hp-words, svg').forEach((el) => el.remove());
            title.setAttribute('aria-label', copy.textContent.replace(/\s+/g, ' ').trim());
        }

        const walk = (node) => {
            [...node.childNodes].forEach((child) => {
                if (child.nodeType === Node.TEXT_NODE) {
                    if (!child.textContent.trim()) {
                        return;
                    }

                    const parts = document.createDocumentFragment();

                    child.textContent.split(/(\s+)/).forEach((part) => {
                        if (!part) {
                            return;
                        }

                        if (/^\s+$/.test(part)) {
                            parts.append(part);
                            return;
                        }

                        const word = document.createElement('span');
                        word.className = 'hp-unit-word';

                        if (letters) {
                            Array.from(part).forEach((character) => {
                                const letter = document.createElement('span');
                                letter.textContent = character;
                                word.append(letter);
                                unit(letter);
                            });
                        } else {
                            word.textContent = part;
                            unit(word);
                        }

                        parts.append(word);
                    });

                    child.replaceWith(parts);
                } else if (child.nodeType === Node.ELEMENT_NODE) {
                    if (child.matches('.hp-highlight, img, svg, .el-image, [uk-icon]')) {
                        unit(child);
                    } else if (!child.matches('.uk-hidden-visually, br')) {
                        walk(child);
                    }
                }
            });
        };

        walk(title);
        units.forEach((el, i) => el.style.setProperty('--hp-i', i));
        title.setAttribute('data-hp-split', '');
    }

    const revealer = 'IntersectionObserver' in window
        ? new IntersectionObserver((entries) => {
            entries.forEach(({ target, isIntersecting }) => {
                if (isIntersecting) {
                    target.classList.add('hp-revealed');

                    if (target.dataset.hpRevealRepeat !== 'true') {
                        revealer.unobserve(target);
                    }
                } else if (target.dataset.hpRevealRepeat === 'true') {
                    target.classList.remove('hp-revealed');
                }
            });
        }, { threshold: 0.3 })
        : null;

    function init(root) {
        root.querySelectorAll('.hp-highlight[data-hp-anim]:not([data-hp-ready])').forEach((el) => {
            el.setAttribute('data-hp-ready', '');

            if (observer) {
                observer.observe(el);
            } else {
                start(el);
            }
        });

        // Without motion or IntersectionObserver the heading simply stays visible.
        if (!reduce && revealer) {
            root.querySelectorAll('.hp-title[data-hp-reveal]:not([data-hp-split])').forEach((title) => {
                split(title);
                revealer.observe(title);
            });
        }
    }

    const boot = () => {
        init(document);

        // The YOOtheme builder preview replaces elements while editing.
        new MutationObserver(() => init(document)).observe(document.body, { childList: true, subtree: true });
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
