<?php

// Copied from YOOtheme Pro 5.0.56 Headline element.

\defined('_JEXEC') or die;

$icon = $this->el('span', [

    'class' => [
        'uk-text-{image_svg_color}',
    ],

    'uk-icon' => [
        'icon: {icon};',
        'width: {image_width};',
        'height: {image_width};',
    ],

]);

return $icon;
