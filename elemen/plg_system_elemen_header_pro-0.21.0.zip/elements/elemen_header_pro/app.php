<?php

/**
 * Header Pro: defaults of its customizer settings, stored with the theme's own settings
 * under "elemen_header". Off by default, so installing changes nothing until chosen.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

return [
    'theme' => [
        'defaults' => [
            'elemen_header' => [
                'style'        => '',
                'apply'        => 'sticky',
                'offset'       => 0,
                'width'        => 'header',
                'animate'      => false,
                'menu_slide'   => false,
                'mobile_shape' => '',
                'menu'         => '',
                'dropdown'     => '',
                'divider'      => false,
                'dialog'       => '',
                'progress'     => '',
                'cta_text'     => '',
                'cta_link'     => '',
                'cta_style'    => 'primary',
                'cta_position' => 'header',
                'cta_target'   => false,
                'cta_mobile'   => false,
                'shape'        => 'full',
                'tint'         => 'default',
                'opacity'      => 70,
                'blur'         => 16,
                'gap'          => 12,
                'radius'       => 'pill',
                'height'       => 0,
                'shadow'       => true,
                'border'       => true,
                'mobile'       => true,
            ],
        ],
    ],
];
