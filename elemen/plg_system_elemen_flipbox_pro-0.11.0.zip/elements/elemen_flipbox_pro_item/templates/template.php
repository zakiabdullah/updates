<?php

/**
 * Flip Box Pro item: a box with a front and a back side that turns on hover, focus or
 * click. Content comes from the item, settings from the parent element ($element).
 *
 * Both sides share one grid cell, so the box is as tall as the taller side and no
 * content is cut off. Keyboard users turn it by tabbing into it.
 *
 * @package     Elemen
 * @license     GNU General Public License version 2 or later
 *
 * @var \YOOtheme\View $this
 * @var array<string, mixed> $props
 * @var array<string, mixed> $attrs
 * @var array<string, mixed> $element
 * @var string $__dir
 */

\defined('_JEXEC') or die;

// Settings from the element, content from this item. An item background color overrides
// the element style for that side, and so does its text color.
$content = ['image', 'image_alt', 'icon', 'icon_lucide', 'title', 'content', 'front_bg_image', 'back_title', 'back_content', 'back_list', 'back_bg_image', 'link', 'link_text'];
$own     = $props;
$props   = array_merge((array) ($element ?? []), array_intersect_key($own, array_flip($content)));

foreach (['front', 'back'] as $side) {
    if (trim((string) ($own["{$side}_bg_color"] ?? '')) !== '') {
        $props["{$side}_style"]    = 'custom';
        $props["{$side}_bg_color"] = $own["{$side}_bg_color"];
    }

    if (!empty($own["{$side}_text"])) {
        $props["{$side}_text"] = $own["{$side}_text"];
    }
}

$has = static fn ($value): bool => trim((string) $value) !== '';

// A Lucide icon from Icon Pro's "Lucide Icon" field, when Icon Pro is installed.
$lucide = static function ($name, int $size): string {
    $file = JPATH_PLUGINS . '/system/elemen_icon_pro/elements/elemen_icon_pro/icons/Icons.php';

    if (trim((string) $name) === '' || !is_file($file)) {
        return '';
    }

    require_once $file;

    return \Elemen\IconPro\Icons::svg((string) $name, ['size' => $size]);
};

if (!$has($props['title']) && !$has($props['content']) && !$has($props['back_title']) && !$has($props['back_content']) && !$has($props['back_list']) && !$props['image'] && !$props['icon'] && !$has($props['icon_lucide'] ?? '')) {
    return;
}

$color  = static fn ($value): string => preg_match('/^[#(),.%\w\s-]+$/', trim((string) $value)) ? trim((string) $value) : '';
$radius = ['none' => '0', 'small' => '4px', 'medium' => '10px', 'large' => '20px'][$props['radius']] ?? '4px';

$el = $this->el('div', [

    'class' => [
        'elemen-flipbox-pro fb',
        'fb-effect-{effect}',
        'fb-depth' => $props['depth'] && str_starts_with((string) $props['effect'], 'flip-'),
        'fb-trigger-{trigger}',
        'el-item',
        'fb-expand uk-height-1-1' => $props['height_expand'] || $props['grid_match'],
        'uk-box-shadow-{shadow}',
    ],

    'style' => sprintf(
        '--fb-duration: %dms; --fb-min-height: %dpx; --fb-radius: %s',
        (int) ($props['duration'] ?: 700),
        (int) ($props['min_height'] ?: 300),
        $radius
    ),

    'tabindex'      => '0',
    'aria-pressed'  => $props['trigger'] === 'click' ? 'false' : false,
    'role'          => $props['trigger'] === 'click' ? 'button' : false,

]);

/**
 * One side of the box.
 */
$face = function (string $side, string $inner) use ($props, $color) {
    $style  = $props["{$side}_style"] ?: ($side === 'front' ? 'default' : 'primary');
    $bg     = $color($props["{$side}_bg_color"]);
    $text   = $props["{$side}_text"];
    $styles = [];

    if ($style === 'custom' && $bg) {
        $styles[] = "background-color: {$bg}";
    }

    $el = $this->el('div', [

        'class' => [
            "fb-face fb-{$side} el-{$side}",
            'uk-card uk-card-' . $style => in_array($style, ['default', 'primary', 'secondary'], true),
            'uk-background-muted' => $style === 'muted',
            'uk-light' => $text === 'light',
            'uk-dark' => $text === 'dark',
            'fb-valign-' . ($props['vertical_align'] ?: 'middle'),
        ],

        'style' => $styles ? implode('; ', $styles) : false,

    ]);

    $html = '';
    $image = $props["{$side}_bg_image"];

    if ($image) {
        $html .= $this->el('image', [
            'class' => ['fb-bg'],
            'src' => $image,
            'alt' => '',
            'loading' => 'lazy',
            'thumbnail' => true,
        ])->render([]);

        if ($overlay = $color($props["{$side}_overlay"])) {
            $html .= '<div class="fb-overlay" style="background-color: ' . $overlay . '"></div>';
        }
    }

    $padding = ['small' => 'uk-padding-small', 'large' => 'uk-padding-large'][$props['padding']] ?? 'uk-padding';

    return $el($props, $html . '<div class="fb-content ' . $padding . '">' . $inner . '</div>');
};

// Front
$media = '';

if ($props['image']) {
    $src   = $props['image'];
    $focal = '';
    $mediaEl = include "{$__dir}/template-image.php";
    $mediaEl->attr('class', ['el-image', 'uk-border-{image_border}', 'uk-margin-{image_margin}-bottom']);
    $media = $mediaEl($props, '');
} elseif ($svg = $lucide($props['icon_lucide'] ?? '', (int) ($props['image_width'] ?: 40))) {
    $media = '<div><span class="el-image uk-margin-' . ($props['image_margin'] ?: 'small') . '-bottom' . ($props['image_svg_color'] ? ' uk-text-' . $props['image_svg_color'] : '') . '">' . $svg . '</span></div>';
} elseif ($props['icon']) {
    $mediaEl = include "{$__dir}/template-icon.php";
    $mediaEl->attr('class', ['el-image', 'uk-margin-{image_margin}-bottom']);
    $media = '<div>' . $mediaEl($props, '') . '</div>';
}

$titleTag = $props['title_element'] ?: 'h3';
$title = static fn ($text, $style) => '<' . $titleTag . ' class="el-title fb-title uk-margin-remove-top uk-margin-small-bottom' . ($style ? " uk-{$style}" : '') . '">' . $text . '</' . $titleTag . '>';

$front = $media
    . ($has($props['title']) ? $title($props['title'], $props['title_style']) : '')
    . ($has($props['content']) ? '<div class="el-content fb-text uk-panel">' . $props['content'] . '</div>' : '');

// Back list: one feature per line, each with the element's icon.
$lines = array_filter(array_map('trim', preg_split('/\R/', (string) $props['back_list']) ?: []), 'strlen');
$list  = '';

if ($lines) {
    $svg  = $lucide($props['list_icon_lucide'] ?? '', 18);
    $icon = $svg ? '<span class="fb-list-icon' . ($props['list_icon_color'] ? ' uk-text-' . $props['list_icon_color'] : '') . '">' . $svg . '</span>' : ($props['list_icon'] ? '<span class="fb-list-icon' . ($props['list_icon_color'] ? ' uk-text-' . $props['list_icon_color'] : '') . '" uk-icon="icon: ' . htmlspecialchars((string) $props['list_icon']) . '; width: 18"></span>' : '');
    $list = '<ul class="el-list fb-list uk-list uk-list-small">' . implode('', array_map(static fn ($line) => '<li>' . $icon . '<span>' . $line . '</span></li>', $lines)) . '</ul>';
}

// Back. A link without text makes the whole back side a link.
$button = '';
$cover  = '';

if ($props['link'] && $has($props['link_text'])) {
    $button = $this->el('a', [
        'class' => [
            'el-link',
            'uk-button uk-button-{link_style} {@!link_style: link}',
            'uk-button-{link_size} {@!link_style: link|text}',
            'uk-link {@link_style: link}',
        ],
        'href'   => ['{link}'],
        'target' => ['_blank {@link_target}'],
    ])->render($props, $props['link_text']);
    $button = '<div class="uk-margin-top">' . $button . '</div>';
} elseif ($props['link']) {
    $cover = $this->el('a', [
        'class'      => ['el-link fb-cover-link'],
        'href'       => ['{link}'],
        'target'     => ['_blank {@link_target}'],
        'aria-label' => strip_tags((string) ($props['back_title'] ?: $props['title'])) ?: false,
    ])->render($props, '');
}

$back = ($has($props['back_title']) ? $title($props['back_title'], $props['back_title_style']) : '')
    . ($has($props['back_content']) ? '<div class="el-content fb-text uk-panel">' . $props['back_content'] . '</div>' : '')
    . $list
    . $button . $cover;

?>
<?= $el($props, $attrs) ?>
    <div class="fb-inner">
        <?= $face('front', $front) ?>
        <?= $face('back', $back) ?>
    </div>
<?= $el->end() ?>
