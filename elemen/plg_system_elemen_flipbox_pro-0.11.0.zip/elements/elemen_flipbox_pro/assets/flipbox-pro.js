/* Elemen: Flip Box Pro — click/tap and keyboard turning. Hover works with CSS alone. */
(() => {
    const touch = window.matchMedia('(hover: none)');

    const toggle = (box, force) => {
        const flipped = box.classList.toggle('is-flipped', force);

        if (box.hasAttribute('aria-pressed')) {
            box.setAttribute('aria-pressed', String(flipped));
        }
    };

    document.addEventListener('click', (event) => {
        const box = event.target.closest('.elemen-flipbox-pro');

        if (!box || event.target.closest('a, button, input, select, textarea')) {
            return;
        }

        // Hover boxes only need help on touch screens, where there is no hover.
        if (box.classList.contains('fb-trigger-click') || touch.matches) {
            toggle(box);
        }
    });

    document.addEventListener('keydown', (event) => {
        const box = event.target;

        if (box.classList?.contains('fb-trigger-click') && (event.key === 'Enter' || event.key === ' ')) {
            event.preventDefault();
            toggle(box);
        }

        if (event.key === 'Escape') {
            const open = event.target.closest?.('.elemen-flipbox-pro.is-flipped');

            if (open) {
                toggle(open, false);
            }
        }
    });
})();
