<?php

/**
 * Package installer script for Terjemah.
 *
 * @license  GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\CMS\Language\Text;
use Joomla\Database\DatabaseInterface;
use Joomla\Database\ParameterType;

return new class () implements InstallerScriptInterface {
    private string $minimumJoomla = '5.4.0';

    private string $minimumPhp = '8.1.0';

    /** Plugins in this package, as [folder, element]. */
    private array $plugins = [
        ['system', 'terjemah'],
        ['system', 'terjemahyoo'],
        ['console', 'terjemah'],
    ];

    /**
     * The console commands this version ships. Plugin updates copy files over the old
     * ones, so a command an earlier version shipped would stay behind: any other file in
     * that folder is removed.
     */
    private array $commands = ['CleanupCommand.php', 'ExportCommand.php', 'ImportFileCommand.php', 'StatusCommand.php'];

    /** @var string[] "folder/element" of plugins present before this install or update. */
    private array $existingPlugins = [];

    public function install(InstallerAdapter $adapter): bool
    {
        return true;
    }

    public function update(InstallerAdapter $adapter): bool
    {
        return true;
    }

    public function uninstall(InstallerAdapter $adapter): bool
    {
        return true;
    }

    public function preflight(string $type, InstallerAdapter $adapter): bool
    {
        if ($type === 'uninstall') {
            return true;
        }

        if (version_compare(PHP_VERSION, $this->minimumPhp, '<')) {
            Factory::getApplication()->enqueueMessage(Text::sprintf('PKG_TERJEMAH_REQUIRES_PHP', $this->minimumPhp, PHP_VERSION), 'error');

            return false;
        }

        if (version_compare(JVERSION, $this->minimumJoomla, '<')) {
            Factory::getApplication()->enqueueMessage(Text::sprintf('PKG_TERJEMAH_REQUIRES_JOOMLA', $this->minimumJoomla, JVERSION), 'error');

            return false;
        }

        $this->existingPlugins = $this->installedPlugins();

        return true;
    }

    public function postflight(string $type, InstallerAdapter $adapter): bool
    {
        if ($type === 'uninstall') {
            return true;
        }

        // Plugins are installed disabled. Enable the ones this run added, and leave
        // plugins that already existed as the administrator set them.
        $db = Factory::getContainer()->get(DatabaseInterface::class);

        foreach (array_diff($this->installedPlugins(), $this->existingPlugins) as $plugin) {
            [$folder, $element] = explode('/', $plugin);

            $query = $db->createQuery()
                ->update($db->quoteName('#__extensions'))
                ->set($db->quoteName('enabled') . ' = 1')
                ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                ->where($db->quoteName('folder') . ' = :folder')
                ->where($db->quoteName('element') . ' = :element')
                ->bind(':folder', $folder)
                ->bind(':element', $element);

            $db->setQuery($query)->execute();
        }

        // Commands earlier versions shipped and this one no longer does.
        foreach (glob(JPATH_PLUGINS . '/console/terjemah/src/Command/*.php') ?: [] as $file) {
            if (!\in_array(basename($file), $this->commands, true)) {
                @unlink($file);
            }
        }

        return true;
    }

    /**
     * @return string[] "folder/element" of this package's plugins that are installed.
     */
    private function installedPlugins(): array
    {
        $db    = Factory::getContainer()->get(DatabaseInterface::class);
        $query = $db->createQuery()
            ->select($db->quoteName(['folder', 'element']))
            ->from($db->quoteName('#__extensions'))
            ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
            ->whereIn($db->quoteName('element'), array_unique(array_column($this->plugins, 1)), ParameterType::STRING);

        $installed = [];

        foreach ($db->setQuery($query)->loadObjectList() as $row) {
            if (\in_array([$row->folder, $row->element], $this->plugins, true)) {
                $installed[] = $row->folder . '/' . $row->element;
            }
        }

        return $installed;
    }
};
